#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""召回模拟：给定用户说法，看 description 的措辞覆盖能不能把它认出来。

指标：查询词元的 IDF 加权覆盖率 = 查询里有多少比例的措辞能在该技能 description/name 中字面找到。
（描述越长不应被惩罚，所以不用余弦；IDF 用来压低“文件/内容/数据”这类到处都有的词。）

注意边界：这里量的是“字面覆盖”，不是语义召回。真实模型靠语义也能命中，
本工具的价值在于暴露“description 里根本没有用户会说的那个词”这类隐性缺口。

用法：
  python route_sim.py --query "帮我把这份数据做成表格"
  python route_sim.py --queries cases.txt        # 每行 "说法<TAB>期望技能(可留空)"
  python route_sim.py --queries cases.txt --top 3 --min-score 0.5 --json out.json
退出码：0 全部命中；1 存在未命中/低覆盖；2 无输入。
"""
import argparse
import json
import math
import os
import re
import sys

STOP = {"技能", "使用", "用户", "支持", "处理", "生成", "创建", "编辑", "分析",
        "相关", "需要", "可以", "以及", "包括", "覆盖", "内容", "输出", "文件", "帮我",
        "这份", "这个", "一下", "把", "的", "了", "是", "在", "和", "与"}


def normalize(text):
    """去掉中英文/字母数字之间的空格，让 “AI 味”≈“AI味”、“ISO 14971”≈“ISO14971”。"""
    t = text or ""
    t = re.sub(r"([\u4e00-\u9fff])\s+([A-Za-z0-9])", r"\1\2", t)
    t = re.sub(r"([A-Za-z0-9])\s+([\u4e00-\u9fff])", r"\1\2", t)
    t = re.sub(r"([A-Za-z])\s+(\d)", r"\1\2", t)
    t = re.sub(r"(\d)\s+([A-Za-z])", r"\1\2", t)
    return t


def tokens(text):
    t = normalize(re.sub(r"[（(][^）)]*[）)]", "", text or ""))
    toks = {w.lower() for w in re.findall(r"[A-Za-z][A-Za-z0-9_-]{1,}", t)}
    for seg in re.findall(r"[\u4e00-\u9fff]+", t):
        for i in range(len(seg) - 1):
            toks.add(seg[i:i + 2])
    return toks - STOP


def load_skills(roots):
    out = []
    for r in roots:
        if not os.path.isdir(r):
            continue
        for name in sorted(os.listdir(r)):
            p = os.path.join(r, name, "SKILL.md")
            if not os.path.isfile(p):
                continue
            text = open(p, encoding="utf-8", errors="replace").read()
            m = re.search(r"^description:\s*(.+)$", text, re.M)
            desc = m.group(1).strip().strip("\"'") if m else ""
            out.append(dict(name=name, desc=desc, toks=tokens(desc + " " + name)))
    return out


def default_roots():
    here = os.path.abspath(__file__)
    user_root = os.path.dirname(os.path.dirname(os.path.dirname(here)))
    workspace = os.path.dirname(user_root)
    home = os.path.expanduser("~")
    return [os.path.join(workspace, ".skills"), user_root,
            os.path.join(home, "Doubao", "skills"), os.path.join(home, ".agents", "skills")]


def build_idf(skills):
    df = {}
    for s in skills:
        for t in s["toks"]:
            df[t] = df.get(t, 0) + 1
    n = len(skills)
    return {t: math.log((n + 1) / (c + 1)) + 1.0 for t, c in df.items()}


def coverage(q, s, idf):
    if not q:
        return 0.0, []
    denom = sum(idf.get(t, 1.0) for t in q)
    if denom <= 0:
        return 0.0, []
    matched = [t for t in q if t in s["toks"]]
    hit = sum(idf.get(t, 1.0) for t in matched)
    name_hit = sum(idf.get(t, 1.0) for t in q if len(t) >= 3 and t in s["name"].lower())
    return min(1.0, (hit + 0.15 * name_hit) / denom), matched


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--query", action="append")
    ap.add_argument("--queries")
    ap.add_argument("--top", type=int, default=3)
    ap.add_argument("--min-score", type=float, default=0.5,
                    help="词面覆盖下限；低于此值说明 description 缺该说法的关键词，只能靠语义猜")
    ap.add_argument("--json")
    ap.add_argument("--debug", action="store_true", help="打印命中/缺失词元，便于核对计分是否可信")
    ap.add_argument("--root", action="append",
                    help="指定技能根，可重复；给了就只扫这些根。用途：把候选 description 放进沙箱先测，再决定要不要改正式文件")
    args = ap.parse_args()

    cases = [(q, "") for q in (args.query or [])]
    if args.queries:
        with open(args.queries, encoding="utf-8") as f:
            for line in f:
                line = line.rstrip("\n")
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                parts = [x.strip() for x in re.split(r"\t|=>", line)]
                cases.append((parts[0], parts[1] if len(parts) > 1 else ""))
    if not cases:
        print("没有输入查询。", file=sys.stderr)
        return 2

    skills = load_skills(args.root if args.root else default_roots())
    idf = build_idf(skills)
    rows, miss = [], 0
    for q, expect in cases:
        qt = tokens(q)
        scored = []
        for s in skills:
            cov, matched = coverage(qt, s, idf)
            # 同分时按“命中词元个数、最长命中词元”再排，避免并列随意取名次
            scored.append((round(cov, 3), len(matched), max((len(t) for t in matched), default=0),
                           s["name"], matched))
        scored.sort(reverse=True)
        ranked = [(r[0], r[3]) for r in scored[:args.top]]
        top_name, top_cov = ranked[0][1], ranked[0][0]
        if args.debug:
            print("   查询词元: %s" % sorted(qt))
            for cov, cnt, ln, nm, mt in scored[:args.top]:
                print("   - %-28s cov=%.2f 命中(%d)=%s" % (nm, cov, cnt, sorted(mt)))
        if expect and top_name != expect:
            miss += 1
            print("MISS  %s\n      期望=%s 实得=%s 覆盖=%.2f  %s" % (q, expect, top_name, top_cov, ranked))
        elif expect:
            print("HIT   %s -> %s 覆盖=%.2f  %s" % (q, top_name, top_cov, ranked))
        else:
            low = top_cov < args.min_score
            print("%s %s -> %s 覆盖=%.2f" % ("LOW " if low else "INFO", q, top_name, top_cov))
            if low:
                miss += 1
        rows.append(dict(query=q, expect=expect, ranked=ranked, top_coverage=top_cov,
                         low_coverage=top_cov < args.min_score))

    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(dict(total=len(rows), miss=miss, min_score=args.min_score, rows=rows),
                      f, ensure_ascii=False, indent=1)
    print("\n用例 %d；未命中/低覆盖 %d" % (len(rows), miss))
    return 1 if miss else 0


if __name__ == "__main__":
    sys.exit(main())
