# -*- coding: utf-8 -*-
"""证据链校验：把"四要素 + 整链四项判据"变成可跑的门禁。

用法：
  python chain_verify.py --in chain.json
  python chain_verify.py --selftest

输入 JSON 形状：
{
 "claim": "结论一句话",
 "evidence": [
   {"id": "E1", "source": "URL 或文件路径", "locator": "页码/行号/字段",
    "time": "YYYY-MM-DD", "sha256": "<64 hex>", "grade": "A|B|C"}
 ]
}

判据：
  单条：source / locator / time / sha256 四项齐全且 grade ∈ {A,B,C} → 强证据
  整链：① 每条证据都强 ② 至少一条 A 或 B ③ 无时间倒挂（time ≤ 今天）
        ④ 总摘要 = 对按 id 排序后的规范化 JSON 求 sha256
退出码：0 CHAIN OK / 1 CHAIN FAIL / 2 参数错误。
"""
import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from datetime import date

HEX64 = re.compile(r"^[0-9a-f]{64}$")
DAY = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def chain_digest(chain):
    items = sorted(chain.get("evidence", []), key=lambda e: str(e.get("id", "")))
    canon = json.dumps({"claim": chain.get("claim", ""), "evidence": items},
                       ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canon.encode("utf-8")).hexdigest()


def check(chain):
    rows = []
    ev = chain.get("evidence") or []
    if not ev:
        return [("整链", False, "没有任何证据")], 0

    for e in ev:
        missing = [k for k in ("source", "locator", "time", "sha256") if not str(e.get(k) or "").strip()]
        bad_hash = not HEX64.match(str(e.get("sha256") or ""))
        bad_time = not DAY.match(str(e.get("time") or ""))
        bad_grade = str(e.get("grade") or "").upper() not in ("A", "B", "C")
        ok = not missing and not bad_hash and not bad_time and not bad_grade
        note = "齐全" if ok else "缺/格式错：" + "、".join(
            missing + (["sha256 非 64 位 hex"] if bad_hash else []) +
            (["time 非 YYYY-MM-DD"] if bad_time else []) +
            (["grade 非法"] if bad_grade else []))
        rows.append((str(e.get("id", "?")), ok, note))

    strongest = max([str(e.get("grade") or "").upper() for e in ev] or ["C"],
                    key=lambda g: {"A": 2, "B": 1, "C": 0}.get(g, 0))
    rows.append(("至少一条 A/B", strongest in ("A", "B"), "最高等级 %s" % strongest))

    today = date.today().isoformat()
    future = [str(e.get("id")) for e in ev if DAY.match(str(e.get("time") or "")) and str(e.get("time")) > today]
    rows.append(("无时间倒挂", not future,
                 "全部 ≤ %s" % today if not future else "时间在未来：" + "、".join(future)))

    rows.append(("总摘要", True, "chain_sha256=%s" % chain_digest(chain)))
    return rows, len(ev)


def report(chain, quiet=False):
    rows, n = check(chain)
    if not quiet:
        print("项            结论  说明")
        print("------------  ----  ----")
        for name, ok, note in rows:
            print("%-12s  %-4s  %s" % (name, "过" if ok else "未过", note))
    ok_all = all(r[1] for r in rows) and n > 0
    if not quiet:
        print("\n%s（证据 %d 条）" % ("CHAIN OK" if ok_all else "CHAIN FAIL", n))
    return 0 if ok_all else 1


def sample(good=True):
    h = hashlib.sha256(b"sample").hexdigest()
    ev = [{"id": "E1", "source": "https://example.org/notice", "locator": "§2 第 3 段",
           "time": "2026-11-01", "sha256": h, "grade": "A"},
          {"id": "E2", "source": "records/2026-11-02.log", "locator": "L1204",
           "time": "2026-11-02", "sha256": h, "grade": "B"}]
    if not good:
        ev[1].pop("locator")
    return {"claim": "示例结论：两次记录一致。", "evidence": ev}


def selftest():
    tmp = tempfile.mkdtemp(prefix="ecs_")
    p1, p2 = os.path.join(tmp, "good.json"), os.path.join(tmp, "bad.json")
    json.dump(sample(True), open(p1, "w", encoding="utf-8"), ensure_ascii=False)
    json.dump(sample(False), open(p2, "w", encoding="utf-8"), ensure_ascii=False)
    d1 = chain_digest(sample(True))
    d2 = chain_digest(sample(False))
    checks = [("合格链应 exit 0", report(sample(True), quiet=True) == 0),
              ("缺 locator 应 exit 1", report(sample(False), quiet=True) == 1),
              ("改一条证据总摘要应变化", d1 != d2)]
    failed = [n for n, ok in checks if not ok]
    if failed:
        print("自检未通过：" + "；".join(failed))
        return 1
    print("自检通过：3/3（合格 0 / 缺定位 1 / 摘要随内容变）")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="input")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return selftest()
    if not args.input:
        print(__doc__)
        return 2
    try:
        chain = json.load(open(args.input, encoding="utf-8"))
    except Exception as e:
        print("读不了输入：%s" % e, file=sys.stderr)
        return 2
    return report(chain)


if __name__ == "__main__":
    sys.exit(main())
