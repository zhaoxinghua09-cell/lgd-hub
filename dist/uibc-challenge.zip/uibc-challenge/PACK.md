# uibc-challenge

自治之物挑战赛的规则、评分与参赛入口，判据公开可复算。

- 版本线：lgd-hub rev H
- 许可：MIT（包内 LICENSE.txt 为全文；引用请保留署名 Xinghua Zhao）
- 包内文件：10 个，解压后约 0.02 MB
- `SKILL.md` 的 SHA-256：`1d28e6ee000dd740325c1de7ecfc6bf3695aaf273b2e2d4b4de82d59dad301ae`

## 安装

```bash
unzip uibc-challenge.zip -d ~/.claude/skills/     # 或你的 agent 技能目录
```

装完即可用；无依赖、不联网、不调模型。入口：`scripts/submission_check.py`。

## 自己核一遍

```bash
sha256sum SKILL.md            # 应等于上面那一行
python scripts/submission_check.py --json         # 机器可读；本件自身也可作为样本
```

哈希对不上就**先报这个**，别先报内容问题——对不上说明你拿到的不是这一版。

## 界线

本包自跑、非认证。评分出自公开加权的判据，判据自身的已知缺陷写在 https://zhaoxinghua09-cell.github.io/lgd-hub/EVAL.md
（我们选择公开而不修）。发现不一致、或不服某个数，走 https://zhaoxinghua09-cell.github.io/lgd-hub/FEEDBACK.md：
7 天内进表，30 天内给结论，结论只有采纳 / 驳回 / 存疑。
