# 体检阈值与误判清单

## 分级阈值

| 级 | 条件 | 含义 | 用法 |
|---|---|---|---|
| A | 总字节 ≥100KB 且文件 ≥10 | 重交付引擎：多文件资产、脚本/参考齐备 | 真实交付优先选它 |
| B | 总字节 ≥30KB 或文件 ≥8 | 中等深度：有参考或脚本，但资产不厚 | 可用，先读 SKILL.md 确认流程 |
| C | 其余（有实质正文） | 单文件流程件 | 按需用，注意它可能只有规则没有资产 |
| D | SKILL.md <3KB 且文件 ≤3 | 占位/入口桩 | 不要在复杂任务里依赖 |

分级只反映体量与资产厚度，不反映正确性。对外表述用“按体量分级”，不要说“最好”。

## 重复判定

- 一档：frontmatter `name` 完全相同 → 直接判重复（多根副本最常见）。
- 二档：SKILL.md 归一化后取连续 3 行 shingle，Jaccard ≥0.60 → 正文重复。
- 母版选择：文件数差 ≥3 取多者；否则体量差 >10% 取大者；都接近则标“需人工判定（目录内容等价）”。
- 处置：移入归档目录，不删除。归档路径 `workspace/.skills-archive/<YYYY-MM-DD>/<技能名>`，保留可回滚。

## 断链判定（防误报是第一位的）

算真断链，仅当：

- 路径以分发目录开头（`scripts/`、`references/`、`assets/`、`templates/`、`elements/`、`branches/`、`evals/`、`scenes/`、`sub-skills/`、`cli/`、`agents/`、`config/`），且技能目录内递归找不到同名文件；
- 或以 `../` 指向兄弟技能的真实路径而不存在。

不算断链（易误判，必须剔除）：

| 形态 | 例子 | 原因 |
|---|---|---|
| 运行期产物 | `report.json`、`qa-run.json`、`.workflow/*.json`、`evidence.json` | 由技能执行时生成，不随包分发 |
| 示例/占位名 | `draft.md`、`outline.md`、`theme.json`、`index.html` | 文档里的示意，不是资产 |
| 模板变量名 | `asset_usage_ep_N.json`、`selector-preflight.vN.json`、`提示词_SEGxxx_vNN.md` | 命名范式，不是具体文件 |
| CLI 片段 | `--format-report-out format_report.json`、`python x.py in.pdf out.txt` | 命令参数被正则误吃 |
| 外部地址 | `https://…`、`file://./x.json`、`~/…` | 非本地资产 |

裸文件名（无目录前缀）单独进“待核”栏：同行出现“见/参见/详见/references/”才列，避免把产物清单刷成断链。待核项人工确认一次，确属引用再修。

## 召回冲突

- 词元：description 去括号补充说明、去标点；中文取双字滑窗，英文取长度 ≥3 的词；剔除通用词（技能/使用/生成/处理/分析…）。
- Jaccard ≥0.30 列为候选，按重叠度排序，只报前 8 对。
- 冲突的含义是“同一句用户话可能同时命中两个技能”。修法在 description：写清适用对象、产物形态、边界（如“只读诊断不代写”“只处理在线文档不含本地 docx”），不要靠目录名或正文区分。

## 报告字段

- `total`：有效技能数（含 SKILL.md 的目录）。
- `hard`：硬问题列表，形如 `(类型, 说明)`，类型 ∈ 断链/重复/空壳/缺字段。
- `skills[]`：每个技能的 `dir/root/fm_name/desc/md_bytes/files/bytes/topdirs/has_scripts/has_refs/has_assets/missing/unverified/tier`。
- `duplicates[]`：`(Jaccard, 判定依据, A, B)`。
- `trigger_overlap[]`：`(Jaccard, A, B)`。
