# 权属证明与许可声明

> 本声明置于每个对外发布物的显著位置（SKILL.md 末尾 / 文档头部 / 包根）。
> 品牌署名统一用「注册老炮@[REDACTED]」，不得出现个人真名、在职公司或内部路径。

## 1. 著作权 ©
© 2026 注册老炮@[REDACTED]. 保留所有权利。
本作品（含软件代码与文档）的著作权归 注册老炮@[REDACTED] 所有。

## 2. 知识版权声明
本作品所汇集的方法论、对比分析、结构化知识与合成内容（"知识内容"），
其编排与原创表达归 注册老炮@[REDACTED] 所有。未经书面许可，不得复制、转载、摘编、转售，
或用于训练任何模型 / 商业系统。
（软件代码依随附 LICENSE 的许可条款使用；本知识版权声明不限制 LICENSE 已授予的权利。）

## 3. 免责声明（AS IS）
本作品按「现状」提供，不提供任何明示或暗示的担保，包括但不限于适销性、
特定用途适用性及非侵权担保。使用风险由使用者自行承担，因使用本作品所致
任何直接或间接损失，作者不承担责任。

## 4. 发布时间戳
- 发布时间（UTC）：2026-08-27T18:17:14.811464+00:00
- 发布时间（本地）：2026-08-28T02:17:14.811474

## 5. 作品指纹（内容哈希）
- 包指纹 SHA-256：c768afea08d7d77fab821bb4924221e1b9c34b9ea0cb3721c7cf3131a9a8a5e3
- 本指纹由发布包内全部文件的哈希按确定顺序合成，可作为该版本
  「于上述时间由 注册老炮@[REDACTED] 发布」的完整性标识。篡改任一文件即导致指纹变化。
- 加强权属：可将本指纹锚定至可信时间戳服务（RFC3161 TSA）或区块链，
  形成不可抵赖的「在先发表」证据（该步骤需外部服务，须经确认后单独执行）。

## 附：文件清单与逐文件哈希
| 文件 | SHA-256 |
|---|---|
| LICENSE.md | 44c4963847703a6fe1aaa79784a45c11ce0cc04202480900c478c2f2ed112feb |
| SKILL.md | e9da4f6dd27c78c72f2d5121e1cb0d50ec713fd5a36ee27fd64e30e4f0793605 |
| assets/overview.svg | 6dde1e53240a6488245e5a4e711dd348efa8f4b50d59df85aace7fd9c588011d |
| references/CN_医疗器械委托生产MAH实务.md | fe0cb05f7ddf9975aded6e5f9681f92c5661e3acc2eddf62b012310561419a87 |
| references/EU_EUDAMED数据库实务.md | 1c31e8d38d23e0378ea633e6a75263a3352bb03bb1f312b6e0e539df66cabec0 |
| references/EU_MDR上市后监管PMS实务.md | aa8c6718bf5fcee34050ba6de895dfff34a64350a2efaff4f85c965891305fe1 |
| references/FDA_UDI实施实务.md | 455244cf60d5b12e34a651e44f48a232bd5cf5fd20797194c1c8c1a51f6dc7c7 |
| references/FDA创伤敷料供应链穿透检查枢纽.md | c4ba7e3ed5f769ea7565d4ef068fc2dd0d924a09a5d2aebf6bcb3b0dafe08957 |
| references/GMP质量体系与验证枢纽.md | e52a8898791e9fcb26f5d998432125cb2b9b836474bf5840a1c009b866d11fe7 |
| references/README.md | 8091a6943063d0fec19bfefa7b7b8aedfa3d768bc94cbbc48cd3fe1d70f35c09 |
| references/UDI全球标识枢纽.md | 3d3873a6205bb65fdbfe3cfb8a040f5a11ae462452ee1bd361e98760bb3eadbd |
| references/上市后监管枢纽.md | 0380df5b24a9d6b64dff3891bb2fbf6edc9988ed8f96624ed4cc9d0ddc777382 |
| references/临床评价枢纽.md | 83d44e2530b098e093a38c5fd8bf5b4d3e7a8fb9783aabaecf4ce74262a2fada |
| references/原材料供应商合规枢纽.md | cd2a2abbef592b27368abae2ed72ca5316a4e4dbaa57daff96e21e43e1a98a9b |
| references/变更延续管理枢纽.md | bb79ca0a0a12f4afe620a911c1f89890241a6e799f803d4eaa61d273887d40ff |
| references/售后服务枢纽.md | 3752e9ddc2ecdabb21e173f842f59904de9b4c310945c708edf7631e96a83015 |
| references/审评核查获证枢纽.md | 6763b620e8fd74cda8fd26b20c88dee6c99ba4b02f19304a45f8d2b284a01d7f |
| references/市场准入与销售枢纽.md | 72594f94c0a79da4b647d40abdaa7d153c7375782250cabbff9ffe6a97ecc20e |
| references/技术文件STED撰写枢纽.md | bef150908b3d098c226c8a5830b6d57f708ff2d6876ade2d204bc43bd714a635 |
| references/枢纽总览_全生命周期7阶段纲领.md | b260cb1514ca302406e12b8395ed4f31def61ab577688ad840f5483677dd727f |
| references/标签与IFU枢纽.md | db752ed1de8a8e7caa9cf78876e00f116522afaf2b9213455893974a63ff0f94 |
| references/注册周期费用有效期对比枢纽.md | c3ce9a9f425b98b913b2a6055250c6ff6303991b799cf67bc74859453b3f523f |
| references/注册工程师资料枢纽.md | 641cb541cff8fa85be2fc6438d97898bea986405e3de2a77b8fa4bff8910bc16 |
| references/注册检验与申报实操枢纽.md | 98d4b34f9dbca8f0d896f7c69bc0121815cc0d72fec72c6a3b5fea50ef58b863 |
| references/灭菌包装验证枢纽.md | 6733dd7fb2d0e9c74af87855319cd548421d9580ae1414b3a2162e7baca23db3 |
| references/生物相容性测试规划枢纽.md | 12455c15d6ec383b7954785ce6ca2619065d4e6de3d8749a15bae031406c054e |
| references/设计开发控制枢纽.md | 3c3be56b3c15684850042d83450c96d82835833228f69d4c69dc777cf5bb2b77 |
| references/软件人因枢纽.md | 5f80f78221530cc673cd1f5ab65aa216fa1e8b9a0efc31161fdcaf992af68bc5 |
| references/需求调研与立项枢纽.md | 0dfa8244eb6210647b1cdd980cda294f9a49f434f11237ff9dbd49e06a790abd |
| references/风险管理枢纽.md | 71863ea41a8952c8b18d9b76f581ea4d31f7fa399241ea3f71e637e64d0d32f5 |
| references/骨科手术器械_全球注册路径汇编.md | 5b4716a3a31a013e18d37715db52a52a2937c1c53aeaf0ff5816c57c69b00866 |
| security-radar.svg | 55d0047c3802c9ff2706a10ba7af6a90e5fc22e13f3f3bc00a596b348592bdb6 |
| security_results.json | 2250b1176bc94852315254b1e682c660825dd9aba816dc4896078a6bed51c57d |
| 安全审计报告.md | 46a059f4dbdcbe877bb7b93a002f5c32858aed0f9d14ff621695eae517a06413 |
