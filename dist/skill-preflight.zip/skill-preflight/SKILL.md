---
x-theory: "LGD-Lifecycle-Governance-Doctrine-v1.0"
author: "赵兴华（Steven Zhao）"
version: "1.2.1"
category: "AI工程方法"
copyright: "赵兴华（Steven Zhao）"
agent_created: "true"
x-brand: "SynomosAI"
x-agent-seat: "潘布达(Buda Pan)"
x-attribution: "Xinghua Zhao"
agent_created: true
name: skill-preflight
description: 技能上架前的零 token 体检门禁。对任意 SKILL.md 按 D1-D10 十维加权 rubric（触发设计/元数据/可执行性/可验证性/边界诚实/去敏纪律/体量/署名/国际化/资源配套）算出 0-1 分与 A/B/C/D 档，给出在 688 个真实技能库中的百分位、逐维与全库均值的落差、泄密形态扫描结果，以及只列 3 条的补强动作；另附『SkillHub 评测对齐度』诊断（七段式骨架覆盖 + 缺哪段），并支持外部 G1 敏感词表（商号等，不硬编码、不随包发布）。全程读磁盘、不调 LLM、不联网，分数可复算、可 diff、可进 CI。触发词：技能体检、skill 体检、技能评分、skill 打分、技能质量、上架前检查、skill preflight、发布门禁、技能审计、SKILL.md 检查、骨架诊断。
license: MIT
metadata:
  x-author-legacy: "潘布达(Buda Pan)@SynomosAI"
  x-attribution: "Xinghua Zhao"
  x-brand: "SynomosAI"
  x-agent-seat: "潘布达(Buda Pan)"
  copyright: "赵兴华（Steven Zhao）"
  display: 技能上架体检器
  x-compliance-review: 已核验：判据全部从磁盘读出，零网络、零凭据、零 LLM 调用；扫描结果只报形态与计数，不回显命中值本身。
  display_name_en: Skill Preflight
  description_en: 'Zero-token, offline pre-publish health check for agent skills. Scores any SKILL.md on a 10-dimension weighted rubric, reports its percentile against a 688-skill baseline, scans for leaked secrets and local absolute paths, lists the top 3 fixes, and adds a SkillHub-evaluation alignment diagnostic (7-section skeleton coverage). Fully deterministic and CI-ready. Triggers: skill health check, skill score, skill preflight, publish gate, audit skill, SKILL.md review.'
  version: 1.2.1
  author: "赵兴华（Steven Zhao）"
  category: AI工程方法
  agent_created: true
  platforms:
  - windows
  - macos
  - linux
  tags:
  - 技能质量
  - 发布门禁
  - rubric
  - 零token
  - 可复算
  - CI
  slug: skill-preflight
  title: 技能上架体检器（Skill Preflight）
x-shelf: flagship
x-signature-line: B

display_name_en: "Skill Preflight"
description_en: "Zero-token pre-listing check for any SKILL.md against a weighted D1-D10 rubric: trigger design, metadata, structure, verifiability, boundaries, disclosure hygiene, size, provenance, internationalisation, resources. Use before listing or publishing a skill."
read_when:
- "技能要发布到任何市场（ClawHub / SkillHub / SkillPie / HF / BuiltinMarket）之前"
- "上线前需要客观判据判断这件技能够不够格"
- "想知道一件技能在真实技能库里排第几、差在哪几维"
- "要把技能质量做成 CI 门禁"
- "收到外部技能，想先体检再决定装不装"
---
# 技能上架体检器（Skill Preflight）

**一句话**：给一个技能目录或 `SKILL.md`，一秒内告诉你——**多少分、排第几、差在哪、能不能发**。

判据全部从磁盘读出的证据推导（frontmatter / 目录形态 / 正文结构词），**不调 LLM、不联网、不读凭据**。
同一份文件跑两次结果逐位相同；换机器结果相同。

## 何时用

| 场景 | 用哪个命令 |
|---|---|
| 上架前最后一个把关 | `preflight.py <技能目录> --require-publishable` |
| 按**内部发布规范**把关（AI 友好/中英文/理论锚/徽章…） | `preflight.py <技能目录> --require-spec 7` |
| 想知道一个技能差在哪 | `preflight.py <技能目录>` |
| 批量体检一批技能 | `preflight.py --batch <父目录>` |
| 接进 CI / 发布脚本 | `preflight.py <路径> --min-tier B`（不达标 exit 1） |
| 机器读结果 | `preflight.py <路径> --json` |

## 十维 rubric

总分 = Σ(维度分 × 权重)，区间 0–1。档位：**A ≥0.80 ｜ B 0.68–0.80 ｜ C 0.55–0.68 ｜ D <0.55**。
否决项命中直接落 D 档，不用高分覆盖。

| 维 | 名称 | 权重 | 看什么 |
|---|---|---|---|
| D1 | 触发设计 | 0.14 | description 是否说清「做什么+何时用」+ 有无触发词 + 有无 read_when |
| D2 | 元数据 | 0.14 | name/description/version/author/license/category/agent_created 完整度 |
| D3 | 可执行性 | 0.14 | 有无 scripts/、编号步骤 ≥3、可复制的命令块 |
| D4 | 可验证性 | 0.12 | 有无自检/验收标准/检查清单（「怎么知道做对了」） |
| D5 | 边界诚实 | 0.10 | 有无不适用/局限/免责 + 红线（不得、禁止、严禁） |
| D6 | 去敏纪律 | 0.10 | **硬门**：本地绝对路径 / 内部敏感词 / 密钥形态 |
| D7 | 体量 | 0.08 | 过短=空壳，过长=加载负担（80–600 行为满分） |
| D8 | 理论锚/署名 | 0.06 | 统一署名 + license + 可选的 DOI / x-theory 锚 |
| D9 | 国际化 | 0.04 | display_name_en / description_en（决定海外市场能否检索到） |
| D10 | 资源配套 | 0.08 | references/、scripts/、assets|templates|examples/ 覆盖度 |

> 完整判据与计分公式见 `references/rubric.md`。
> 口径与「家底总账 · 技能本体评估器（eval_skills.py v1.0）」**同源**，因此分数可直接与 688 技能基线比对。
> 改了任一侧，必须同步另一侧，否则分位会飘。

## 附加诊断：SkillHub 评测对齐度（七段式骨架）

**不参与 D1-D10 计分**（口径必须与 `eval_skills.py` 同源，动权重会让基线分位失真），
只在报告末尾额外输出，用来回答另一个问题：**"平台 AI 评审判我缺什么？"**

| 段 | 对应平台评分项 | 补什么 |
|---|---|---|
| 错误处理 | `reliability.errorHandling` | ≥4 条「若 X 失败 → 怎么办」+ 输入校验 + 降级说明 |
| 反模式/FAQ | `convention.antiPatternFaq` | ≥4 条"别这样做" + ≥5 条高频问答 |
| 环境与稳定性 | `reliability.stability` | 环境 / 依赖 / 兼容 / 幂等 / 重试 |
| 示例与最佳实践 | `convention.docQuality` | 真实跑出的输入输出对 + 快速开始 |
| 能力边界 | `adaptability.boundary` | 「不该用」+「改用谁」 |
| 触发设计 | `adaptability.trigger` | 标题或 frontmatter `read_when` / description 里的触发词 |
| 安装矩阵 | `effectiveness.usability` | ≥2 个客户端的安装方式 |

**为什么两套分要分开看**：机械结构分高 ≠ 语义评测分高。实测有技能 D1-D10 拿 **0.951（A 档）**，
骨架覆盖却只有 **2/7** —— 两把尺子测的不是同一件事，**都得看**。

## 发布规范符合度（对齐我们自己的两份既有规范）

**不是新造口径** —— 逐条对应已定的两份内部规范：

| 出处 | 规范 |
|---|---|
| ① | 《技能打磨规范 v1.0》（2026-09-06）「AI 友好六要素」 |
| ② | 《技能包设计规范》（2026-09-08）§3 修复回执 / §5 安装矩阵 / §6 frontmatter / §7 展示 / §10 政策契合 |

| # | 条款 | 出处 |
|---|---|---|
| S1 | frontmatter 结构化 | ①§一.1 ／ ②§6 |
| S2 | description 含触发词 + 边界 | ①§一.2 |
| S3 | **理论锚**（`x-theory:` 或 DOI `10.5281/zenodo.*`） | ①§一.3 |
| S4 | **徽章行**（`lgd-powered`，规范标「必须」） | ①§一.4 |
| S5 | 可验证性（`Source` / `How it's tested`） | ①§一.5 |
| S6 | 许可 + 署名 | ①§一.6 |
| S7 | **中英文双语元数据**（`display_name_en` / `description_en`） | ②§6、§7⑦ |
| S8 | 安装矩阵表 | ②§5 |
| S9 | 错误码 / 修复回执 | ②§3（须**行首标签**或错误码表；句中提一句不算） |
| S10 | 政策契合声明 | ②§10 |

**同样不计入 D1-D10**（口径同源原则）。门禁用法：

```bash
python scripts/preflight.py "<技能目录>" --require-spec 7   # 低于 7/10 → exit 1
python scripts/preflight.py --selftest                      # 自查门禁：豁免规则 11 条正/负样本断言，失守 exit 1
```

**🔴 禁用措辞**（②§10「虚假背书」红线：获得支持 / 入选 / 认证 / 官方推荐 / 政策扶持 / 指定产品 / 试点单位）
**无需开关，命中即阻断**。三道限定缺一不可，否则必误报：

1. **政策语境共现**——禁用词前后 60 字内须出现 工信部/政策/专项行动/入库/试点 等；
   否则「官方推荐（上游建议的版本）」这类技术写法会被误判（实测踩过）。
2. **元语境豁免**——命中词若处于「规则清单 / 规范对照表 / 引用行 / 反引号内」，一律不计。
   因为写规范、写「不要用 X」的说明时**必然要列出禁用词本身**，不豁免就会把
   **规则读成违规**（误报）、把**说明书读成已具备**（假达标）——这两个坑实测都踩过，
   而且是在**检查器扫自己**的时候现的原形。
3. **只认反引号**作引用信号——中文引号「」在正式文案里太常见（书名、专有名词），
   拿它当引用信号会把真声明误豁免（实测：真政策声明用「人工智能+软件」被漏判）。

> **教训一句话**：合规检查必须**区分「在讲规则」和「在使用」**。这是本检查器第二次栽在
> 「语境缺失」上（第一次是 `wemm-multimodal-kb` 的「官方推荐」误报）——
> 已按错误台账 3 击规则记录，第 3 击即升级为硬门禁。

## 外部 G1 敏感词表（商号等）

商号、客户名这类词**刻意不硬编码进代码**——写进代码本身就是泄漏，而且技能包会对外发。
改用外部词表，三种给法（优先级从高到低）：

```bash
python scripts/preflight.py "<技能目录>" --g1-file "<词表路径>"   # ① 显式指定
export PREFLIGHT_G1_FILE="<词表路径>"                            # ② 环境变量
# ③ 默认读 ~/.workbuddy/.g1_terms（该路径在技能包之外，不会随包发布）
```

词表格式：**一行一个词，# 开头为注释**。读不到就跳过，不报错。

> 设计意图：**词表与代码分离** ⇒ 技能包内不含商号 ⇒ 工具自己的自检不会自触发，
> 也不会在分发时把"我们不想外传的词"一起发出去。

## 怎么跑

1. **确认 Python 可用**（3.8+，零第三方依赖）：
   ```bash
   python --version
   ```
2. **体检单个技能**：
   ```bash
   python scripts/preflight.py "<技能目录路径>"
   ```
   接受目录（自动找里面的 `SKILL.md`）或直接给 `SKILL.md` 路径。
3. **看机器可读结果**：
   ```bash
   python scripts/preflight.py "<技能目录路径>" --json
   ```
4. **当门禁用**（不合格返回退出码 1）：
   ```bash
   python scripts/preflight.py "<技能目录路径>" --min-tier B --require-publishable
   ```
   三种门禁可组合：`--min-tier A|B|C`、`--min-score 0.75`、`--require-publishable`。
5. **批量体检一个目录下的所有技能**：
   ```bash
   python scripts/preflight.py --batch "<父目录>"
   ```

## 输出怎么读

```
总分      : 0.9510   →  A 档
全库分位  : 高于 99.9% 的技能（基线 688 个，中位 0.525）
-- 逐维（★ = 低于全库均值） --
  D5   边界诚实   0.750    0.395    0.1    ★   ← 本项 0.75 高于全库 0.395，标 ★ 表示落差超过 -0.05 才打
-- 该补什么（按拖后腿程度排序，只列 3 条） --
  1. D10 资源配套 = 0.700
     → 补 references/、scripts/、assets|templates|examples/ 至少两类。
-- 判定 --
  PASS · A 档，可直接对外交付
```

**分位为什么比绝对分有用**：全库中位数只有 0.525，A 档仅 11/688。一个 0.72 的技能听起来不错，
实际已在前 25%——但它的 D5 可能是 0.0。**绝对分说不出这件事，分位能。**

## 举证：怎么知道它是对的

| 判据 | 结果 | 验法 |
|---|---|---|
| 复现率 ≥95% | **100%**（60/60 逐位吻合） | 对台账 as_of 后未改动过的技能重算，与 `技能评估.json` 记录分数比对 |
| 幂等 | 通过（0/10 非幂等） | 同一技能连跑 2 次，剔除时间戳后 JSON 完全相同 |
| 门禁真会拦 | 通过 | 故意拿 D 档技能过 `--min-tier B` → exit 1；A 档 → exit 0 |

复现脚本见 `references/verify.md` 的「验证脚本」段（可原样复跑）。

## 出错怎么办

| 症状 | 原因 | 处置 |
|---|---|---|
| `[skip] 找不到 SKILL.md` | 路径给错，或该目录不是技能根目录 | 确认目录里有 `SKILL.md`；或直接把 `SKILL.md` 路径传进来 |
| 分位显示 `-` | 读不到 `references/baseline.json` | 检查该文件是否存在；缺了分数仍能算，只是没有百分位 |
| 分数与台账记录对不上 | 该技能在台账生成时间（`as_of`）**之后被改过** | 比对文件 `mtime` 与台账 `as_of`，不要直接怀疑工具 |
| 自检报"含内部敏感词"但确认文件是干净的 | **结构性自触发**——过滤器词表就写在自己代码/文档里 | 在技能根目录建 `.preflight-allow` 登记，**并用 `::words` 限定类型** |
| 批量模式报路径不存在 | Git Bash 会把 `/tmp` 映射到 Windows 盘符根下 | 传 Windows 风格路径（盘符 + `:/` + 目录，勿用 Unix 绝对路径） |

**输入校验规则**：只接受「目录」或「`.md` 文件」；目录下必须有 `SKILL.md`，否则跳过并打 stderr。
**失败时是否降级**：会——读不到基线只关分位，读不到词表只跳该项，**不中断体检**。

## 自检互测（D4 加强 · 上架前必跑 · 2026-10-07 血案）

**D4 达标 ≠ 自检本身是对的。** 实测血案：某文档型技能包 `--min-tier` 门禁全过、D4 拿满分
（有自检脚本 + 验收标准），但——

1. **拿本包自己的样例跑本包自检 → 失败**：校验器把**格式脚手架**（`出处`引用编号 / 表格序号列 /
   有序列表标记 `1.`）当成内容数字，要求它们在原文逐字出现 ⇒ **越遵守本包格式规范，越被本包判违例**；
   而包内文档恰好指引用户"用脚本自检上面任一样例" ⇒ **自检从资产变成负资产**。
2. **核心判据可被最朴素的截断绕过**：摘要把原文 `1500` 写成 `50`、`13.5` 写成 `3.5`，全部判为**通过**
   —— 根因是数字判据用了**子串包含**（`"50" in "1500"` 为真），防线形同虚设。

⇒ **交付前必做 4 条**（缺一不可）：

| # | 检查 | 不做会怎样 |
|---|---|---|
| 1 | **自带自检对本包自己的样例全部通过** | 文档让用户跑自检，跑出来是失败 ⇒ 自检成负资产 |
| 2 | **判据做过「可规避性攻击」**（截断/替换/粒度） | 核心判据被绕过，有闸等于没闸 |
| 3 | **修复配「防过度修正」用例** | 加严判据后未补反向用例（粒度粗化 `3 月` ⊂ `3 月 15 日`、小数 `1.5`）⇒ 修一个漏一个 |
| 4 | **检查器本身被攻击验证** | 抽取器/检查器自身 bug ⇒ 「测不到」被误读成「没问题」 |

> 一句话：**能跑 ≠ 对**。工具必须与其**自身的格式规范互测**，判据必须被主动攻击过才算数。
> 配套可复用工具见内部加固 Kit（含模板化校验器与《交付前自查清单》）。

## 常见陷阱 / Anti-patterns

| ❌ 别这样做 | ✅ 应该这样做 | 为什么 |
|---|---|---|
| 为了分数好看删掉 D5 边界段、D4 验证段 | 该补的补，不该删的别删 | 那是把体检变成化妆，问题反而被藏起来 |
| 用整文件豁免盖住命中 | 用 `::paths` / `::words` **类型限定** | 整文件豁免会把同文件里的真泄漏一起盖掉 |
| 把命中的密钥值贴进对话或工单 | 只报计数与位置，然后按凭据流程轮换 | 对话是高危信道，贴出去即不可撤回 |
| 分数过线就直接上架 | 分数是**必要条件**，不是许可 | 发布闸由 `platform-publish-steward` 按 G1–G4 判定 |
| 以为骨架覆盖高就一定拿高分 | 两套尺子独立看 | 实测有技能 0.951 分但骨架仅 2/7 |
| 以为 D4 满分就等于自检可靠 | 另跑「自检互测」4 条（样例全绿 + 可规避性攻击 + 防过度修正 + 检查器本身被攻击） | D4 只查「**有没有**自检」，不查「自检**对不对**」 |

## FAQ

**Q1：分数能跨机器复现吗？**
A：能。判据全部从磁盘推导，无时间戳、无随机数、无网络。换机器结果逐位相同。

**Q2：为什么七段骨架只做诊断、不计入总分？**
A：总分口径必须与 `eval_skills.py` 同源，动了权重会让 688 技能基线分位整体失真。要看骨架，单独看那一行。

**Q3：命中的密钥形态能豁免吗？**
A：**永不豁免**。`.preflight-allow` 只能豁免「本地绝对路径」与「内部敏感词」两类。

**Q4：它能不能判断技能解决的是不是真需求？**
A：不能。它只测"技能本体写得好不好"，需求真伪要靠市场数据（下载/星标/留存）。

**Q5：`--require-publishable` 和 `--min-tier` 有什么区别？**
A：前者查「**能不能对外**」（去敏 + 元数据 + 体量），后者查「**结构分够不够**」。发布前建议两个一起跑。

## 边界（不做的事）

- **只评「技能本体」，不评「技能有没有用」**。它测不出这个技能解决的是不是真需求——那要靠市场数据。
- **不判断事实正确性**。技能里写的法规编号对不对，它不管。
- **不替代 LLM 判官**。对外件发布前仍建议加一道人工或 LLM 质量判官，本工具是**前置筛**，不是终审。
- **本地绝对路径不视为安全事件**。内部技能写本机路径是正常的，只在 `--require-publishable` 时才算阻塞项。
- **不发任何网络请求、不读任何凭据**。命中密钥形态时只报「形态 + 计数」，**不回显命中值本身**。

## 红线

- **不得**把扫描命中的密钥值复制进对话、日志或工单——只报计数与文件位置，然后按凭据流程轮换。
- **禁止**为了让分数好看而删掉 D5 边界段或 D4 验证段——那是把体检变成化妆。
- **严禁**在未同步 `eval_skills.py` 的情况下改动 `WEIGHTS` 或 `DIM_NAME`——会让分位失真。
- **绝不**把本工具当作「上架许可」。分数过线只是必要条件，发布闸仍由 `platform-publish-steward` 判定。

## 资源

- `scripts/preflight.py` —— 体检器本体（零依赖、离线、可复算）
- `scripts/pull_platform_scores.py` —— 拉取**平台侧 AI 评分**（只读，用于与本地体检交叉；需本机 `~/.skillhub/credentials.json`）
- `scripts/build_baseline.py` —— 从台账 `技能评估.json` 重建 `baseline.json`
- `scripts/batch_enhance.py` —— **批量规范骨架补强**（S3/S4/S5/S6/S8/S10 + README）。
  默认 dry-run；`--scope <范围.json>` / `--root <技能库根>` / `--only a,b` / `--go` / `--restore`。
  **三道硬约束（F-003 血的教训，勿改）**：① 徽章/理论行**只许追加在文末**（插正文顶部会把触发词挤出
  `body[:2000]` 窗口 → D1 掉分并连带 S2 失守）；② 政策句适用范围用**原始正文**判定（用改后文本会因刚注入的
  `x-theory: "LGD-…"` 含 `LGD` 而恒真）；③ **备份绝不覆盖**，改后必须做全库口径对比（只升不降才算过）。
- `references/rubric.md` —— D1-D10 完整判据与计分公式 + `platform_fit` 口径
- `references/verify.md` —— 验证方法与验证脚本
- `references/baseline.json` —— 688 技能真实分数分布（用于算百分位）
