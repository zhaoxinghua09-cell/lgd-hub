# medxpert-reg-hub

All-in-one hub for medical device registration engineers — global pathways & classification (CN NMPA / US FDA / EU MDR / JP PMDA / ASEAN·LATAM), plus 20 topic hubs (UDI, STED, biocompatibility, GMP, post-market, labeling/IFU, risk, clinical evaluation, design control, software/human factors, sterilization, submission, review, after-sales, market access...) mapped to the 7-stage lifecycle, with verified official links. From feasibility to certificate, no more scattered searching.

## Usage

- Entry point: `SKILL.md` — read its frontmatter `name` / `description` to decide applicability, then follow the steps.
- No `scripts/` directory: this skill ships documentation only.

## License

MIT — see [LICENSE](LICENSE).
