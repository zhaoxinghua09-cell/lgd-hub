# medxpert-reg-hub

医械注册枢纽：按产品与市场给出路径，结论带官方直达链接。

- 版本线：lgd-hub rev H
- 许可：CC-BY-4.0（包内 LICENSE.txt 为全文；引用请保留署名 Xinghua Zhao）
- 包内文件：41 个，解压后约 0.25 MB
- `SKILL.md` 的 SHA-256：`068da1aa4a1ae1e169613fdfd7568d303c635d97e05504727fd4ad48f8ac5f26`

## 安装

```bash
unzip medxpert-reg-hub.zip -d ~/.claude/skills/     # 或你的 agent 技能目录
```

装完即可用；无依赖、不联网、不调模型。入口：`scripts/hub_verify.py`。

## 自己核一遍

```bash
sha256sum SKILL.md            # 应等于上面那一行
python scripts/hub_verify.py --json         # 机器可读；本件自身也可作为样本
```

哈希对不上就**先报这个**，别先报内容问题——对不上说明你拿到的不是这一版。

## 已知缺陷（不藏）

`SKILL.md` 第 517 行让使用者先读 `references/.abstract.md`（27 枢纽一句话速查）和 `references/.overview.md`（何时读/搭配/边界），但这两个文件在当前版本里**不存在**——本货架自己的诊断器 `skill-doctor` 直接报的 `[断链]`。包内保持资产原样，不偷偷补两个文件：补了哈希就变，你核的就不再是这一版。修法是下一个版本生成这两个索引件并重新打哈希、重新评分。

## 界线

本包自跑、非认证。评分出自公开加权的判据，判据自身的已知缺陷写在 https://zhaoxinghua09-cell.github.io/lgd-hub/EVAL.md
（我们选择公开而不修）。发现不一致、或不服某个数，走 https://zhaoxinghua09-cell.github.io/lgd-hub/FEEDBACK.md：
7 天内进表，30 天内给结论，结论只有采纳 / 驳回 / 存疑。
