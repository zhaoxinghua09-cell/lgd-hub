# -*- coding: utf-8 -*-
"""七层测试评分卡：把七层测试的实跑结果折算成覆盖率与误报率，并按目标判绿/判红。

用法：
  python gate_scorecard.py --in scorecard.json
  python gate_scorecard.py --selftest

输入 JSON 形状（只用到这些键，多余键忽略）：
{
  "layers": {
    "1_unit":      {"cases": 12, "passed": 12},
    "2_integration":{"cases": 4,  "passed": 4},
    "3_error_paths":{"cases": 6,  "passed": 5},
    "4_redteam":   {"cases": 9,  "passed": 9},
    "5_benchmark": {"tp": 40, "fp": 2, "fn": 3},
    "6_e2e":       {"cases": 3,  "passed": 3},
    "7_stress":    {"files": 10000, "ok": true}
  },
  "target_fp_rate": 0.05,
  "target_layer_coverage": 1.0
}

判定：
  - 每层只要 cases>0 且 passed==cases 记为「过」，否则记「未过」；5_benchmark 用精确率。
  - 误报率 = fp / (tp + fp)；召回率 = tp / (tp + fn)。
  - 任一层未过，或误报率 > target_fp_rate，退出码 1。
退出码：0 全绿 / 1 未达标 / 2 输入错误。
"""
import argparse
import json
import sys

LAYERS = [
    ("1_unit", "单元测试"),
    ("2_integration", "集成测试"),
    ("3_error_paths", "错误处理"),
    ("4_redteam", "红队测试"),
    ("5_benchmark", "严格基准"),
    ("6_e2e", "E2E 模拟"),
    ("7_stress", "压力测试"),
]


def eval_layer(key, node):
    """返回 (是否通过, 说明)。"""
    if not isinstance(node, dict):
        return False, "缺数据"
    if key == "5_benchmark":
        tp, fp, fn = node.get("tp", 0), node.get("fp", 0), node.get("fn", 0)
        if tp + fp + fn == 0:
            return False, "无样本"
        prec = tp / (tp + fp) if (tp + fp) else 0.0
        rec = tp / (tp + fn) if (tp + fn) else 0.0
        return (tp > 0 and fp == 0), "精确率 %.3f / 召回率 %.3f（tp=%d fp=%d fn=%d）" % (prec, rec, tp, fp, fn)
    if key == "7_stress":
        files = node.get("files", 0)
        return bool(node.get("ok")) and files > 0, "处理 %d 文件，结果=%s" % (files, node.get("ok"))
    cases, passed = node.get("cases", 0), node.get("passed", 0)
    if cases <= 0:
        return False, "无用例"
    return passed == cases, "%d/%d 通过" % (passed, cases)


def score(card):
    layers = card.get("layers") or {}
    rows, ok_all, measured = [], True, 0
    for key, label in LAYERS:
        ok, note = eval_layer(key, layers.get(key))
        rows.append((label, "过" if ok else "未过", note))
        if ok:
            measured += 1
        else:
            ok_all = False

    bm = layers.get("5_benchmark") or {}
    tp, fp = bm.get("tp", 0), bm.get("fp", 0)
    fp_rate = fp / (tp + fp) if (tp + fp) else 1.0
    target_fp = card.get("target_fp_rate", 0.05)
    coverage = measured / len(LAYERS)
    target_cov = card.get("target_layer_coverage", 1.0)

    fp_ok = fp_rate <= target_fp
    cov_ok = coverage >= target_cov
    verdict = "GREEN" if (ok_all and fp_ok and cov_ok) else "RED"
    return rows, fp_rate, coverage, target_fp, target_cov, fp_ok, cov_ok, verdict


def print_card(card):
    rows, fp_rate, coverage, target_fp, target_cov, fp_ok, cov_ok, verdict = score(card)
    print("层            结论   说明")
    print("------------  ----   ----")
    for label, state, note in rows:
        print("%-12s  %-6s %s" % (label, state, note))
    print("")
    print("覆盖率 %.2f（目标 ≥ %.2f，%s）" % (coverage, target_cov, "达标" if cov_ok else "未达标"))
    print("误报率 %.3f（目标 ≤ %.3f，%s）" % (fp_rate, target_fp, "达标" if fp_ok else "未达标"))
    print("判定：%s" % verdict)
    return 0 if verdict == "GREEN" else 1


def selftest():
    good = {"layers": {"1_unit": {"cases": 5, "passed": 5},
                       "2_integration": {"cases": 2, "passed": 2},
                       "3_error_paths": {"cases": 3, "passed": 3},
                       "4_redteam": {"cases": 4, "passed": 4},
                       "5_benchmark": {"tp": 20, "fp": 0, "fn": 1},
                       "6_e2e": {"cases": 2, "passed": 2},
                       "7_stress": {"files": 10000, "ok": True}}}
    bad = {"layers": dict(good["layers"], **{"3_error_paths": {"cases": 3, "passed": 2}})}
    noisy = {"layers": dict(good["layers"], **{"5_benchmark": {"tp": 20, "fp": 3, "fn": 0}})}

    checks = [
        ("全绿样例应 exit 0", print_card(good) == 0),
        ("错误处理缺一例应 exit 1", print_card(bad) == 1),
        ("误报率超目标应 exit 1", print_card(noisy) == 1),
    ]
    failed = [name for name, ok in checks if not ok]
    if failed:
        print("\n自检未通过：" + "；".join(failed))
        return 1
    print("\n自检通过：3/3 符合预期（全绿 0 / 缺层 1 / 误报超标 1）")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="input")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return selftest()
    if not args.input:
        print(__doc__)
        return 2
    try:
        card = json.load(open(args.input, encoding="utf-8"))
    except Exception as e:
        print("读不了输入：%s" % e, file=sys.stderr)
        return 2
    return print_card(card)


if __name__ == "__main__":
    sys.exit(main())
