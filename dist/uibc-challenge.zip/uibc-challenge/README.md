# uibc-challenge

UIBC 国际自治之物挑战赛（International Union of Beings Challenge）官方赛事助手——赛事体系、赛题规则、评分与反作弊、参赛指南一站式 AI 可读入口。UIBC 是 LGD 全程治理理论体系（凡自治之物：有籍·有证·有门禁）的公开验证场：挑战赛（单场）→ 系列赛（S1 赛季，4 站周更积分制，主题「迁移的判定与问责」）→ 专项赛（GATE 第二届·运行时门禁治理 Runtigil 三律命题）。评分 rubric S/A/B/C/D 五级、反作弊+查重双闸、人工晋级答辩（A³ 法则人类监督不可让渡）。当用户询问 UIBC 挑战赛、报名参赛、赛题规则、评分标准、系列赛赛程、GATE 命题、LGD 治理理论验证时加载本技能。品牌：UIBC（藏青+青绿）；理论母体：LGD（凡自治之物，有籍·有证·有门禁）；发起：SynomosAI 品牌运营。

## Usage

- Entry point: `SKILL.md` — read its frontmatter `name` / `description` to decide applicability, then follow the steps.
- No `scripts/` directory: this skill ships documentation only.

## License

MIT — see [LICENSE](LICENSE).
