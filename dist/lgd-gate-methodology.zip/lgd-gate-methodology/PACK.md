# lgd-gate-methodology

从 0 到 1 做开源信任/安全工具的完整方法论（有籍、有证、有门禁）。

- 版本线：lgd-hub rev H
- 许可：CC-BY-4.0（包内 LICENSE.txt 为全文；引用请保留署名 Xinghua Zhao）
- 包内文件：19 个，解压后约 0.03 MB
- `SKILL.md` 的 SHA-256：`cb2f6aa9f68e3771ee89f650a5603c2a6e96ee5ada37f1db82d90e22f3ac7ca6`

## 安装

```bash
unzip lgd-gate-methodology.zip -d ~/.claude/skills/     # 或你的 agent 技能目录
```

装完即可用；无依赖、不联网、不调模型。入口：`scripts/gate_scorecard.py`。

## 自己核一遍

```bash
sha256sum SKILL.md            # 应等于上面那一行
python scripts/gate_scorecard.py --json         # 机器可读；本件自身也可作为样本
```

哈希对不上就**先报这个**，别先报内容问题——对不上说明你拿到的不是这一版。

**这个 zip 是可复现的**：打包时冻结了内部时间戳与文件权限，所以同样内容重新打一次，字节与哈希完全相同（构建脚本自己连打两遍、自比对，不一致就不出包）。也就是说，「我们没在事后改过东西」这件事，你自己能验，不必信我们。

## 界线

本包自跑、非认证。评分出自公开加权的判据，判据自身的已知缺陷写在 https://zhaoxinghua09-cell.github.io/lgd-hub/EVAL.md
（我们选择公开而不修）。发现不一致、或不服某个数，走 https://zhaoxinghua09-cell.github.io/lgd-hub/FEEDBACK.md：
7 天内进表，30 天内给结论，结论只有采纳 / 驳回 / 存疑。
