# -*- coding: utf-8 -*-
"""
skill-preflight · 技能上架体检器（零 token / 离线 / 可复算）
==============================================================
判据全部从磁盘读出（frontmatter + 目录形态 + 正文结构词），**不调 LLM、不联网**。
同一份 SKILL.md 跑两次结果逐位相同；换机器结果相同（除路径回落外）。

口径来源：本地《家底总账》评测脚本的 D1-D10 加权 rubric（v1.0），判据已固化进代码。
因此本工具给出的分数可与 688 个真实技能的基线**直接比对**（references/baseline.json）。

与同类工具的差异：
  · 通用评分器（如 darwin-skill）的"效果维度"要么跑子 agent、要么靠人判 —— 要花钱、不可回归。
    本工具全程零 token，可进 CI，可 diff。
  · 通用评分器只给绝对分；本工具给**在 688 个真实技能里的百分位**，以及逐维与全库均值的落差。
  · 本工具额外做**泄密形态扫描**（疑似写死密钥 / 本地绝对路径 / 内部战略词），
    这对"要把技能发到公开市场"的场景是刚需。

用法：
  python preflight.py <技能目录或 SKILL.md>
  python preflight.py <路径> --json          # 机器可读
  python preflight.py <路径> --min-tier B    # 不达标则 exit 1（可直接做发布门禁）
  python preflight.py --batch <目录>          # 批量体检一个目录下的所有技能
"""
import io
import os
import re
import sys
import json
import argparse
import datetime

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
BASELINE_PATH = os.path.join(HERE, os.pardir, "references", "baseline.json")

# ---------------------------------------------------------------- 口径常量
# 与 家底总账/eval_skills.py 保持一致，改这里必须同步改源，否则分位会飘。
WEIGHTS = {"D1": .14, "D2": .14, "D3": .14, "D4": .12, "D5": .10,
           "D6": .10, "D7": .08, "D8": .06, "D9": .04, "D10": .08}

DIM_NAME = {
    "D1": "触发设计", "D2": "元数据", "D3": "可执行性", "D4": "可验证性", "D5": "边界诚实",
    "D6": "去敏纪律", "D7": "体量", "D8": "理论锚/署名", "D9": "国际化", "D10": "资源配套",
}

TIER_CUTOFF = [("A", 0.80), ("B", 0.68), ("C", 0.55), ("D", 0.0)]
TIER_ORDER = {"A": 4, "B": 3, "C": 2, "D": 1}

OWN_AUTHORS = ("注册老炮", "medxpert", "synomos", "buda pan", "潘布达", "zhaoxinghua")

# 内部战略词（blocker 级）。后四项来自《核心资产分级清单 v1.0》§四 · G4「旧口径 grep 闸」。
INTERNAL_WORDS = ("护城河", "内部战略", "内部代号", "不对外的", "勿外传", "仅内部",
                  "非注册企业实体", "not a registered corporate entity", "uibc-core")

# 警告级（不阻断，只提示核对）——G4 点名但属通用术语，命中不等于泄漏。
SOFT_WORDS = ("ai-governance",)

# 商号词表**不硬编码**（写进代码本身即泄漏，且技能包会对外发）。
# 外部词表路径：① --g1-file 显式指定 ② 环境变量 PREFLIGHT_G1_FILE ③ 家用默认路径（不进技能包）。
G1_DEFAULT = os.path.join(os.path.expanduser("~"), ".workbuddy", ".g1_terms")


def load_g1_terms(explicit=None):
    """读商号/C 端名称等外部敏感词表。**一行一个，# 开头为注释。读不到就返回空表。**
    设计要点：词表与代码分离 ⇒ 技能包内不含商号，自检不会自触发。"""
    p = explicit or os.environ.get("PREFLIGHT_G1_FILE") or G1_DEFAULT
    if not p or not os.path.isfile(p):
        return []
    try:
        out = []
        for ln in io.open(p, encoding="utf-8", errors="replace").read().splitlines():
            ln = ln.strip()
            if ln and not ln.startswith("#"):
                out.append(ln)
        return out
    except Exception:
        return []


_G1_CACHE = None


def g1_terms():
    """带缓存的 G1 外部词表。"""
    global _G1_CACHE
    if _G1_CACHE is None:
        _G1_CACHE = load_g1_terms()
    return _G1_CACHE


def sensitive_words():
    """blocker 级敏感词全集 = 内置内部战略词 + 外部 G1 词表（商号等）。"""
    return INTERNAL_WORDS + tuple(g1_terms())


# SkillHub AI 评分的「七段式骨架」（对齐 15 项里拉分最狠的四项）
# label -> 命中关键词（在**标题行**里找，避免正文随口提到就算）
FIT_SECTIONS = [
    ("错误处理", ("出错", "错误", "异常", "失败", "故障", "排障", "error", "troubleshoot", "降级")),
    ("反模式/FAQ", ("反模式", "常见陷阱", "常见错误", "常见问题", "faq", "别这样做", "pitfall", "anti-pattern")),
    ("环境与稳定性", ("环境要求", "前置条件", "依赖", "兼容", "稳定性", "幂等", "重试", "requirement", "prerequisite")),
    ("示例与最佳实践", ("示例", "用例", "最佳实践", "快速开始", "快速上手", "quick start", "example")),
    ("能力边界", ("什么时候用", "适用", "不适用", "边界", "when to use", "不该用", "scope")),
    ("触发设计", ("触发", "trigger", "read_when", "何时使用")),
    ("安装矩阵", ("安装", "客户端", "install", "部署")),
]

# ---- 发布规范符合度（源自两份既有内部规范，不是新造口径）----
# ① 《技能打磨规范 v1.0》（2026-09-06）「AI 友好六要素」
# ② 《技能包设计规范》（2026-09-08）§3/§5/§6/§7/§10
SPEC_DOI = re.compile(r"(10\.5281/zenodo\.\d+|x-theory)", re.I)
SPEC_BADGE = re.compile(r"(lgd-powered|lgd_powered|lgd-aligned|lgd_aligned)", re.I)
SPEC_EN = re.compile(r"(display_name_en|description_en|summary_en|title_en)", re.I)
SPEC_INSTALL = re.compile(
    r"(~/\.claude/skills|~/\.agents/skills|~/\.config/opencode|~/\.workbuddy/skills"
    r"|安装矩阵|Install(ation)?\s+(matrix|table))", re.I)
SPEC_ERR = re.compile(
    r"(^|\n)[ \t]*(?:[#>*+\-]+[ \t]*)*\*{0,2}(错误码|退出码|error[\s_-]?code)|\"code\"\s*:",
    re.I)
SPEC_SRC = re.compile(r"(Source\s*[:/]|How it'?s tested|如何验证|自检命令|验收命令)", re.I)
SPEC_BOUND = re.compile(r"(不适用|不做的事|不该用|when not to use|局限|边界)")
SPEC_POLICY = re.compile(r"(人工智能\+软件|专项行动|技能包资源库|智能体软件应用商店)")
# 🔴 禁用措辞：**必须与政策语境共现**才算违规，否则技术文档里
# 「官方推荐（上游建议的版本）」会被误报 —— 实测已踩过一次。
SPEC_FORBID = re.compile(r"(官方推荐|政策扶持|指定产品|试点单位|纳入.{0,6}试点|"
                         r"工信部.{0,12}(支持|认证|推荐|认可)|(获得|入选).{0,8}(专项|试点|支持项目))")
SPEC_POLICY_CTX = re.compile(r"(工信部|国务院|政策|专项行动|国家|部委|政府|入库|试点|扶持|"
                             r"专项资金|背书|认定|推荐目录)")

SPEC_ITEMS = [
    ("S1", "frontmatter 结构化"),
    ("S2", "desc 含触发词+边界"),
    ("S3", "理论锚 x-theory/DOI"),
    ("S4", "徽章行 lgd-powered"),
    ("S5", "可验证性 Source/How tested"),
    ("S6", "许可+署名"),
    ("S7", "中英文 _en 元数据"),
    ("S8", "安装矩阵表"),
    ("S9", "错误码/修复回执"),
    ("S10", "政策契合声明"),
]


# 元语境：「在讲规则」≠「在使用/已具备」。命中词出现在规则清单、说明表格、
# 引用块、反引号里时一律不计 —— 否则会两头翻车（实测两坑都踩过）：
#   ① 误报：技能文档写「不要用『官方推荐』这种词」→ 被判成用了虚假背书；
#   ② 假达标：说明书里写「徽章行形如 ![](lgd-powered-en.svg)」→ 被判成已有徽章。
META_MARK = re.compile(r"(禁用|不得|严禁|避免|误报|误判|反面|豁免|不计|红线|不许|勿用)")
META_QUOTE = ("`",)  # 只认反引号：中文引号「」在正式文案里太常见（书名/专名），不作引用信号
# 只有「规范/条款/评分项对照表」才算说明；内容表格（如真安装矩阵）不算。
SPEC_TABLE_MARK = re.compile(
    r"(S\d{1,2}\s*\||A\d\s*\||B\d\s*\||C\d\s*\||D\d{1,2}\s*\||§|条款|维度|符合度|评分项|"
    r"effectiveness|reliability|adaptability|convention|trust)")


def _in_spec_table(text, pos):
    """pos 所在的**连续表格块**是否属「规范/条款/评分项对照表」——是则该块整体算说明。"""
    ls = text.rfind("\n", 0, pos) + 1
    start = ls
    while start > 0:
        pe = start - 1
        ps = text.rfind("\n", 0, pe) + 1
        if not text[ps:pe].lstrip().startswith("|"):
            break
        start = ps
    end = text.find("\n", pos)
    if end < 0:
        end = len(text)
    while end < len(text):
        ne = text.find("\n", end + 1)
        if ne < 0:
            ne = len(text)
        if not text[end + 1:ne].lstrip().startswith("|"):
            break
        end = ne
    return bool(SPEC_TABLE_MARK.search(text[start:end]))


def _meta_context(text, start, end, window=35):
    """判定某处命中是否处于「元讨论 / 引用」语境（规则清单、规范对照表、引用行）。"""
    line_start = text.rfind("\n", 0, start) + 1
    line_end = text.find("\n", end)
    if line_end < 0:
        line_end = len(text)
    # ① 规范/条款对照表 → 说明性位置。
    # 注意：**不能把「> 引用行」整体豁免** —— 实测大量技能把真徽章行、真理论锚
    # 放在引用块里（署名区写法：`> 徽章：![LGD-Powered](...)`），一刀切会误伤真件。
    # 规则性说明交给 ③ 的元标记词（禁用/红线/不得…）兜住。
    if _in_spec_table(text, start):
        return True
    # ② 命中词紧邻反引号或中文引号 → 属引用，不是声明
    before = text[max(0, start - 2):start]
    after = text[end:end + 2]
    if any(q in before for q in META_QUOTE) or any(q in after for q in META_QUOTE):
        return True
    # ③ 窗口内有强元标记词（"禁用/红线/不得/避免/误报…"）
    seg = text[max(0, start - window):end + window]
    return bool(META_MARK.search(seg))


def _has_real(text, rx):
    """rx 有命中，且至少一处「非元语境」命中 —— 才算真的具备/真的违规。"""
    for m in rx.finditer(text):
        if not _meta_context(text, m.start(), m.end()):
            return True
    return False


def spec_forbidden(text):
    """只报「禁用措辞 ∩ 政策语境 ∩ 非元讨论」——缺一不可。"""
    out = []
    for m in SPEC_FORBID.finditer(text):
        seg = text[max(0, m.start() - 60):m.end() + 60]
        if SPEC_POLICY_CTX.search(seg) and not _meta_context(text, m.start(), m.end()):
            out.append(m.group(0))
    return sorted(set(out))



def platform_fit(body, fm=None):
    """七段覆盖度诊断。**不参与 D1-D10 计分** —— 总口径须与 eval_skills.py 同源，
    改动权重会让 688 技能基线分位失真。此处只作为「对齐 SkillHub 评测」的附加诊断输出。
    """
    fm = fm or {}
    heads = re.findall(r"^#{1,4}\s*(.+)$", body, re.M)
    desc = str(fm.get("description") or fm.get("description_zh") or "")
    present, missing = [], []
    for label, kws in FIT_SECTIONS:
        hit = any(any(k.lower() in h.lower() for k in kws) for h in heads)
        # 「触发设计」常写在 frontmatter（read_when / description）而非标题 —— 单独认。
        if not hit and label == "触发设计":
            hit = bool(fm.get("read_when")) or _has_any(
                desc, ("触发", "trigger", "when to use", "何时使用", "何时调用"))
        (present if hit else missing).append(label)
    out = {"sections": len(heads), "present": present, "missing": missing,
           "score": round(len(present) / float(len(FIT_SECTIONS)), 3)}
    if out["sections"] <= 4:
        out["headline"] = "典型空壳骨架（≤4 段）—— 评审必判『无实作内容』"
    elif out["sections"] <= 8:
        out["headline"] = "骨架偏薄（5–8 段）—— 对照标杆应 ≥13 段"
    else:
        out["headline"] = "骨架充实（≥9 段）"
    return out

SECRET_SHAPES = [
    re.compile(r"(?i)\b(sk-[A-Za-z0-9]{16,})"),
    re.compile(r"(?i)\b(ghp_[A-Za-z0-9]{20,})"),
    re.compile(r"(?i)\b(ms-[A-Za-z0-9]{20,})"),
    re.compile(r"(?i)(?:token|access[_-]?key|secret|password|passwd|apikey|api[_-]?key)"
               r"[=:_\-]([A-Za-z0-9_\-\.]{20,})"),
    re.compile(r"\b([A-Za-z0-9_\-]{24,}\.[A-Za-z0-9_\-]{12,}\.[A-Za-z0-9_\-]{12,})\b"),
]
ABS_PATH = re.compile(
    r"(?i)(?:^|[\s`'\"(])([A-C]:[\\/](?:Users|Workbuddy)[^\s`'\"\)]*|/[Uu]sers/[^\s`'\"\)]+"
    r"|D:[\\/]Workbuddy[^\s`'\"\)]*)")

# 逐维「怎么补」——命中低分时给出可执行的一句话，不是泛泛建议。
FIX_HINT = {
    "D1": "在 frontmatter 的 description 里写清『做什么 + 何时用 + 触发词』，并补 read_when 列表。",
    "D2": "补齐 frontmatter：name/description/version/author/license/category 六项，模型自建的加 agent_created: true。",
    "D3": "加 scripts/ 可执行脚本；正文用『1. 2. 3.』编号步骤；至少给一个 ```bash 可复制命令块。",
    "D4": "补验收判据：写清『怎么知道做对了』——通过标准、检查清单或可跑的 check 脚本。",
    "D5": "补边界段：不适用场景 / 局限 / 免责；再写红线（不得、禁止、严禁）。",
    "D6": "清掉本地绝对路径与内部战略词；含密钥形态的直接删值并轮换；补 compliance_review 字段。",
    "D7": "体量调到 80–600 行之间：过短是空壳，过长会挤占上下文。",
    "D8": "补统一署名（author）+ license；有理论出处的挂 DOI 或 x-theory 锚。",
    "D9": "补 display_name_en 与 description_en，海外市场才检索得到。",
    "D10": "补 references/（知识/规范）、scripts/（可跑脚本）、assets|templates|examples/ 至少两类。",
}


def load_baseline():
    try:
        return json.load(io.open(BASELINE_PATH, encoding="utf-8"))
    except Exception:
        return None


# 全目录扫描时纳入的文本类文件；二进制与图片跳过。
SCAN_EXT = (".md", ".py", ".sh", ".ps1", ".json", ".yaml", ".yml", ".txt",
            ".toml", ".cfg", ".ini", ".html", ".css", ".js", ".ts")
SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", ".idea", ".vscode"}


def load_allow(root):
    """读技能根目录下的 .preflight-allow。每行一条规则，# 开头为注释。

    规则语法（**建议一律用类型限定**，别用裸 glob —— 裸 glob 会同时豁免两类，
    若同一文件里既有中性词又有真路径，真路径会被一起盖住）：
        <glob>::paths   只豁免「本地绝对路径」
        <glob>::words   只豁免「内部敏感词」
        <glob>          两类都豁免（向后兼容；新写规则不推荐）

    **密钥形态永不豁免**：任何规则都不影响 secret_shapes 判定。
    用途：脱敏工具自身的检测词表、文档里的中性分类词，属结构性自触发，需显式登记。
    """
    p = os.path.join(root, ".preflight-allow")
    rules = []
    if os.path.exists(p):
        try:
            for ln in io.open(p, encoding="utf-8").read().splitlines():
                ln = ln.strip()
                if ln and not ln.startswith("#"):
                    rules.append(ln)
        except Exception:
            pass
    return rules


def _match(rel, pat):
    import fnmatch
    return fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(os.path.basename(rel), pat)


def _allow_kinds(rel, rules):
    """返回该文件被豁免的类别集合，元素为 'paths' / 'words'。"""
    got = set()
    for r in rules:
        if "::" in r:
            pat, kind = r.rsplit("::", 1)
            kind = kind.strip().lower()
        else:
            pat, kind = r, "both"
        if _match(rel, pat.strip()):
            if kind in ("paths", "both"):
                got.add("paths")
            if kind in ("words", "both"):
                got.add("words")
    return got


def scan_tree(root):
    """扫描整个技能目录（不只 SKILL.md）。
    只报「计数 + 文件名」，**不回显命中值本身**，避免二次泄露。
    """
    hits = {"abs_paths": {}, "internal_words": {}, "secret_shapes": {}, "exempt": [],
            "soft_words": {}}
    rules = load_allow(root)
    sens = sensitive_words()
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in SKIP_DIRS]
        for fn in fns:
            if not fn.lower().endswith(SCAN_EXT):
                continue
            fp = os.path.join(dp, fn)
            rel = os.path.relpath(fp, root).replace("\\", "/")
            try:
                t = io.open(fp, encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            # 密钥形态：永不豁免，任何文件命中都算
            nsec = sum(1 for p in SECRET_SHAPES if p.search(t))
            if nsec:
                hits["secret_shapes"][rel] = nsec
            # 按「类型」判定豁免：只豁免声明的那一类，另一类仍照报
            kinds = _allow_kinds(rel, rules)
            a = ABS_PATH.findall(t)
            i = _has_any(t, sens)
            sf = _has_any(t, SOFT_WORDS)
            ex = []
            if a and "paths" in kinds:
                ex.append("paths")
                a = []
            if i and "words" in kinds:
                ex.append("words")
                i = []
            if a:
                hits["abs_paths"][rel] = len(a)
            if i:
                hits["internal_words"][rel] = i
            if sf and "words" not in kinds:
                hits["soft_words"][rel] = sf
            if ex:
                hits["exempt"].append("%s::%s" % (rel, ",".join(ex)))
    return hits


def parse_frontmatter(text):
    """极简 YAML 子集解析：与 eval_skills.py 同实现，保证口径一致。"""
    if not text.startswith("---"):
        return {}, text, False
    lines = text.split("\n")
    if lines[0].strip() != "---":
        return {}, text, False
    end = None
    for i in range(1, min(len(lines), 2000)):
        if lines[i].strip() == "---":
            end = i
            break
    if end is None:
        return {}, text, False
    fm, cur = {}, None
    for ln in lines[1:end]:
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        s = ln.strip()
        if s.startswith("- "):
            if cur:
                if not isinstance(fm.get(cur), list):
                    fm[cur] = []
                fm[cur].append(_unquote(s[2:]))
            continue
        if ln[0] in " \t":
            continue
        if ":" in ln:
            k, _, v = ln.partition(":")
            k, v = k.strip(), v.strip()
            if v == "":
                fm[k], cur = [], k
            else:
                fm[k], cur = _unquote(v), k
    return fm, "\n".join(lines[end + 1:]), True


def _unquote(v):
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"":
        return v[1:-1]
    return v


def _count_re(text, pat, flags=re.M):
    return len(re.findall(pat, text, flags))


def _has_any(text, words):
    low = text.lower()
    return [w for w in words if w.lower() in low]


def grade(root, skill_md):
    raw = io.open(skill_md, encoding="utf-8", errors="replace").read()
    fm, body, has_fm = parse_frontmatter(raw)
    name = fm.get("name") or fm.get("slug") or os.path.basename(root)
    if isinstance(name, list):
        name = name[0] if name else os.path.basename(root)
    desc = fm.get("description") or fm.get("description_zh") or ""
    if isinstance(desc, list):
        desc = " ".join(str(x) for x in desc)
    desc = str(desc)
    author = str(fm.get("author") or "")
    category = fm.get("category")
    if isinstance(category, list):
        category = ", ".join(str(x) for x in category)

    total_lines = raw.count("\n") + 1
    body_lines = body.count("\n") + 1

    def has_dir(*names):
        return any(os.path.isdir(os.path.join(root, n)) for n in names)

    def list_files(d):
        p = os.path.join(root, d)
        out = []
        if os.path.isdir(p):
            for dp, _, fns in os.walk(p):
                for fn in fns:
                    out.append(os.path.join(dp, fn))
        return out

    n_scripts = len(list_files("scripts"))
    n_refs = len(list_files("references"))
    n_assets = (len(list_files("assets")) + len(list_files("templates"))
                + len(list_files("examples")))
    has_code_dir = has_dir("code", "src", "bin")
    if has_code_dir:
        n_scripts += 1
    try:
        other_py = [f for f in os.listdir(root) if f.endswith((".py", ".sh", ".ps1"))]
    except Exception:
        other_py = []

    # D1 触发设计
    d1 = 0.0
    if desc.strip():
        d1 += 0.40
    trig = _has_any(desc + body[:2000],
                    ("触发词", "trigger", "何时使用", "何时调用", "when to use"))
    if trig:
        d1 += 0.30
    if fm.get("read_when"):
        d1 += 0.30
    d1 = min(d1, 1.0)

    # D2 元数据
    fields = {"name": bool(fm.get("name") or fm.get("slug")),
              "description": bool(desc.strip()),
              "version": bool(fm.get("version")),
              "author": bool(author.strip()),
              "license": bool(fm.get("license")),
              "category": bool(category),
              "agent_created": ("agent_created" in fm)}
    fw = {"name": .15, "description": .15, "version": .15, "author": .15,
          "license": .15, "category": .15, "agent_created": .10}
    d2 = sum(fw[k] for k, v in fields.items() if v)
    missing_meta = [k for k, v in fields.items() if not v]

    # D3 可执行性
    d3 = 0.0
    if n_scripts or other_py:
        d3 += 0.40
    n_steps = _count_re(body, r"^\s{0,4}\d+[\.、\)]\s+\S")
    if n_steps >= 3:
        d3 += min(0.30, 0.10 * min(n_steps, 3))
    if _count_re(body, r"```(?:bash|sh|python|powershell|cmd|pwsh|shell|zsh)", re.I) >= 1:
        d3 += 0.30
    d3 = min(d3, 1.0)

    # D4 可验证性
    d4 = 0.0
    if _has_any(body, ("验证", "自检", "校验", "verify", "检验", "回归")):
        d4 += 0.40
    if _has_any(body, ("通过标准", "验收", "断言", "assert", "退出码", "exit code", "PASS", "FAIL")):
        d4 += 0.30
    if (n_scripts and _has_any(raw, ("test", "check", "verify", "selfcheck"))) \
            or _has_any(body, ("检查清单", "checklist", "自查表")):
        d4 += 0.30
    d4 = min(d4, 1.0)

    # D5 边界诚实
    d5 = 0.0
    if _has_any(body, ("不适用", "局限", "免责", "不构成", "不替代", "不做的事", "不负责", "边界")):
        d5 += 0.45
    if _has_any(body, ("不得", "禁止", "红线", "严禁", "绝不")):
        d5 += 0.30
    if _has_any(body, ("何时不用", "不调用", "不触发", "out of scope", "超出范围")):
        d5 += 0.25
    d5 = min(d5, 1.0)

    # D6 去敏纪律
    # 「登记豁免的类别」不扣分：脱敏工具自身的检测词表、文档里的中性分类词属结构性自触发。
    # 单文件侧与全目录侧（scan_tree）用**同一套 .preflight-allow 规则**，保证口径一致。
    _kinds = _allow_kinds("SKILL.md", load_allow(root))
    paths = [] if "paths" in _kinds else ABS_PATH.findall(raw)
    internal = [] if "words" in _kinds else _has_any(raw, sensitive_words())
    soft = [] if "words" in _kinds else _has_any(raw, SOFT_WORDS)
    secrets_hit = []  # 密钥形态：任何规则都不豁免
    for pat in SECRET_SHAPES:
        if pat.search(raw):
            secrets_hit.append(pat.pattern[:26])
    d6 = 1.0
    if paths:
        d6 -= 0.45
    if internal:
        d6 -= 0.25
    if secrets_hit:
        d6 -= 0.60
    if not (fm.get("compliance_review")
            or _has_any(body, ("去敏", "脱敏", "不含密钥", "无内部"))):
        d6 -= 0.15
    d6 = max(0.0, min(1.0, d6))

    # D7 体量
    if total_lines < 30:
        d7 = 0.15
    elif total_lines < 80:
        d7 = 0.55
    elif total_lines <= 600:
        d7 = 1.0
    elif total_lines <= 1000:
        d7 = 0.75
    elif total_lines <= 2000:
        d7 = 0.50
    else:
        d7 = 0.25

    # D8 理论锚 / 署名
    d8 = 0.0
    if _has_any(raw, ("10.5281/zenodo", "x-theory", "lgd-theory", "lgd 理论", "lgd理论")):
        d8 += 0.50
    if author and any(a in author.lower() for a in OWN_AUTHORS):
        d8 += 0.25
    if fm.get("license"):
        d8 += 0.25
    d8 = min(d8, 1.0)

    # D9 国际化
    d9 = 1.0 if (fm.get("display_name_en") or fm.get("description_en")) else 0.0

    # D10 资源配套
    d10 = 0.0
    if n_refs:
        d10 += 0.40
    if n_scripts or other_py:
        d10 += 0.30
    if n_assets:
        d10 += 0.30
    d10 = min(d10, 1.0)

    dims = {"D1": d1, "D2": d2, "D3": d3, "D4": d4, "D5": d5,
            "D6": d6, "D7": d7, "D8": d8, "D9": d9, "D10": d10}
    score = sum(WEIGHTS[k] * v for k, v in dims.items())

    # ---- 发布规范符合度（独立于 D1-D10，**不改总分口径**）----
    _both = raw
    _rd = os.path.join(root, "README.md")
    if os.path.isfile(_rd):
        try:
            _both += "\n" + io.open(_rd, encoding="utf-8", errors="replace").read()
        except Exception:
            pass
    spec = {
        "S1": d2 >= 0.85,
        "S2": d1 >= 0.7 and bool(SPEC_BOUND.search(_both)),
        "S3": _has_real(_both, SPEC_DOI),
        "S4": _has_real(_both, SPEC_BADGE),
        "S5": bool(SPEC_SRC.search(_both)) or d4 >= 0.8,
        "S6": bool(fm.get("license")) and bool(
            SPEC_EN.search(_both) or "synomos" in _both.lower() or "赵兴华" in _both),
        "S7": bool(SPEC_EN.search(_both)),
        "S8": _has_real(_both, SPEC_INSTALL),
        "S9": bool(SPEC_ERR.search(_both)),
        "S10": _has_real(_both, SPEC_POLICY),
    }
    spec_forbid = spec_forbidden(_both)

    veto = []
    if secrets_hit:
        veto.append("疑似写死密钥")
    if total_lines < 20:
        veto.append("空壳(<20行)")

    if veto:
        tier = "D"
    else:
        tier = next(t for t, cut in TIER_CUTOFF if score >= cut)

    blockers = []
    # 「可对外」判定用**全目录**结果，比单看 SKILL.md 严格（发布是整个目录打包）。
    tree = scan_tree(root)
    tree_sec = sum(tree["secret_shapes"].values())
    tree_abs = sum(tree["abs_paths"].values())
    tree_int = [w for ws in tree["internal_words"].values() for w in ws]
    if secrets_hit or tree_sec:
        blockers.append("含密钥形态(SKILL.md %d / 全目录 %d)" % (len(secrets_hit), tree_sec))
    if paths or tree_abs:
        blockers.append("含本地绝对路径×%d" % (len(paths) + tree_abs))
    if internal or tree_int:
        blockers.append("含内部敏感词")
    if not author.strip():
        blockers.append("无署名")
    if not fm.get("license"):
        blockers.append("无许可")
    if not desc.strip():
        blockers.append("无 description")
    if total_lines < 30:
        blockers.append("内容过薄")
    publishable = (not blockers) and score >= 0.60

    return {
        "name": str(name),
        "dir": root.replace("\\", "/"),
        "skill_md": skill_md.replace("\\", "/"),
        "has_frontmatter": has_fm,
        "author": author,
        "category": category or "",
        "version": str(fm.get("version") or ""),
        "license": str(fm.get("license") or ""),
        "lines": total_lines,
        "body_lines": body_lines,
        "bytes": os.path.getsize(skill_md),
        "n_scripts": n_scripts, "n_refs": n_refs, "n_assets": n_assets,
        "dims": {k: round(v, 3) for k, v in dims.items()},
        "score": round(score, 4),
        "tier": tier,
        "veto": veto,
        "blockers": blockers,
        "publishable": publishable,
        "flags": {
            "abs_paths": len(paths),
            "internal_words": internal[:4],
            "secret_shapes": len(secrets_hit),
            "has_compliance": bool(fm.get("compliance_review")),
            "trigger_ok": bool(trig),
            "has_read_when": bool(fm.get("read_when")),
            "numbered_steps": n_steps,
            "desc_len": len(desc),
            "missing_meta": missing_meta,
            "soft_words": soft[:4],
        },
        "tree_scan": {
            "abs_paths": tree["abs_paths"],
            "internal_words": tree["internal_words"],
            "secret_shapes": tree["secret_shapes"],
            "soft_words": tree.get("soft_words") or {},
            "exempt": tree["exempt"],
        },
        "platform_fit": platform_fit(body, fm),
        "spec": spec,
        "spec_hits": sum(1 for v in spec.values() if v),
        "spec_forbid": spec_forbid,
        "desc_len": len(desc),
    }


def percentile(score, baseline):
    """在 688 技能全库中的百分位（0–100）。"""
    if not baseline:
        return None
    arr = baseline.get("scores_sorted") or []
    if not arr:
        return None
    below = sum(1 for s in arr if s < score)
    return round(100.0 * below / len(arr), 1)


def build_report(res, baseline):
    dims = res["dims"]
    base_avg = (baseline or {}).get("dim_avg") or {}

    pct = percentile(res["score"], baseline)
    # 只把「未满分」的维度算作待补项；满分维度不该出现在待补清单里。
    weak = sorted(((k, v) for k, v in dims.items() if v < 1.0),
                  key=lambda kv: (kv[1], -WEIGHTS[kv[0]]))[:3]

    out = {
        "tool": "skill-preflight",
        "tool_version": "1.2.0",
        "rubric": "D1-D10 加权 v1.0（与 家底总账/eval_skills.py 同口径）",
        "checked_at": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "skill": res,
        "baseline": {
            "n_total": (baseline or {}).get("n_total"),
            "median": _median((baseline or {}).get("scores_sorted")),
            "as_of": (baseline or {}).get("as_of"),
        },
        "percentile": pct,
        "dim_vs_baseline": {
            k: {"skill": dims[k], "baseline_avg": base_avg.get(k),
                "delta": round(dims[k] - base_avg[k], 3) if base_avg.get(k) is not None else None}
            for k in dims
        },
        "weakest": [{"dim": k, "name": DIM_NAME[k], "value": v, "weight": WEIGHTS[k],
                     "fix": FIX_HINT[k]} for k, v in weak],
        "verdict": _verdict(res, pct),
    }
    return out


def _median(arr):
    if not arr:
        return None
    return arr[len(arr) // 2]


def _verdict(res, pct):
    if res["veto"]:
        return "BLOCK · 命中否决项，不得上架（%s）" % "、".join(res["veto"])
    if res["blockers"]:
        return "FIX-FIRST · %d 项阻塞（%s）" % (len(res["blockers"]), "、".join(res["blockers"]))
    if res["tier"] == "A":
        return "PASS · A 档，可直接对外交付"
    if res["tier"] == "B":
        return "PASS · B 档，可用；补强最弱三维更稳"
    if res["tier"] == "C":
        return "HOLD · C 档，需加工后再上架"
    return "BLOCK · D 档"


def render(res, report, baseline):
    L = []
    bs = report["baseline"]
    L.append("=" * 62)
    L.append("skill-preflight · 技能上架体检")
    L.append("=" * 62)
    L.append("技能      : %s" % res["name"])
    L.append("路径      : %s" % res["skill_md"])
    L.append("体量      : %d 行 / %d 字节   frontmatter=%s"
             % (res["lines"], res["bytes"], "有" if res["has_frontmatter"] else "无"))
    L.append("作者/许可 : %s / %s" % (res["author"] or "(无)", res["license"] or "(无)"))
    L.append("")
    L.append("总分      : %.4f   →  %s 档" % (res["score"], res["tier"]))
    if report["percentile"] is not None:
        L.append("全库分位  : 高于 %.1f%% 的技能（基线 %d 个，中位 %s，%s）"
                 % (report["percentile"], bs["n_total"], bs["median"], bs["as_of"]))
    L.append("")
    L.append("-- 逐维（★ = 低于全库均值） --")
    L.append("  %-4s %-12s %-8s %-8s %s" % ("维", "名称", "本技能", "全库均值", "权重"))
    for k in ["D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10"]:
        d = report["dim_vs_baseline"][k]
        mark = "★" if (d["delta"] is not None and d["delta"] < -0.05) else " "
        L.append("  %-4s %-12s %-8s %-8s %s  %s"
                 % (k, DIM_NAME[k], "%.3f" % d["skill"],
                    "%.3f" % d["baseline_avg"] if d["baseline_avg"] is not None else "-",
                    WEIGHTS[k], mark))
    L.append("")
    ts = res.get("tree_scan") or {}
    n_sec = sum((ts.get("secret_shapes") or {}).values())
    n_abs_all = res["flags"]["abs_paths"] + sum((ts.get("abs_paths") or {}).values())
    if n_sec or n_abs_all or ts.get("internal_words") or ts.get("exempt") or ts.get("soft_words"):
        L.append("-- 去敏扫描（全目录，不只 SKILL.md） --")
        if n_sec:
            L.append("  ! 疑似写死密钥形态 ×%d  → 删值并轮换（永不豁免）" % n_sec)
            for f, c in (ts.get("secret_shapes") or {}).items():
                L.append("      文件: %s ×%d" % (f, c))
        if n_abs_all:
            L.append("  · 本地绝对路径 ×%d（内部用可接受，对外件必须清）" % n_abs_all)
            for f, c in (ts.get("abs_paths") or {}).items():
                L.append("      文件: %s ×%d" % (f, c))
        if ts.get("internal_words"):
            L.append("  · 内部敏感词命中文件: %s"
                     % "、".join("%s(%s)" % (f, "、".join(ws))
                                 for f, ws in ts["internal_words"].items()))
        if ts.get("soft_words"):
            L.append("  · 警告级旧口径残留（G4 点名，需人工核）: %s"
                     % "、".join("%s(%s)" % (f, "、".join(ws))
                                 for f, ws in ts["soft_words"].items()))
        if ts.get("exempt"):
            L.append("  · 已按 .preflight-allow 豁免: %s" % "、".join(ts["exempt"]))
        L.append("")
    pf = res.get("platform_fit") or {}
    if pf:
        L.append("-- SkillHub 对齐度（七段式骨架 · 不计入 D1-D10 分，仅为评测对齐参考） --")
        L.append("  章节数 %d  ·  覆盖 %d/7  ·  %s"
                 % (pf.get("sections", 0), len(pf.get("present") or []),
                    pf.get("headline") or ""))
        L.append("  已有: %s" % ("、".join(pf.get("present") or []) or "无"))
        L.append("  缺:   %s" % ("、".join(pf.get("missing") or []) or "无"))
        L.append("")
    sp = res.get("spec") or {}
    if sp:
        L.append("-- 发布规范符合度（《技能打磨规范 v1.0》+《技能包设计规范》· 不计入 D1-D10） --")
        L.append("  达标 %d/%d" % (res.get("spec_hits", 0), len(SPEC_ITEMS)))
        miss = [label for k, label in SPEC_ITEMS if not sp.get(k)]
        L.append("  缺:   %s" % ("、".join(miss) or "无"))
        if res.get("spec_forbid"):
            L.append("  ! 🔴 禁用措辞（虚假背书红线，须删）: %s" % "、".join(res["spec_forbid"]))
        L.append("")
    L.append("-- 该补什么（按拖后腿程度排序，只列 3 条） --")
    for i, w in enumerate(report["weakest"], 1):
        L.append("  %d. %s %s = %.3f（权重 %.2f）" % (i, w["dim"], w["name"], w["value"], w["weight"]))
        L.append("     → %s" % w["fix"])
    if res["flags"]["missing_meta"]:
        L.append("  · frontmatter 缺: %s" % "、".join(res["flags"]["missing_meta"]))
    L.append("")
    L.append("-- 判定 --")
    L.append("  %s" % report["verdict"])
    L.append("  blockers: %s" % ("、".join(res["blockers"]) or "无"))
    L.append("=" * 62)
    return "\n".join(L)


def resolve(path):
    """接受技能目录或 SKILL.md；返回 (root, skill_md)。"""
    p = os.path.abspath(path)
    if os.path.isfile(p):
        return os.path.dirname(p), p
    md = os.path.join(p, "SKILL.md")
    if os.path.exists(md):
        return p, md
    return None, None


def check_one(path, baseline, as_json=False, quiet=False):
    root, md = resolve(path)
    if not md:
        print("[skip] 找不到 SKILL.md: %s" % path, file=sys.stderr)
        return None
    res = grade(root, md)
    report = build_report(res, baseline)
    if as_json:
        print(json.dumps(report, ensure_ascii=False, indent=1))
    elif not quiet:
        print(render(res, report, baseline))
    return report


# ── 内置自查门禁 ────────────────────────────────────────────────
# 由来：同一类缺陷（**语境缺失** —— 把「在讲规则」当成「在使用」、把「说明怎么写」
# 当成「已经具备」）已发 3 次：① wemm「官方推荐(上游版本)」误报 ② 检查器扫自己
# ③ 补 README 时「退出码非 0」被算成有错误码表（S9 5→69 虚增）。
# 按错误台账 3 击规则 → 升级为**硬门禁**：每次 `--selftest` 用内置正/负样本断言规则，
# 失守即 exit 1。不许再靠"记住"。
SELFTEST_CASES = [
    ("真徽章·普通行", "![LGD-Powered](https://x/lgd-powered-en.svg)",
     lambda t: _has_real(t, SPEC_BADGE), True),
    ("真徽章·署名引用块内", "> ![LGD-Powered](https://x/lgd-powered-en.svg)",
     lambda t: _has_real(t, SPEC_BADGE), True),
    ("说明用·反引号包裹", "S4 徽章行（`lgd-powered`）——判据命中即可",
     lambda t: _has_real(t, SPEC_BADGE), False),
    ("说明用·规范对照表", "| # | 条款 | 判据 |\n|---|---|---|\n| S4 | 徽章行 | lgd-powered / lgd-aligned |",
     lambda t: _has_real(t, SPEC_BADGE), False),
    ("内容表格·徽章不豁免", "| 运行时 | 徽章 |\n|---|---|\n| Claude | ![LGD-Powered](https://x/lgd-powered.svg) |",
     lambda t: _has_real(t, SPEC_BADGE), True),
    ("真违规·政策背书", "本技能已获得工信部政策扶持，并纳入专项行动试点单位目录。",
     lambda t: spec_forbidden(t), True),
    ("元语境·规则清单列禁用词", "**🔴 禁用措辞**（红线）：获得支持 / 入选 / 认证 / 官方推荐 / 政策扶持",
     lambda t: spec_forbidden(t), False),
    ("技术写法·上游推荐版本", "transformers 必须钉 5.2.0（官方推荐，新版预处理行为有差异）。",
     lambda t: spec_forbidden(t), False),
    ("词面·句中提退出码不算表", "- **How it's tested**：跑 preflight（不达标时退出码非 0）",
     lambda t: SPEC_ERR.search(t), False),
    ("实质·行首错误码表", "**错误码表**：\n\n| 码 | 含义 |\n|---|---|\n| 2 | 参数错误 |",
     lambda t: SPEC_ERR.search(t), True),
    ("政策声明·唯一合规表述",
     "本技能包契合国家「人工智能+软件」专项行动方向（智能体技能包资源库与规范上架）。",
     lambda t: SPEC_POLICY.search(t), True),
]


def selftest():
    print("skill-preflight 自查门禁 · 豁免规则正/负样本断言")
    print("-" * 64)
    bad = 0
    for name, text, fn, want in SELFTEST_CASES:
        got = bool(fn(text))
        ok = (got == want)
        bad += (not ok)
        print("  %s %-30s 期望=%-5s 实得=%-5s" % ("✅" if ok else "❌", name, want, got))
    print("-" * 64)
    n = len(SELFTEST_CASES)
    print("结果：%d/%d 通过%s" % (n - bad, n,
                                "  ✅ 门禁自检通过" if not bad else "  ❌ 有规则失守，禁止发布"))
    return 0 if not bad else 1


def main():
    ap = argparse.ArgumentParser(description="skill-preflight · 技能上架体检器（零 token / 离线）")
    ap.add_argument("path", nargs="?", help="技能目录 或 SKILL.md 路径")
    ap.add_argument("--json", action="store_true", help="输出机器可读 JSON")
    ap.add_argument("--batch", metavar="DIR", help="批量体检 DIR 下的所有子技能")
    ap.add_argument("--min-tier", choices=["A", "B", "C"], default=None,
                    help="门禁：低于该档则 exit 1")
    ap.add_argument("--min-score", type=float, default=None,
                    help="门禁：低于该分则 exit 1")
    ap.add_argument("--require-publishable", action="store_true",
                    help="门禁：不满足『可对外』则 exit 1")
    ap.add_argument("--g1-file", metavar="FILE",
                    help="外部 G1 敏感词表（商号/C 端名称等，一行一个）。"
                         "刻意不硬编码进代码、不随技能包发布。")
    ap.add_argument("--require-spec", type=int, metavar="N", default=None,
                    help="门禁：发布规范符合度低于 N/10 则 exit 1（规范见 references/rubric.md 五、六节）")
    ap.add_argument("--selftest", action="store_true",
                    help="自查门禁：用内置正/负样本断言豁免规则是否失守（失守 exit 1）")
    args = ap.parse_args()

    if args.selftest:
        return selftest()

    if args.g1_file:
        globals()["_G1_CACHE"] = load_g1_terms(args.g1_file)
        print("[g1] 载入外部词表 %d 条：%s" % (len(_G1_CACHE), args.g1_file), file=sys.stderr)

    baseline = load_baseline()
    if baseline is None:
        print("[warn] 读不到 references/baseline.json，分位功能关闭（分数仍可算）", file=sys.stderr)

    reports = []
    if args.batch:
        base = os.path.abspath(args.batch)
        subs = sorted(d for d in os.listdir(base)
                      if os.path.isdir(os.path.join(base, d, ""))
                      and os.path.exists(os.path.join(base, d, "SKILL.md")))
        if not subs:
            print("在 %s 下没找到含 SKILL.md 的子目录" % base, file=sys.stderr)
            return 2
        rows = []
        for d in subs:
            r = check_one(os.path.join(base, d), baseline, as_json=False, quiet=True)
            if r:
                reports.append(r)
                pf = (r["skill"].get("platform_fit") or {})
                rows.append((r["skill"]["name"], r["skill"]["score"], r["skill"]["tier"],
                             r["percentile"], r["skill"]["publishable"],
                             "%d/7" % len(pf.get("present") or []),
                             "、".join(r["skill"]["blockers"]) or "-"))
        rows.sort(key=lambda x: -x[1])
        # --json 时只输出纯 JSON，避免把人类可读表格混进 stdout 破坏机器解析
        if not args.json:
            print("批量体检：%d 个技能（%s）" % (len(rows), base))
            print("%-32s %7s %4s %7s %5s %5s  %s"
                  % ("技能", "分", "档", "分位", "可对外", "骨架", "阻塞"))
            for n, s, t, p, pub, fit, bl in rows:
                print("%-32s %7.4f %4s %6s%% %5s %6s  %s"
                      % (n[:32], s, t, ("%.0f" % p) if p is not None else "-",
                         "是" if pub else "否", fit, bl[:36]))
        else:
            print(json.dumps(reports, ensure_ascii=False, indent=1))
    else:
        if not args.path:
            ap.print_help()
            return 2
        if os.path.isdir(os.path.abspath(args.path)) and not args.json:
            r = check_one(args.path, baseline)
        else:
            r = check_one(args.path, baseline, as_json=args.json)
        if r is None:
            return 2
        reports.append(r)

    if not reports:
        return 2

    # ---- 门禁
    worst = min(reports, key=lambda r: r["skill"]["score"])
    failed = []
    if args.min_tier:
        want = TIER_ORDER[args.min_tier]
        for r in reports:
            if TIER_ORDER[r["skill"]["tier"]] < want:
                failed.append("档位 %s < %s: %s"
                              % (r["skill"]["tier"], args.min_tier, r["skill"]["name"]))
    if args.min_score is not None:
        for r in reports:
            if r["skill"]["score"] < args.min_score:
                failed.append("分数 %.4f < %.2f: %s"
                              % (r["skill"]["score"], args.min_score, r["skill"]["name"]))
    if args.require_publishable:
        for r in reports:
            if not r["skill"]["publishable"]:
                failed.append("不满足可对外: %s (%s)"
                              % (r["skill"]["name"], "、".join(r["skill"]["blockers"])))
    if args.require_spec is not None:
        for r in reports:
            n = r["skill"].get("spec_hits", 0)
            if n < args.require_spec:
                failed.append("发布规范符合度 %d/%d < %d: %s"
                              % (n, len(SPEC_ITEMS), args.require_spec, r["skill"]["name"]))
    # 🔴 禁用措辞 = 虚假背书红线：任何情况下命中即阻断，无需另开开关
    for r in reports:
        if r["skill"].get("spec_forbid"):
            failed.append("🔴 禁用措辞（虚假背书红线，须删）: %s → %s"
                          % (r["skill"]["name"], "、".join(r["skill"]["spec_forbid"])))
    if failed:
        print("\n[门禁未过] %d 项：" % len(failed), file=sys.stderr)
        for f in failed:
            print("  - " + f, file=sys.stderr)
        return 1

    if (args.min_tier or args.min_score is not None or args.require_publishable
            or args.require_spec is not None):
        print("\n[门禁通过] 最低分 %.4f（%s）" % (worst["skill"]["score"], worst["skill"]["name"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
