# -*- coding: utf-8 -*-
"""从家底总账的 技能评估.json 重新生成 references/baseline.json。

什么时候要重跑：技能库扩容、或 eval_skills.py 的口径改了（权重/判据变化）。
不重跑的话，分位会基于旧快照 —— 分数仍准，但「排第几」会偏。

用法：
  python build_baseline.py --src "<技能评估.json 路径>" [--dst "<输出路径>"]
  默认 dst = <skill-preflight>/references/baseline.json
"""
import io
import os
import sys
import json
import argparse
import collections

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DST = os.path.normpath(os.path.join(HERE, os.pardir, "references", "baseline.json"))

DIM_KEYS = ["D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10"]


def main():
    ap = argparse.ArgumentParser(description="重建 skill-preflight 基线分位文件")
    ap.add_argument("--src", required=True, help="技能评估.json 的路径")
    ap.add_argument("--dst", default=DEFAULT_DST, help="输出路径（默认写到 references/baseline.json）")
    args = ap.parse_args()

    src = os.path.abspath(args.src)
    if not os.path.exists(src):
        print("[err] 找不到 %s" % src, file=sys.stderr)
        return 2

    d = json.load(io.open(src, encoding="utf-8"))
    skills = d["skills"]
    scores = sorted(round(float(s["score"]), 4) for s in skills)

    dim_avg = {}
    for k in DIM_KEYS:
        vals = [float(s["dims"][k]) for s in skills if s.get("dims") and k in s["dims"]]
        dim_avg[k] = round(sum(vals) / len(vals), 4) if vals else None

    tier_counts = collections.Counter(s["tier"] for s in skills)
    own = [s for s in skills if s.get("origin") == "own"]

    out = {
        "schema": "skill-preflight-baseline/1",
        # 只记来源描述，不写本机绝对路径（对外件要干净）
        "generated_from": "家底总账 · 技能本体评估器 eval_skills.py v1.0（全库评估输出）",
        "as_of": d.get("as_of"),
        "n_total": len(skills),
        "n_own": len(own),
        "tier_cutoffs": {"A": 0.80, "B": 0.68, "C": 0.55, "D": 0.0},
        "tier_counts": dict(tier_counts),
        "dim_avg": dim_avg,
        "weights": d["weights"],
        "scores_sorted": scores,
        "own_scores_sorted": sorted(round(float(s["score"]), 4) for s in own),
        "notes": [
            "scores_sorted 为全库技能的分数升序排列，用于算百分位。",
            "同口径：skill-preflight 复现 eval_skills.py 的 D1-D10 加权判据，分数可直接比对。",
            "重建：python scripts/build_baseline.py --src \"<技能评估.json 路径>\"",
        ],
    }

    dst = os.path.abspath(args.dst)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    io.open(dst, "w", encoding="utf-8").write(json.dumps(out, ensure_ascii=False, indent=1))

    print("n_total = %d ｜ n_own = %d" % (len(skills), len(own)))
    print("tier_counts = %s" % dict(tier_counts))
    print("dim_avg = %s" % json.dumps(dim_avg, ensure_ascii=False))
    print("score range = %s ~ %s ｜ median = %s" % (scores[0], scores[-1], scores[len(scores) // 2]))
    print("wrote %s (%d bytes)" % (dst, os.path.getsize(dst)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
