#!/usr/bin/env python3
"""
发布质量门禁 - 四层敏感信息扫描脚本
用法:
  python check_release.py <目标目录或zip> [发布物名称]

四层检查:
  L1 公司敏感信息: 公司名/人名/证号/内部资料
  L2 本机信息:     本机路径/电脑用户名/安装路径
  L3 个人信息:     手机号/邮箱/身份证/微信/QQ/地址
  L4 机密信息:     API密钥/密码/平台账号/内部代号/外部IP

输出: 命中列表 + 误报判定建议，退出码 0=零真实命中 1=有疑似命中
"""

import re
import os
import sys
import json
import zipfile

TEXT_EXTS = {'.md', '.py', '.json', '.txt', '.yml', '.yaml', '.html', '.csv', '.xml', '.ini', '.cfg', '.env'}
BIN_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.webp', '.ico', '.pdf', '.docx', '.xlsx', '.pptx', '.zip'}

# ============ 四层检查模式 ============

LAYERS = {
    "L1 公司敏感信息": {
        "公司名": r'(?i)(?<![是了的在把将为和与及这那每个份该其应可需即则再均如若所并但而使被从对向由])'
                  r'(?![是了的在把将为和与及这那每个份该其应可需即则再均如若所并但而使被从对向由])'
                  r'([\u4e00-\u9fa5]{2,10}(?:有限公司|股份有限公司|集团))',
        "商号疑似": r'([\u4e00-\u9fa5]{2,8}(?:医疗|科技|药业))',
        "人名": r'(?i)([\u4e00-\u9fa5]{2,4}\s*(?:先生|女士|经理|总监|工程师))',
        "证号": r'(?i)([A-Z]{2}[0-9]{6,})',
        "证号词": r'(?i)(注册证号|备案号|营业执照号|统一社会信用代码)',
        "内部资料词": r'(?i)(内部体系文件|客户合同|未公开|机密文件|confidential)',
    },
    "L2 本机信息": {
        "本机路径": r'(?i)(C:[/\\\\]Users[/\\\\]\w+|D:[/\\\\]Workbuddy[/\\\\]\w+|[\/]c[\/]Users[\/]\w+|[\/]home[\/]\w+)',
        "电脑用户名": r'(?i)(desktop-[a-z0-9]+|pc-\w+)',
        "安装路径": r'(?i)(%LOCALAPPDATA%|%APPDATA%|C:[/\\\\]Program Files[/\\\\](?!Ollama))',
    },
    "L3 个人信息": {
        "手机号": r'(?<!\d)1[3-9]\d{9}(?!\d)',
        "邮箱": r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,}',
        "身份证": r'(?<!\d)\d{17}[\dXx](?!\d)',
        "QQ号": r'(?<!\d)[1-9]\d{5,11}(?!\d)',
        "地址": r'(?i)(天津市|北京市|上海市|广东省|深圳市|香港|澳门|滨海新区)[^\s]{0,30}(路|街|道|号|大厦|中心|广场)',
    },
    "L4 机密信息": {
        "API密钥": r'(?i)(sk-[a-zA-Z0-9]{16,}|api[_-]?key\s*[=:]\s*["\']\S{8,}["\']|access[_-]?token\s*[=:]\s*["\']\S{8,}["\']|secret[_-]?key\s*[=:]\s*["\']\S{8,}["\'])',
        "密码": r'(?i)(password|passwd|pwd)\s*[=:]\s*["\']\S{4,}["\']',
        "平台账号": r'(?i)(ima[_-]?mcp|agent[_-]?mail|示例平台账号)',
        "内部代号": r'(?i)(项目代号|内部系统名|内部代号)',
        "凭据落点": r'(?i)(明文[^"\'\\n+]{0,12}(密钥|key|token|凭据|凭证|密码)|(密钥|key|token|凭据|凭证)[^"\'\\n+]{0,12}明文)',
        "外部IP": r'(?<![\d.])(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?![\d.])',
    },
}

# ============ 已知误报（技术参数，非敏感） ============
# 端口号、上下文窗口、MD5、回环地址、通用占位符等

KNOWN_FALSE_POSITIVES = [
    r'localhost:\d+',           # 本地服务端口
    r'127\.0\.0\.1(?::\d+)?',   # 回环地址（含不带端口）
    r'0\.0\.0\.0',              # 全零地址
    r'11434',                   # Ollama 默认端口
    r'\b(8192|16384|32768|65536)\b',  # 上下文窗口
    r'[a-f0-9]{32}',            # MD5
    r'[0-9]{4}-[0-9]{2}-[0-9]{2}',   # 日期
    r'qwen2\.5[:0-9a-z.]+',     # 模型名
    r'deepseek[-\w:.]*',        # 模型名
    r'\bGMP-\d{4}\b',           # 法规年份
    r'ISO\s?13485',             # 标准号
]

# ============ 品牌豁免（公开品牌，有意保留） ============
# 发布者公开的公司品牌/作者品牌，出现在发布物中是有意的品牌曝光，不算泄露。
# 命中这些词 → 列为"品牌确认"而非风险。
BRAND_NAMES = ["注册老炮"]

# ============ 作者署名豁免 ============
# 发布者有意保留的作者署名（建立实名可信度），不算泄露。
# 命中这些名字且出现在 author/作者/署名 上下文中 → 列为"署名确认"而非风险。
AUTHOR_NAMES = ["注册老炮"]


def is_author_credit(hit):
    """判断命中是否为作者署名或公开品牌（有意保留）"""
    # 公开品牌豁免（如作者品牌、公开署名，有意保留）
    matched_lower = hit['matched'].lower()
    if any(brand.lower() in matched_lower for brand in BRAND_NAMES):
        return True
    ctx = hit['snippet'].lower()
    if any(brand.lower() in ctx for brand in BRAND_NAMES):
        if any(kw in ctx for kw in ['注册老炮', '"name"', 'author', '作者', '署名', '版权', '©']):
            return True
    # 作者署名豁免
    if hit['type'] != '人名':
        return False
    # 命中值本身是作者名
    if any(name.lower() in matched_lower for name in AUTHOR_NAMES):
        return True
    # 上下文含署名语义
    if any(name.lower() in ctx for name in AUTHOR_NAMES):
        if any(kw in ctx for kw in ['"name"', 'author', '作者', '署名', '原创', '整理']):
            return True
    return False


def is_false_positive(hit_text):
    """判断命中是否为已知技术参数误报"""
    return any(re.search(pat, hit_text, re.IGNORECASE) for pat in KNOWN_FALSE_POSITIVES)


# ============ 规则文本型误报（2026-11-11 实跑修正） ============
# 一个文件若本身就在"列举禁止出现的词"，正文必然含这些词，会被自己的词表命中。
# 这类命中是"规则/示例"，不是泄漏值，降级为提示，不影响退出码。

# 这些类型匹配的是"类别词"而不是"具体值"（如 未公开 / 内部代号 四个字本身）。
# 真正泄漏的会是某个具体代号或文件名，所以这些命中只作提醒。
GENERIC_LABEL_TYPES = {"内部代号", "内部资料词", "证号词"}

# 弱判据：单靠后缀"医疗/科技/药业"无法区分商号与普通叙述（"汇编与生成医疗器械"也会命中）。
# 一律降为提示，不影响退出码；带"有限公司/集团"这类强后缀的仍走 HIT。
ADVISORY_TYPES = {"商号疑似"}

RULE_MARKERS = (
    "r'", 'r"', "re.compile", "PATTERNS", "SENSITIVE_WORDS", "LAYERS =",
    "BANNED", "FORBIDDEN", "禁用词", "敏感词", "脱敏", "规则", "示例",
    "判据", "检测", "扫描",
)

HEX = "0123456789abcdefABCDEF"


def line_of(content, pos):
    ls = content.rfind("\n", 0, pos) + 1
    le = content.find("\n", pos)
    return content[ls:(le if le != -1 else len(content))]


def is_rule_text(content, m, pname):
    """命中行是否属于"规则/示例文本"，而非真实值。"""
    line = line_of(content, m.start())
    # 1) 占位符写法（<内部代号> / {…} / ……）
    if re.search(r"<[^<>]{1,20}>", line) or "…" in line:
        return True
    # 2) 正则字面量 / 词表定义行
    if any(mk in line for mk in RULE_MARKERS):
        return True
    # 3) 类别词命中（它们本身就是类别名，不是值）
    if pname in GENERIC_LABEL_TYPES:
        return True
    # 3b) 弱判据命中（仅提示）
    if pname in ADVISORY_TYPES:
        return True
    # 4) "凭据落点"：若同一行带否定/规劝语气，是在讲规矩，不是在报位置
    if pname == "凭据落点":
        if re.search(r"(?i)(不得|禁止|不要|勿|不应|避免|一律不要|not\s+write)", line):
            return True
    # 5) 密钥占位写法：一串同样的 x/X/* 不是真密钥
    if pname == "API密钥":
        core = re.sub(r"(?i)^(sk-|x)", "", m.group(0))
        if core and set(core) <= set("xX*0123456789"):
            return True
    return False


def digits_in_hex_run(content, m):
    """命中数字是否被夹在一长串十六进制里（哈希/摘要的数字子串）。"""
    a, b = m.start(), m.end()
    l = a
    while l > 0 and content[l - 1] in HEX:
        l -= 1
    r = b
    while r < len(content) and content[r] in HEX:
        r += 1
    run = r - l
    # 整段连续十六进制 ≥12 位，基本可判定为哈希/摘要（真实账号不会长成这样）
    return run >= 12


def contextual_exempt(pname, content, m):
    """按上下文排查结构型误报（2026-11-11 实跑修正）

    1) DOI/zenodo 标识里的纯数字，不是 QQ 号；
    2) 检测器自身的敏感词定义行（SENSITIVE_WORDS / 敏感词表），不是泄密。
    """
    ctx = content[max(0, m.start() - 40):min(len(content), m.end() + 40)]
    if pname == "QQ号":
        if re.search(r"(?i)(doi|zenodo|10\.5281|10\.\d{4})", ctx):
            return True
        # 8 位日期（YYYYMMDD）不是 QQ 号
        if re.fullmatch(r"(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|1[0-9]|2[0-9]|3[0-1])", m.group(0)):
            return True
    if pname == "内部代号":
        ls = content.rfind("\n", 0, m.start()) + 1
        le = content.find("\n", m.end())
        line = content[ls:(le if le != -1 else len(content))]
        if re.search(r"(?i)(SENSITIVE_WORDS|WORDS\s*=|\bKEYWORDS\b|敏感词|黑名单|BANNED|FORBIDDEN)", line):
            return True
        # 术语表/定义行：同一行列举 ≥3 个禁用术语，属规则说明而非泄密
        terms = sum(1 for t in ("护城河", "内部战略", "内部代号", "不对外的", "勿外传", "仅内部") if t in line)
        if terms >= 3:
            return True
    if pname == "QQ号":
        # 命中被夹在十六进制串里（SHA-256 / MD5 的数字子串）
        if digits_in_hex_run(content, m):
            return True
        # 命中落在 URL / 标准号 / 日期组合里
        ctx40 = content[max(0, m.start() - 40):min(len(content), m.end() + 40)]
        if re.search(r"(?i)(http|www\.|iso\s?\d|ilac|ansi|ieee|gb/?t|yy/?t|\.org|\.gov)", ctx40):
            return True
    return False



def _redact(s):
    """输出脱敏：把本机绝对路径替换为占位符，避免日志泄露本机布局。"""
    if not isinstance(s, str):
        return s
    s = re.sub(r"(?i)[A-C]:\\?[^\\s'\")]*", "<本机路径>", s)
    s = re.sub(r"/Us[er]{2}/[^\s'\")]+", "<本机路径>", s)
    return s

def scan_text(name, content):
    """扫描单文件文本内容，返回命中列表"""
    hits = []
    for layer, patterns in LAYERS.items():
        for pname, pat in patterns.items():
            for m in re.finditer(pat, content):
                start = max(0, m.start() - 25)
                end = min(len(content), m.end() + 25)
                snippet = content[start:end].replace('\n', ' ')
                line_no = content[:m.start()].count('\n') + 1
                reason = None
                if is_false_positive(snippet) or contextual_exempt(pname, content, m):
                    reason = "技术参数"
                elif is_rule_text(content, m, pname):
                    reason = "规则/示例文本"
                hits.append({
                    'layer': layer,
                    'type': pname,
                    'file': name,
                    'line': line_no,
                    'snippet': snippet,
                    'matched': m.group(0)[:60],
                    'false_positive': reason is not None,
                    'fp_reason': reason,
                })
    return hits


def scan_path(path, label_prefix=""):
    """扫描文件或目录，返回命中列表"""
    hits = []
    if os.path.isfile(path):
        ext = os.path.splitext(path)[1].lower()
        if ext in TEXT_EXTS:
            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                hits += scan_text(label_prefix + os.path.basename(path), content)
            except Exception:
                pass
        return hits

    for root, dirs, files in os.walk(path):
        # 跳过隐藏目录和临时目录
        dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ('node_modules', '__pycache__')]
        for f in files:
            full = os.path.join(root, f)
            ext = os.path.splitext(f)[1].lower()
            if ext in TEXT_EXTS:
                try:
                    with open(full, 'r', encoding='utf-8', errors='ignore') as fh:
                        content = fh.read()
                    rel = os.path.relpath(full, path)
                    hits += scan_text(rel, content)
                except Exception:
                    pass
    return hits


def scan_zip(zip_path):
    """扫描 zip 内文本内容"""
    hits = []
    try:
        with zipfile.ZipFile(zip_path) as zf:
            for name in zf.namelist():
                ext = os.path.splitext(name)[1].lower()
                if ext in TEXT_EXTS:
                    try:
                        content = zf.read(name).decode('utf-8', errors='ignore')
                        hits += scan_text(name, content)
                    except Exception:
                        pass
    except Exception as e:
        print(f"[!] 无法读取 zip: {e}")
    return hits


def load_baseline(path):
    """加载基线豁免表。

    结构：{"entries": [{"file": "...", "type": "...", "matched": "...",
                        "reason": "...", "reviewer": "...", "date": "..."}]}
    匹配键 = (file, type, matched)。基线文件放在**被扫目录之外**，否则它自己会被扫到。
    """
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return {}
    out = {}
    for e in data.get("entries", []):
        key = (e.get("file", ""), e.get("type", ""), e.get("matched", ""))
        out[key] = e
    return out


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)

    args = [a for a in sys.argv[1:]]
    baseline_path = None
    if "--baseline" in args:
        i = args.index("--baseline")
        baseline_path = args[i + 1] if i + 1 < len(args) else None
        del args[i:i + 2]

    target = args[0]
    label = args[1] if len(args) > 1 else os.path.basename(target)

    print(f"🔍 四层敏感信息扫描: {label}")
    print(f"   目标: {_redact(target)}\n")

    all_hits = []
    if os.path.isdir(target):
        all_hits = scan_path(target)
    elif zipfile.is_zipfile(target):
        all_hits = scan_zip(target)
    else:
        all_hits = scan_path(target)

    # 汇总
    real_hits = [h for h in all_hits if not h['false_positive'] and not is_author_credit(h)]
    credit_hits = [h for h in all_hits if not h['false_positive'] and is_author_credit(h)]
    fp_hits = [h for h in all_hits if h['false_positive']]

    # 基线豁免：已人工复核为良性、带理由留档的命中，不参与退出码
    baseline = load_baseline(baseline_path)
    baselined = []
    if baseline:
        remaining = []
        for h in real_hits:
            key = (h['file'].replace(os.sep, '/'), h['type'], h['matched'])
            if key in baseline:
                baselined.append((h, baseline[key]))
            else:
                remaining.append(h)
        real_hits = remaining

    # 按层分组统计
    layer_stats = {}
    for h in real_hits:
        layer_stats.setdefault(h['layer'], []).append(h)

    print("=" * 60)
    print("扫描结果统计:")
    for layer in LAYERS:
        n = len(layer_stats.get(layer, []))
        status = "✅ 零命中" if n == 0 else f"⚠️ {n} 个疑似命中"
        print(f"  {layer}: {status}")
    print(f"  已知技术参数误报（自动排除）: {len([h for h in fp_hits if h.get('fp_reason') == '技术参数'])} 个")
    rule_fp = len([h for h in fp_hits if h.get('fp_reason') == '规则/示例文本'])
    if rule_fp:
        print(f"  规则/示例文本误报（自动排除）: {rule_fp} 个   ← 文件本身在列举禁用词，不是泄漏")
    if baselined:
        print(f"  基线豁免（已复核留档，不参与退出码）: {len(baselined)} 个")
    if not baseline_path:
        pass
    if credit_hits:
        print(f"  作者署名/公开品牌（有意保留，需确认）: {len(credit_hits)} 个")
    print("=" * 60)

    if not real_hits:
        print("\n✅ 四层检查通过（无真实敏感信息泄露）!")
        if credit_hits:
            print(f"\n📝 另发现 {len(credit_hits)} 处作者署名/公开品牌（如 注册老炮），请确认是有意保留的:")
            for h in credit_hits:
                print(f"  - {h['file']}:{h['line']}: {h['matched']}")
        sys.exit(0)

    # 打印疑似命中，供人工复核
    print(f"\n⚠️ 发现 {len(real_hits)} 个疑似敏感信息（需人工逐条复核）:\n")
    for i, h in enumerate(real_hits, 1):
        print(f"--- [{h['layer']} / {h['type']}] ---")
        print(f"  文件: {h['file']}:{h['line']}")
        print(f"  命中: {_redact(h['matched'])}")
        print(f"  上下文: ...{_redact(h['snippet'])}...")
        print()

    if credit_hits:
        print(f"📝 另发现 {len(credit_hits)} 处作者署名/公开品牌（有意保留，需确认）:\n")
        for h in credit_hits:
            print(f"  - [{h['layer']} / {h['type']}] {h['file']}:{h['line']}: {h['matched']}")
        print()

    print("=" * 60)
    print("复核建议:")
    print("  1. 逐条判断是真实敏感信息还是误报（已自动排除端口/MD5/回环等常见误报）")
    print("  2. 真实命中 → 脱敏修改 → 重新打包 → 重新扫描直到零命中")
    print("  3. 注意: 二进制图片(png等)的正则命中几乎都是误报，跳过即可")
    sys.exit(1)


if __name__ == "__main__":
    main()
