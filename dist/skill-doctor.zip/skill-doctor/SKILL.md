---
x-theory: "LGD-Lifecycle-Governance-Doctrine-v1.0"
copyright: "赵兴华（Steven Zhao）"
x-brand: "SynomosAI"
x-agent-seat: "无"
x-attribution: "Xinghua Zhao"
license: "MIT"
agent_created: true
  x-author-legacy: "赵兴华/Steven Zhao"
  x-attribution: "Xinghua Zhao"
  x-brand: "SynomosAI"
  x-agent-seat: "无"
  copyright: "赵兴华（Steven Zhao）"
name: skill-doctor
author: "赵兴华（Steven Zhao）"
version: 1.0.0
description: 已装 Skill 的体检与选型器。当需要盘点本机或某个技能根下的技能、判断哪些技能可用/断链/空壳/重复、给技能分级排序、查召回冲突、新增技能前先查重，或回答“这些技能哪几个最好、能不能用”时使用。覆盖 .skills、.user_skills、Doubao\skills、.agents\skills 多个根。触发词：技能体检、技能盘点、哪些技能能用、断链、空壳、重复技能、召回冲突、技能分级、加技能前查重、打包技能。
x-shelf: flagship
x-signature-line: B
read_when:
- 要盘点本机或某个根下的技能，判断哪些能用
- 要查技能断链 / 空壳 / 跨根重复 / 召回冲突
- 要新增技能前先查重
- 要把一个技能打成可上传的 ZIP

display_name_en: "Skill Doctor"
description_en: "Audits installed skills and tells you which actually work: usable, broken, empty shell or duplicate, ranked by grade; detects recall conflicts and checks for duplicates before you add a new skill. Use to answer 'which skills are worth keeping'."
---

# Skill Doctor

体检已装 Skill：体量分级、断链、跨根重复、召回冲突、空壳、规范符合性、召回模拟、打包。除打包外全程只读。

## 四个脚本

| 脚本 | 干什么 | 命令 |
|---|---|---|
| `skill_doctor.py` | 体量/断链/重复/召回冲突/空壳体检，出 md+json | `python scripts/skill_doctor.py --md r.md --json r.json` |
| `spec_lint.py` | 按 Agent Skills 开放规范查 frontmatter 与正文 | `python scripts/spec_lint.py [--path <技能目录>]` |
| `route_sim.py` | 用真实说法模拟召回，看 description 措辞覆盖够不够 | `python scripts/route_sim.py --queries cases.txt` |
| `pack_skill.py` | 打成可上传 ZIP（根即技能名目录，剔缓存与冗余文档） | `python scripts/pack_skill.py --skill <目录> --out x.zip` |

脚本按自身位置自动定位四个标准根：`<workspace>/.skills`、`<workspace>/.user_skills`、`~/Doubao/skills`、`~/.agents/skills`；其它根用 `--root <路径>` 追加，可重复。
退出码：0 无硬问题 / 1 有硬问题 / 2 找不到技能根。

## 五项判据

| 项 | 判据 | 命中后 |
|---|---|---|
| 分级 | A：≥100KB 且 ≥10 文件；B：≥30KB 或 ≥8 文件；C：其余；D：SKILL.md <3KB 且 ≤3 文件 | A 类日常优先；D 类视作占位 |
| 断链 | 反引号路径指向分发目录（scripts/references/assets/templates/cli 等）但文件不存在 | 改路径或删引用 |
| 待核 | 裸文件名（无目录前缀）且同行出现“见/参见/references/” | 人工看一眼，不必然是断链 |
| 重复 | frontmatter name 相同，或 SKILL.md 三行 shingle Jaccard ≥0.60 | 留母版，另一份归档 |
| 召回冲突 | description 去停用词后 CJK 双字 + 英文词的 Jaccard ≥0.30 | 加区分词，不靠目录名 |

阈值与误判清单见 `references/health-rubric.md`。

## 规范符合性（spec_lint）

判据取 Agent Skills 开放规范：`name` ≤64 字符且仅小写字母/数字/连字符、不含保留词；`description` 非空 ≤1024 字符、不含 XML 标签、须写清“做什么 + 何时用”；frontmatter 仅允许 `name/description/license/allowed-tools/metadata/dependencies`；正文 <500 行；`references/` 下 >100 行的文件开头要有目录；正文用祈使句、避免第二人称与年份式时效表述。

ERROR 才阻断（不合规必改）；WARN 是风格提示。两类规则要会区分：
- `/page/<token>` 这类反引号里的路径模板不是 XML 标签，先剔除再判。
- 出处/署名行里的年份（`©`、`attribution`、`沉淀自`、`License`）是证据不是时效风险，不报。

## 召回模拟（route_sim）

指标是“查询措辞有多少比例能在该技能 description/name 里字面找到”，IDF 加权，避免用描述长短当信号。

- `--queries` 文件每行写「用户会说的原话<TAB>期望技能」，比对第一名是否命中。
- `--root` 指定技能根（可重复，给了就只扫这些根）：把候选 description 放进沙箱目录先测，确认能赢再改正式文件。平台托管件只能这样验证，不能就地改。
- `--min-score` 控低覆盖阈值（默认 0.5）；`--debug` 打印命中/缺失词元，用来核对分数是否可信。
- 未给期望时，低覆盖判 LOW：说明 description 缺用户会说的那个词，实跑时只能靠语义猜。

**边界**：这是字面覆盖，不是语义召回。高分不等于一定被选中，低分也不等于一定选不中；它只用来暴露“书面词 vs 口语词”的同义缺口（如“去除”对“去掉”、“表格”对“把数据做成表格”）。词元归一化必须吃掉字母与数字之间的空格（`ISO 14971` ≈ `ISO14971`），否则标准号类说法永远命中 0。描述只有英文、用户说中文时，覆盖会直接掉到 0——这是实测里最容易漏的一类。

## 打包（pack_skill）

ZIP 内层必须是 `<技能名>/` 作为根，不能是散文件——平台上传按这个结构识别技能。脚本会剔除 `.git`、`__pycache__`、`.workflow` 与 README/CHANGELOG/INSTALLATION_GUIDE/QUICK_REFERENCE（规范明令不要这些冗余文档，需要保留加 `--keep-docs`），打完回读 ZIP 校验所有条目都在技能根下。

## 怎么读报告

1. 先处理硬问题：断链改引用、重复归档残件、空壳补齐或下线。
2. 再看召回冲突：这不是错误而是风险，同族技能要在 description 里写清“对象 + 产物形态”的差异。
3. 最后看分级表：A 类是重交付引擎（大类文档/设计/医疗/表格），C/D 类多是一次性占位，真实任务不要依赖。

## 判定纪律

- 只有“指向分发目录且递归找不到同名文件”才算断链；运行期产物（`report.json`、`.workflow/*.json`）、示例名、CLI 参数、URL、含 `vN`/`_N`/`xxx` 的模板名一律剔除。
- 跨技能引用（`../兄弟技能/references/x.md`）按真实路径核对，不按字面并入本技能目录。
- 同名跨根副本先比目录内容再比名字：带 tests/scripts 的那份才是母版。
- 报告只读，脚本不自动删。要处置时把副本移入 `workspace/.skills-archive/<YYYY-MM-DD>/`，保留可回滚路径。

## 边界

- 只管技能根（含 SKILL.md 的目录）。插件（plugins）由平台下发，本机一般没有安装入口，不要承诺“装新插件”。
- 分级是体量与资产厚度的代理指标，不等于质量；引用它时说明判据，不宣称“最好”。
- 平台托管目录（`.skills`）的改动可能被平台回滚，结论里给出改法即可，别承诺“已改平台技能”。
- 上游仓库快照类技能（目录名带 `-master-<sha>`）改了 description 会被再同步覆盖：要么把改动推回上游，要么在同步流程里补一步，别只改本地就说“已修好”。

## 何时不用（out of scope）

- 要**评价某个技能写得好不好、值不值得买**：这不是体检，属评审；本件只给结构面事实（体量、断链、重复、召回覆盖），不给质量结论。
- 要**改平台托管技能并保证不被回滚**：本件做不到，只能给改法。
- 要**语义召回实测**（选中的概率）：`route_sim` 只测字面覆盖，语义召回要用真实调用日志。
- 想**让脚本自动删技能**：本件不删，只报。

## 红线（不得做）

- **不得**把"分级低"直接说成"不能用"：C/D 级只表示体量薄，是否可用要看脚本能否跑通。
- **不得**静默删除或移动他人技能：处置一律移到 `workspace/.skills-archive/<日期>/` 并给出回滚路径。
- **不得**只报告总数不给出逐件证据：每条结论必须能追到具体路径与判据行。
- **严禁**在报告里写入凭证、密钥或本机绝对路径以外的敏感落点；报告对外前先脱敏。
- **绝不**把"没查到硬问题"写成"已认证合格"：本件是体检，不是认证。

## 跑一次看看

```bash
python scripts/skill_doctor.py --md report.md --json report.json
python scripts/spec_lint.py --path <技能目录>
```

第一条预期 current 目录下生成两份报告、exit 0（无硬问题）；第二条按开放规范逐项列 ERROR/WARN，`ERROR` 才阻断。判据阈值机器可读版见 `assets/grade-thresholds.json`，召回模拟的输入模板见 `assets/queries-template.txt`。

