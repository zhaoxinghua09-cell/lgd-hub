# evidence-chain-suite

四段证据链：建链、查链、可追溯审计、长期留痕。

- 版本线：lgd-hub rev H
- 许可：MIT（包内 LICENSE.txt 为全文；引用请保留署名 Xinghua Zhao）
- 包内文件：7 个，解压后约 0.02 MB
- `SKILL.md` 的 SHA-256：`857ddde056c3a49e24bff3be7820ed6878056fa7cfec42b76ef10e1f8144726c`

## 安装

```bash
unzip evidence-chain-suite.zip -d ~/.claude/skills/     # 或你的 agent 技能目录
```

装完即可用；无依赖、不联网、不调模型。入口：`scripts/chain_verify.py`。

## 自己核一遍

```bash
sha256sum SKILL.md            # 应等于上面那一行
python scripts/chain_verify.py --json         # 机器可读；本件自身也可作为样本
```

哈希对不上就**先报这个**，别先报内容问题——对不上说明你拿到的不是这一版。

## 界线

本包自跑、非认证。评分出自公开加权的判据，判据自身的已知缺陷写在 https://zhaoxinghua09-cell.github.io/lgd-hub/EVAL.md
（我们选择公开而不修）。发现不一致、或不服某个数，走 https://zhaoxinghua09-cell.github.io/lgd-hub/FEEDBACK.md：
7 天内进表，30 天内给结论，结论只有采纳 / 驳回 / 存疑。
