#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""skill_doctor.py — 已装 Skill 的体检器。

检查项：frontmatter 完整性 / 体量与资产分级 / 断链（递归 basename 核对）/
跨根重复（SKILL.md 3 行 shingle 的 Jaccard）/ 空壳 / description 召回冲突。

用法：
  python skill_doctor.py
  python skill_doctor.py --root D:\\a --root D:\\b
  python skill_doctor.py --md report.md --json report.json
退出码：0 = 无硬问题；1 = 存在断链/重复/空壳/缺 frontmatter；2 = 找不到任何技能根
"""
import argparse
import json
import os
import re
import sys

SKILL_FILE = "SKILL.md"
REF_EXT = r"(?:md|py|sh|ps1|js|mjs|json|yaml|yml|txt|csv|html)"
REF_RE = re.compile(r"`([^`\n]+?\.%s)`" % REF_EXT)
SKIP_DIRS = {".git", ".pytest_cache", "__pycache__", ".workflow", "node_modules"}
# 只有指向这些“随技能一起分发”的目录，缺文件才算真断链
SHIPPED_DIRS = {
    "scripts", "script", "references", "reference", "assets", "asset",
    "templates", "template", "elements", "branches", "evals", "scenes",
    "sub-skills", "cli", "agents", "config",
}
# 这些词在同一行出现时，裸文件名才被当作“文档引用”而非运行期产物
SEE_HINTS = ("见 `", "参见", "详见", "阅读 `", "references/", "模板")
OUT_HINTS = ("输出", "落盘", "生成", "写入", "产物", "示例", "例如", "would be", "would help",
             "example", "examples", "output", "e.g.")
STOP_TOKENS = {
    "技能", "使用", "用户", "支持", "处理", "生成", "创建", "编辑", "分析",
    "相关", "需要", "可以", "以及", "包括", "覆盖", "内容", "输出",
}


def default_roots():
    here = os.path.abspath(__file__)                     # <.user_skills>/skill-doctor/scripts/
    skill_dir = os.path.dirname(os.path.dirname(here))   # <.user_skills>/skill-doctor
    user_root = os.path.dirname(skill_dir)               # <.user_skills>
    workspace = os.path.dirname(user_root)               # .../workspace
    home = os.path.expanduser("~")
    return [
        os.path.join(workspace, ".skills"),
        user_root,
        os.path.join(home, "Doubao", "skills"),
        os.path.join(home, ".agents", "skills"),
    ]


def parse_frontmatter(text):
    fm = {}
    if not text.startswith("---"):
        return fm
    end = text.find("\n---", 3)
    block = text[3:end] if end > 0 else text[3:]
    key = None
    for line in block.splitlines():
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_-]*):\s*(.*)$", line)
        if m:
            key = m.group(1).lower()
            fm[key] = m.group(2).strip().strip("\"'")
        elif key and line.strip() and line.startswith((" ", "\t")):
            fm[key] = (fm.get(key, "") + " " + line.strip()).strip()
    return fm


def walk_skill_dir(d):
    names, files, nbytes, topdirs = set(), 0, 0, set()
    for dp, dn, fn in os.walk(d):
        dn[:] = [x for x in dn if x not in SKIP_DIRS]
        rel = os.path.relpath(dp, d)
        if rel != ".":
            topdirs.add(rel.split(os.sep)[0])
        for f in fn:
            names.add(f.lower())
            files += 1
            try:
                nbytes += os.path.getsize(os.path.join(dp, f))
            except OSError:
                pass
    return names, files, nbytes, topdirs


def check_refs(md, names, skill_dir):
    """返回 (confirmed, unverified)。confirmed = 指向分发目录但文件不存在；unverified = 裸文件名待核。"""
    confirmed, unverified = [], []
    for line in md.splitlines():
        for raw in REF_RE.findall(line):
            ref = raw.strip()
            if any(c in ref for c in "*<>{}") or "://" in ref:
                continue
            for tok in ref.split():
                tok = tok.strip("\"'").lstrip("@")
                if not tok or tok.startswith("-") or tok.startswith("~") or tok.startswith("./"):
                    continue
                if re.match(r"^[A-Za-z]:", tok) or re.search(r"(?i)(vN\b|_N\b|xxx|SEG\d)", tok):
                    continue
                if "兄弟技能" in tok or "<" in tok:
                    continue
                if re.search(r"(?i)(^|[\\/])([A-Za-z]{1,2})\.(md|json|py|txt|yaml|yml)$", tok):
                    continue
                if not re.search(r"\.%s$" % REF_EXT, tok, re.I):
                    continue
                if "/" in tok or "\\" in tok:
                    segs = re.split(r"[\\/]", tok)
                    if segs[0] in ("..", "."):
                        p = os.path.normpath(os.path.join(skill_dir, tok))
                        if not os.path.exists(p):
                            confirmed.append(tok)
                        continue
                    if segs[0].lower() not in SHIPPED_DIRS:
                        continue
                    if os.path.basename(tok).lower() not in names:
                        # 行内带“示例/输出”语义的，降级为待核，不判死
                        low = line.lower()
                        (unverified if any(o.lower() in low for o in OUT_HINTS) else confirmed).append(tok)
                    continue
                base = tok.lower()
                if base in names:
                    continue
                if base.endswith(".md") and any(h in line for h in SEE_HINTS) \
                        and not any(o in line for o in OUT_HINTS):
                    unverified.append(tok)
    return sorted(set(confirmed)), sorted(set(unverified))


def shingles(md):
    lines = [l.strip() for l in md.splitlines() if l.strip()]
    return {" ".join(lines[i:i + 3]) for i in range(len(lines) - 2)}


def desc_tokens(desc):
    d = re.sub(r"[（(][^）)]*[）)]", "", desc or "")
    toks = {w.lower() for w in re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}", d)}
    for seg in re.findall(r"[\u4e00-\u9fff]+", d):
        for i in range(len(seg) - 1):
            toks.add(seg[i:i + 2])
    return toks - STOP_TOKENS


def tier_of(nbytes, files, md_bytes):
    if files <= 1 and md_bytes < 3000:
        return "D"
    if files <= 2 and md_bytes < 2600:
        return "D"
    if nbytes >= 100 * 1024 and files >= 10:
        return "A"
    if nbytes >= 30 * 1024 or files >= 8:
        return "B"
    return "C"


def load_skills(roots):
    skills, seen_roots = [], []
    for root in roots:
        if not os.path.isdir(root):
            continue
        seen_roots.append(root)
        for name in sorted(os.listdir(root)):
            d = os.path.join(root, name)
            p = os.path.join(d, SKILL_FILE)
            if not (os.path.isdir(d) and os.path.isfile(p)):
                continue
            md = open(p, encoding="utf-8", errors="replace").read()
            fm = parse_frontmatter(md)
            names, files, nbytes, topdirs = walk_skill_dir(d)
            cf, uv = check_refs(md, names, d)
            skills.append(dict(
                dir=name, root=root, path=d,
                fm_name=fm.get("name", ""), desc=fm.get("description", ""),
                md_bytes=len(md.encode("utf-8")), files=files, bytes=nbytes,
                topdirs=sorted(topdirs),
                has_scripts=any(t.lower() in ("scripts", "script") for t in topdirs),
                has_refs=any(t.lower().startswith("reference") for t in topdirs),
                has_assets=any(t.lower() == "assets" for t in topdirs),
                missing=cf,
                unverified=uv,
                _sh=shingles(md), _tok=desc_tokens(fm.get("description", "")),
            ))
    return skills, seen_roots


def detect_dups(skills):
    pairs = []
    for i in range(len(skills)):
        for j in range(i + 1, len(skills)):
            a, b = skills[i], skills[j]
            if a["name_key"] == b["name_key"] or (a["fm_name"] and a["fm_name"] == b["fm_name"]):
                pairs.append((1.0, "同 frontmatter name", a, b))
                continue
            if not a["_sh"] or not b["_sh"]:
                continue
            inter = len(a["_sh"] & b["_sh"])
            if inter < 20:
                continue
            jac = inter / len(a["_sh"] | b["_sh"])
            if jac >= 0.60:
                pairs.append((jac, "SKILL.md 正文重复", a, b))
    return sorted(pairs, key=lambda x: -x[0])


def detect_trigger_overlap(skills, threshold=0.30, limit=8):
    pairs = []
    for i in range(len(skills)):
        for j in range(i + 1, len(skills)):
            a, b = skills[i], skills[j]
            if not a["_tok"] or not b["_tok"]:
                continue
            jac = len(a["_tok"] & b["_tok"]) / len(a["_tok"] | b["_tok"])
            if jac >= threshold:
                pairs.append((jac, a, b))
    return sorted(pairs, key=lambda x: -x[0])[:limit]


def render_md(skills, dup_pairs, trig_pairs, roots, hard):
    lines = ["# 技能体检报告", ""]
    lines.append("- 生成时间：%s" % __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    lines.append("- 扫描根：")
    for r in roots:
        lines.append("  - `%s`" % r)
    lines.append("- 有效技能：**%d**" % len(skills))
    lines.append("- 硬问题：**%d**（断链 %d / 重复 %d / 空壳 %d / 缺字段 %d）" % (
        len(hard),
        sum(1 for h in hard if h[0] == "断链"),
        sum(1 for h in hard if h[0] == "重复"),
        sum(1 for h in hard if h[0] == "空壳"),
        sum(1 for h in hard if h[0] == "缺字段")))
    lines.append("")
    lines.append("## 一、分级")
    lines.append("")
    lines.append("| 分级 | 技能 | 体量 | 文件 | 资产 |")
    lines.append("|---|---|---|---|---|")
    for s in sorted(skills, key=lambda x: (x["tier"], -x["bytes"])):
        assets = ",".join(x for x in (
            ("scripts" if s["has_scripts"] else ""),
            ("references" if s["has_refs"] else ""),
            ("assets" if s["has_assets"] else "")) if x) or "-"
        lines.append("| %s | %s | %dKB | %d | %s |" % (
            s["tier"], s["dir"], s["bytes"] // 1024, s["files"], assets))
    lines.append("")
    lines.append("## 二、硬问题")
    lines.append("")
    if not hard:
        lines.append("无。")
    else:
        for kind, detail in hard:
            lines.append("- **[%s]** %s" % (kind, detail))
    lines.append("")
    lines.append("## 三、待核引用（裸文件名，可能是示例或运行期产物，人工确认一次即可）")
    lines.append("")
    uv = [(s["dir"], s["unverified"]) for s in skills if s["unverified"]]
    if not uv:
        lines.append("无。")
    else:
        for d, refs in uv:
            lines.append("- %s：%s" % (d, " | ".join(refs[:6])))
    lines.append("")
    lines.append("## 四、召回冲突候选（description 用词重叠 ≥30%）")
    lines.append("")
    if not trig_pairs:
        lines.append("无。")
    else:
        lines.append("| 重叠度 | A | B |")
        lines.append("|---|---|---|")
        for jac, a, b in trig_pairs:
            lines.append("| %.2f | %s | %s |" % (jac, a["dir"], b["dir"]))
    lines.append("")
    lines.append("## 五、处置建议")
    lines.append("")
    lines.append("1. 断链：改路径或删引用；运行期产物名不要写成反引号引用。")
    lines.append("2. 重复：保留带 scripts/tests 的母版，其余移入 `workspace/.skills-archive/<日期>/`。")
    lines.append("3. 空壳：补齐内容或下线，避免占用触发词。")
    lines.append("4. 召回冲突：在 description 里加区分词（适用对象/产物形态），不要靠目录名区分。")
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", action="append", default=None)
    ap.add_argument("--md", default=None)
    ap.add_argument("--json", default=None)
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    roots = args.root or default_roots()
    skills, seen = load_skills(roots)
    if not skills:
        print("找不到任何技能根（含 SKILL.md 的目录）。", file=sys.stderr)
        return 2

    for s in skills:
        s["name_key"] = s["dir"].lower()
        s["tier"] = tier_of(s["bytes"], s["files"], s["md_bytes"])

    dup_pairs = detect_dups(skills)
    dup_dirs = set()
    for jac, why, a, b in dup_pairs:
        dup_dirs.add(a["dir"])

    hard = []
    for s in skills:
        if not s["fm_name"] or not s["desc"]:
            hard.append(("缺字段", "%s：%s 缺少 name 或 description" % (s["dir"], s["path"])))
        if s["missing"]:
            hard.append(("断链", "%s：%s" % (s["dir"], " | ".join(s["missing"][:6]))))
        if s["tier"] == "D":
            hard.append(("空壳", "%s：SKILL.md %dB / %d 个文件，疑似占位" % (s["dir"], s["md_bytes"], s["files"])))
    for jac, why, a, b in dup_pairs:
        if abs(a["files"] - b["files"]) >= 3:
            keep = a if a["files"] > b["files"] else b
        elif max(a["bytes"], b["bytes"]) > min(a["bytes"], b["bytes"]) * 1.1:
            keep = a if a["bytes"] > b["bytes"] else b
        else:
            keep = None
        hard.append(("重复", "%s ↔ %s（%.2f，%s）；母版：%s" % (
            a["dir"], b["dir"], jac, why,
            keep["dir"] if keep else "需人工判定（目录内容等价）")))

    trig = detect_trigger_overlap(skills)

    if args.json:
        payload = dict(root=seen, total=len(skills), hard=hard,
                       skills=[{k: v for k, v in s.items() if not k.startswith("_")} for s in skills],
                       duplicates=[(round(j, 2), w, a["dir"], b["dir"]) for j, w, a, b in dup_pairs],
                       trigger_overlap=[(round(j, 2), a["dir"], b["dir"]) for j, a, b in trig])
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=1)

    md = render_md(skills, dup_pairs, trig, seen, hard)
    if args.md:
        with open(args.md, "w", encoding="utf-8", newline="") as f:
            f.write(md)

    if not args.quiet:
        print("技能总数 %d；硬问题 %d" % (len(skills), len(hard)))
        for kind, detail in hard:
            print("  [%s] %s" % (kind, detail))
        if trig:
            print("召回冲突候选（≥30%）：")
            for jac, a, b in trig:
                print("  %.2f  %s  <->  %s" % (jac, a["dir"], b["dir"]))
        if args.md:
            print("报告：%s" % args.md)

    return 1 if hard else 0


if __name__ == "__main__":
    sys.exit(main())
