#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""按 Agent Skills 开放规范（agentskills.io / Claude 文档）检查 SKILL.md 合规性。

规则来源（2026-11 基线）：
  name          ≤64 字符，仅小写字母/数字/连字符，不含 XML 标签，不含保留词 anthropic/claude
  description   非空，≤1024 字符，不含 XML 标签，须同时写“做什么”和“何时用”
  frontmatter   仅允许 name / description / license / allowed-tools / metadata / dependencies
  body          <500 行（超出应用 references 分流）
  references    >100 行的参考文件应在开头给目录
  其他          正文用祈使句、避免第二人称；避免依赖年份的时效表述

用法：
  python spec_lint.py                      # 全部技能
  python spec_lint.py --root <目录>        # 指定根
  python spec_lint.py --path <技能目录>     # 单个技能
退出码：0 无 ERROR；1 存在 ERROR；2 找不到技能
"""
import argparse
import os
import re
import sys

ALLOWED_KEYS = {"name", "description", "license", "allowed-tools", "metadata", "dependencies"}
NAME_RE = re.compile(r"^[a-z0-9-]{1,64}$")
RESERVED = ("anthropic", "claude")


def parse_fm(text):
    fm, raw = {}, ""
    if not text.startswith("---"):
        return fm, text
    end = text.find("\n---", 3)
    if end < 0:
        return fm, text
    raw = text[3:end]
    body = text[end + 4:]
    key = None
    for line in raw.splitlines():
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_-]*):\s*(.*)$", line)
        if m:
            key = m.group(1).lower()
            fm[key] = m.group(2).strip().strip("\"'")
        elif key and line.strip() and line.startswith((" ", "\t")):
            fm[key] = (fm.get(key, "") + " " + line.strip()).strip()
    return fm, body


def default_roots():
    here = os.path.abspath(__file__)
    user_root = os.path.dirname(os.path.dirname(os.path.dirname(here)))
    workspace = os.path.dirname(user_root)
    home = os.path.expanduser("~")
    return [os.path.join(workspace, ".skills"), user_root,
            os.path.join(home, "Doubao", "skills"), os.path.join(home, ".agents", "skills")]


def lint_one(d):
    name_dir = os.path.basename(d)
    p = os.path.join(d, "SKILL.md")
    if not os.path.isfile(p):
        return [("ERROR", "缺少 SKILL.md")]
    text = open(p, encoding="utf-8", errors="replace").read()
    fm, body = parse_fm(text)
    issues = []

    n = fm.get("name", "")
    if not n:
        issues.append(("ERROR", "frontmatter 缺 name"))
    else:
        if not NAME_RE.match(n):
            issues.append(("ERROR", "name 不合规（须 ≤64 且仅小写字母/数字/连字符）：%s" % n))
        for w in RESERVED:
            if w in n.lower():
                issues.append(("ERROR", "name 含保留词 %s" % w))
        if n != name_dir:
            issues.append(("ERROR", "name(%s) 与目录名(%s) 不一致（规范要求一致）" % (n, name_dir)))

    dsc = fm.get("description", "")
    if not dsc:
        issues.append(("ERROR", "frontmatter 缺 description"))
    else:
        if len(dsc) > 1024:
            issues.append(("ERROR", "description 超 1024 字符：%d" % len(dsc)))
        # 反引号里的路径模板（如 `/page/<token>`）不是 XML 标签，先剔除再判
        plain = re.sub(r"`[^`]*`", "", dsc)
        if re.search(r"<[A-Za-z/]", plain):
            issues.append(("ERROR", "description 含 XML 标签"))
        if not re.search(r"(当|用于|需要|\buse when\b|when the user)", dsc, re.I):
            issues.append(("WARN", "description 未写“何时使用”"))

    for k in fm:
        if k not in ALLOWED_KEYS:
            issues.append(("WARN", "frontmatter 含规范外字段：%s" % k))

    n_lines = body.count("\n") + 1
    if n_lines >= 500:
        issues.append(("WARN", "正文 %d 行，超过 500 行上限，应分流到 references/" % n_lines))

    if len(re.findall(r"你(?![们])", body)) > 3:
        issues.append(("WARN", "正文第二人称偏多，规范要求祈使句"))

    # 年份只算“指令性”表述；出处/署名行里的日期是证据，不算过期风险
    PROVENANCE = re.compile(r"©|\(c\)|attribution|cite as|沉淀自|License|许可|来源|参考|版本|version|CHANGELOG", re.I)
    yr_lines = [(i, l) for i, l in enumerate(body.splitlines(), 1)
                if re.search(r"20(?:2[5-9]|3[0-9])(?:年|-)", l) and not PROVENANCE.search(l)]
    if yr_lines:
        issues.append(("WARN", "正文第 %d 行含具体年份（指令性表述易过期）"
                       % yr_lines[0][0]))

    refs_dir = os.path.join(d, "references")
    if os.path.isdir(refs_dir):
        for f in os.listdir(refs_dir):
            if not f.lower().endswith(".md"):
                continue
            fp = os.path.join(refs_dir, f)
            try:
                lines = open(fp, encoding="utf-8", errors="replace").read().splitlines()
            except OSError:
                continue
            if len(lines) > 100 and not any(re.search(r"目录|contents|##\s*[一二三]", l, re.I)
                                            for l in lines[:15]):
                issues.append(("WARN", "references/%s 超 100 行但开头无目录" % f))
    return issues


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", action="append")
    ap.add_argument("--path")
    args = ap.parse_args()

    targets = []
    if args.path:
        targets = [args.path]
    else:
        for r in (args.root or default_roots()):
            if not os.path.isdir(r):
                continue
            for name in sorted(os.listdir(r)):
                d = os.path.join(r, name)
                if os.path.isfile(os.path.join(d, "SKILL.md")):
                    targets.append(d)
    if not targets:
        print("找不到技能。", file=sys.stderr)
        return 2

    total_err = total_warn = 0
    for d in targets:
        issues = lint_one(d)
        errs = [m for s, m in issues if s == "ERROR"]
        warns = [m for s, m in issues if s == "WARN"]
        total_err += len(errs)
        total_warn += len(warns)
        if issues:
            print("%s  (E%d/W%d)" % (os.path.basename(d), len(errs), len(warns)))
            for s, m in issues:
                print("   [%s] %s" % (s, m))

    print("\n共 %d 个技能；ERROR %d；WARN %d" % (len(targets), total_err, total_warn))
    return 1 if total_err else 0


if __name__ == "__main__":
    sys.exit(main())
