# EVIDENCE · skill-doctor

- 类型：可执行
- 记录日期：2026-11-11 17:13:40（当日实跑，未引用历史快照）
- 环境指纹：Windows / Python 3.13.14
- 记录口径：命令 + 退出码 + 输出尾部 + 产物；非“看起来正常”

## 结论

**PASS**——上列命令退出码全为 0。

## 实跑命令与退出码

| # | 命令 | 目标 | 退出码 | 耗时(ms) |
|---|---|---|---|---|
| 1 | `python -u scripts\skill_doctor.py --root <技能根> --json evidence_doctor_report.json --quiet` | - | 0 | 94 |

## 实跑输出（尾部）

```text
# [1] exit=0
(无输出)
```

## 产物

- `evidence_doctor_report.json`（6747 B）— 体检结果 JSON，含逐技能分级

## 复跑方式

```bash
# 在技能目录内执行；<…> 为需替换的目标参数
python -u scripts\skill_doctor.py --root <技能根> --json evidence_doctor_report.json --quiet
```

## 边界

- 只证明“当日、按上列命令可跑通并给出该输出”，不外推到其他环境或其他输入。
- 本文件刻意不写入本机绝对路径：可复现性靠命令与版本，不靠机器布局。
- 无脚本件用结构校验代替实跑，不冒充可执行验证。
- 退出码非 0 即记 FAIL，不以措辞放宽。

## 外锚（外部时间戳）

- 锚定对象：本件 `SKILL.md` 的 SHA-256
- 指纹：`51bd567950e99e6b349c7d114034fc485b3d93686a6cf52d96c46733fea02c54`
- 证明文件：同目录 `SKILL.md.ots`（OpenTimestamps，Binary 格式）
- 提交日历：a.pool / b.pool / alice.btc 三个公共日历，均有回执
- 生成时间：2026-11-11T17:36:30
- 复核方式：`ots verify SKILL.md`（需联网升级至比特币区块确认）；本机等价命令见《65 号件》§三
- 状态：**Pending**（已提交、待比特币区块确认；确认后 proof 永久有效，可离线校验）
- 内容不上链：链上只有 32 字节哈希与时间，原始文本不进入任何外部网络
