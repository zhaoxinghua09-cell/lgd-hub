# -*- coding: utf-8 -*-
"""UIBC 参赛包完整性检查：把 5 段流水线的交付要求变成可跑的清单。

用法：
  python submission_check.py --dir <参赛包目录>
  python submission_check.py --selftest

检查项（每条 pass/fail，任一 fail 退出码 1）：
  1 报名段：submission.json 存在且含 team / contact / track 三个键
  2 赛题段：problem.md 存在且 ≥ 200 字（赛题复述不能一句话带过）
  3 交付段：spec / tests / runlog 三类文件至少各有 1 个
  4 可复现段：runlog 里至少一条记录含退出码（"exit=0" 或 "exit code: 0" 形式）
  5 反作弊段：submission.json 的 anticheat 块含 declared=true 与 dedup_sha256
  6 原创段：submission.json 含 originality.statement，且长度 ≥ 50 字

退出码：0 全部通过 / 1 有未通过项 / 2 参数错误。
"""
import argparse
import json
import os
import re
import sys
import tempfile

RUNLOG_EXIT = re.compile(r"(?:exit(?:\s*code)?\s*[:=]\s*\d+|\bexit=\d+)", re.I)


def find(dirpath, names):
    for n in names:
        if os.path.isfile(os.path.join(dirpath, n)):
            return os.path.join(dirpath, n)
    return None


def count_ext(dirpath, exts):
    n = 0
    for root, _d, files in os.walk(dirpath):
        for f in files:
            if os.path.splitext(f)[1].lower() in exts:
                n += 1
    return n


def check(dirpath):
    rows = []

    sub_path = os.path.join(dirpath, "submission.json")
    sub = {}
    if os.path.isfile(sub_path):
        try:
            sub = json.load(open(sub_path, encoding="utf-8"))
        except Exception:
            sub = {}
    rows.append(("1 报名段", bool(sub.get("team") and sub.get("contact") and sub.get("track")),
                 "submission.json: team/contact/track"))

    prob = os.path.join(dirpath, "problem.md")
    chars = 0
    if os.path.isfile(prob):
        chars = len(open(prob, encoding="utf-8", errors="replace").read())
    rows.append(("2 赛题段", chars >= 200, "problem.md %d 字（需 ≥200）" % chars))

    have = {
        "spec": find(dirpath, ["spec.md", "SPEC.md", "protocol.md"]),
        "tests": find(dirpath, ["test_cases.json", "tests.json", "test_cases.md"]),
        "runlog": find(dirpath, ["runlog.md", "run.log", "runlog.txt"]),
    }
    rows.append(("3 交付段", all(have.values()),
                 "缺：" + "、".join(k for k, v in have.items() if not v) if not all(have.values()) else "spec/tests/runlog 齐"))

    exit_hits = 0
    if have["runlog"]:
        txt = open(have["runlog"], encoding="utf-8", errors="replace").read()
        exit_hits = len(RUNLOG_EXIT.findall(txt))
    rows.append(("4 可复现段", exit_hits >= 1, "runlog 中带退出码的记录 %d 条" % exit_hits))

    ac = sub.get("anticheat") or {}
    rows.append(("5 反作弊段", bool(ac.get("declared")) and bool(ac.get("dedup_sha256")),
                 "anticheat.declared / dedup_sha256"))

    orig = (sub.get("originality") or {}).get("statement") or ""
    rows.append(("6 原创段", len(orig) >= 50, "originality.statement %d 字（需 ≥50）" % len(orig)))

    return rows


def report(dirpath, quiet=False):
    rows = check(dirpath)
    if not quiet:
        print("项            结论  说明")
        print("------------  ----  ----")
        for name, ok, note in rows:
            print("%-12s  %-4s  %s" % (name, "过" if ok else "未过", note))
        bad = [r[0] for r in rows if not r[1]]
        print("\n通过 %d/%d%s" % (len(rows) - len(bad), len(rows),
                                  "" if not bad else "；未过：" + "、".join(bad)))
    return 0 if all(r[1] for r in rows) else 1


def make_pkg(root, complete=True):
    os.makedirs(root, exist_ok=True)
    sub = {"team": "T-01", "contact": "team@example.org", "track": "S1-stage-1",
           "anticheat": {"declared": True, "dedup_sha256": "0" * 64},
           "originality": {"statement": "全部代码与文档由本队在赛期内独立完成，未使用他人成品，"
                                       "外部依赖均为公开库并在 runlog 中列明。"}}
    if not complete:
        sub.pop("anticheat")
    json.dump(sub, open(os.path.join(root, "submission.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    open(os.path.join(root, "problem.md"), "w", encoding="utf-8").write(
        "# 赛题复述\n\n" + ("本站在于识别判定边界迁移后的部分失效并完成问责上报，"
                          "要求不依赖云端、不静默失败、问责记录可审计。" * 8))
    open(os.path.join(root, "spec.md"), "w", encoding="utf-8").write("# 协议\n步骤 1 2 3\n")
    open(os.path.join(root, "test_cases.json"), "w", encoding="utf-8").write('{"cases": []}\n')
    open(os.path.join(root, "runlog.md"), "w", encoding="utf-8").write(
        "| 步骤 | 结果 |\n|---|---|\n| 全量跑 | exit=0 |\n")


def selftest():
    tmp = tempfile.mkdtemp(prefix="uibc_pkg_")
    good, bad = os.path.join(tmp, "good"), os.path.join(tmp, "bad")
    make_pkg(good, True)
    make_pkg(bad, False)
    got_good, got_bad = report(good, quiet=True), report(bad, quiet=True)
    checks = [("完整包应 exit 0", got_good == 0), ("缺反作弊块应 exit 1", got_bad == 1)]
    failed = [n for n, ok in checks if not ok]
    if failed:
        print("自检未通过：" + "；".join(failed))
        return 1
    print("自检通过：2/2（完整包 0 / 缺反作弊 1）")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return selftest()
    if not args.dir:
        print(__doc__)
        return 2
    if not os.path.isdir(args.dir):
        print("目录不存在：%s" % args.dir, file=sys.stderr)
        return 2
    return report(args.dir)


if __name__ == "__main__":
    sys.exit(main())
