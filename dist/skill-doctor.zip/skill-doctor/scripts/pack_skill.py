#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把技能目录打成可上传的 ZIP（根目录即以技能名命名的文件夹）。

按规范：ZIP 内层必须是 <skill-name>/ 作为根，而不是散文件；不打包 .git、缓存与临时产物。
默认剔除规范不建议的冗余文档（README / CHANGELOG / INSTALLATION_GUIDE / QUICK_REFERENCE），
需要保留则加 --keep-docs。

用法：
  python pack_skill.py --skill <技能目录> --out <输出.zip> [--keep-docs]
退出码：0 成功；1 校验失败（缺 SKILL.md / name 不合规）；2 参数错误。
"""
import argparse
import os
import re
import sys
import zipfile

EXCLUDE_DIRS = {".git", "__pycache__", ".pytest_cache", "node_modules", ".workflow"}
EXCLUDE_DOCS = {"README.md", "README_CN.md", "CHANGELOG.md", "INSTALLATION_GUIDE.md",
                "QUICK_REFERENCE.md", "CONTRIBUTING.md", "CODE_OF_CONDUCT.md"}
NAME_RE = re.compile(r"^[a-z0-9-]{1,64}$")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skill", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--keep-docs", action="store_true")
    args = ap.parse_args()

    d = os.path.abspath(args.skill)
    md = os.path.join(d, "SKILL.md")
    if not os.path.isfile(md):
        print("缺 SKILL.md：%s" % d, file=sys.stderr)
        return 1

    text = open(md, encoding="utf-8", errors="replace").read()
    m = re.search(r"^name:\s*(.+)$", text, re.M)
    fm_name = m.group(1).strip().strip("\"'") if m else ""
    root = os.path.basename(d)
    if fm_name and not NAME_RE.match(fm_name):
        print("frontmatter name 不合规：%s" % fm_name, file=sys.stderr)
        return 1
    if fm_name and fm_name != root:
        print("提示：name(%s) 与目录名(%s) 不一致，ZIP 根将用目录名" % (fm_name, root))

    entries, skipped = [], []
    for dp, dn, fn in os.walk(d):
        dn[:] = [x for x in dn if x not in EXCLUDE_DIRS]
        for f in fn:
            fp = os.path.join(dp, f)
            rel = os.path.relpath(fp, d).replace(os.sep, "/")
            if not args.keep_docs and rel in EXCLUDE_DOCS:
                skipped.append(rel)
                continue
            entries.append((fp, rel))

    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as z:
        for fp, rel in entries:
            z.write(fp, "%s/%s" % (root, rel))

    with zipfile.ZipFile(args.out) as z:
        names = z.namelist()
        bad_root = [n for n in names if not n.startswith(root + "/")]

    print("打包：%s（%d 个文件，%d 字节）" % (args.out, len(entries), os.path.getsize(args.out)))
    if skipped:
        print("已剔除冗余文档：%s" % ", ".join(skipped))
    if bad_root:
        print("错误：存在不在技能根下的条目：%s" % bad_root[:3], file=sys.stderr)
        return 1
    print("ZIP 根目录校验通过：%s/" % root)
    return 0


if __name__ == "__main__":
    sys.exit(main())
