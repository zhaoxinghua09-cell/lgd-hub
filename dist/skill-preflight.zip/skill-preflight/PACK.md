# skill-preflight

给一个技能目录或 SKILL.md，一秒内出分、位次、差在哪、能不能发。

- 版本线：lgd-hub rev H
- 许可：MIT（包内 LICENSE.txt 为全文；引用请保留署名 Xinghua Zhao）
- 包内文件：11 个，解压后约 0.12 MB
- `SKILL.md` 的 SHA-256：`588ec5c1e0d03d881d0f739fe39067e5cfa08dc827e5ffb0a2273f44f81c7e6b`

## 安装

```bash
unzip skill-preflight.zip -d ~/.claude/skills/     # 或你的 agent 技能目录
```

装完即可用；无依赖、不联网、不调模型。入口：`scripts/preflight.py`。

## 自己核一遍

```bash
sha256sum SKILL.md            # 应等于上面那一行
python scripts/preflight.py --json         # 机器可读；本件自身也可作为样本
```

哈希对不上就**先报这个**，别先报内容问题——对不上说明你拿到的不是这一版。

## 界线

本包自跑、非认证。评分出自公开加权的判据，判据自身的已知缺陷写在 https://zhaoxinghua09-cell.github.io/lgd-hub/EVAL.md
（我们选择公开而不修）。发现不一致、或不服某个数，走 https://zhaoxinghua09-cell.github.io/lgd-hub/FEEDBACK.md：
7 天内进表，30 天内给结论，结论只有采纳 / 驳回 / 存疑。
