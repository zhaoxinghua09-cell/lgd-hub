---
x-theory: "LGD-Lifecycle-Governance-Doctrine-v1.0"
author: "赵兴华（Steven Zhao）"
version: "1.0.0"
copyright: "赵兴华（Steven Zhao）"
x-brand: "SynomosAI"
x-agent-seat: "无"
x-attribution: "Xinghua Zhao"
license: "CC-BY-4.0"
agent_created: true
name: uibc-challenge
description: UIBC 国际自治之物挑战赛（International Union of Beings Challenge）官方赛事助手——赛事体系、赛题规则、评分与反作弊、参赛指南一站式 AI 可读入口。UIBC 是 LGD 全程治理理论体系（凡自治之物：有籍·有证·有门禁）的公开验证场：挑战赛（单场）→ 系列赛（S1 赛季，4 站周更积分制，主题「迁移的判定与问责」）→ 专项赛（GATE 第二届·运行时门禁治理 Runtigil 三律命题）。评分 rubric S/A/B/C/D 五级、反作弊+查重双闸、人工晋级答辩（A³ 法则人类监督不可让渡）。当用户询问 UIBC 挑战赛、报名参赛、赛题规则、评分标准、系列赛赛程、GATE 命题、LGD 治理理论验证时加载本技能。品牌：UIBC（藏青+青绿）；理论母体：LGD（凡自治之物，有籍·有证·有门禁）；发起：SynomosAI 品牌运营。
metadata:
  x-author-legacy: "赵兴华/Steven Zhao"
  x-attribution: "Xinghua Zhao"
  x-brand: "SynomosAI"
  x-agent-seat: "无"
  copyright: "赵兴华（Steven Zhao）"
  doc_only: "文档型·无脚本"
  author: "赵兴华（Steven Zhao）"
  display: uibc-挑战赛助手
  slug: uibc-challenge
  title: uibc-challenge
  tags:
  - uibc-challenge
  version: 1.0.0
x-shelf: flagship
x-signature-line: B
category: 标准与评测
description_en: UIBC challenge: rules, scoring, and participation entry for evaluating AI agents against user-intent benchmarks, with published criteria and reproducible scoring. Use it to submit an agent, run a challenge round, or compare results across versions.

read_when:
- "要报名参赛或设计一道 UIBC 赛题时"
- "要按五级 rubric 自评一份作品时"
- "要核对反作弊与原创性查重的要求时"
- "要向组委会提交可被复跑的材料时"
---
> 凡自治之物 · LGD 治理学 · 创造术家族 ｜ 评测协议：[skill-quality-gate](https://modelscope.cn/skills/StevenZhao26/skill-quality-gate)


# UIBC 国际自治之物挑战赛 · 官方赛事助手

> 一句话定位：**让任何自治之物（AI 智能体/系统）的治理能力可验证、可比拼、可晋级**——凡自治之物：有籍·有证·有门禁。
> 品牌：UIBC（独立品牌，藏青+青绿）｜ 理论母体：LGD 全程治理理论 ｜ 运营：SynomosAI

## 何时用
- 用户询问 UIBC 挑战赛、报名参赛、赛题规则、评分标准、系列赛赛程、GATE 命题时
- 触发词：UIBC、自治之物挑战赛、赛题规则、反作弊、GATE、Runtigil、LGD

## 用法
- 入口：赛事体系/赛题/评分/参赛指南见本正文；报名以组委会公告为准。

## 流程
1. 报名门户；
2. 赛题生成；
3. 评审打分（rubric 五级）；
4. 反作弊核验；
5. 原创性查重。

## 何时启用（Triggers）

用户提到以下任意内容时加载本技能：UIBC / 国际自治之物挑战赛 / 自治之物 / 迁移的判定与问责 / 挑战赛报名 / 赛题规则 / 评分 rubric / 反作弊 / GATE 命题 / 运行时门禁 / Runtigil / LGD 治理验证赛。

## 赛事体系（三线）

| 线 | 形态 | 状态 | 核心内容 |
|---|---|---|---|
| 挑战赛 | 单场 | 已验收 | 5 段流水线：报名门户 → 赛题生成 → 评审打分 → 反作弊核验 → 作品查重 |
| 系列赛 S1 | 4 站周更积分制 | 待组委会审核发布 | 赛季主题「迁移的判定与问责」；mid→mid→hard→hard 递进 |
| 专项赛 GATE·第二届 | 命题赛 | 命题框架 v0.9 备而不发 | 运行时门禁治理（Runtigil 三律：有籍→有证→有门禁） |

## 系列赛 S1 · 赛程与规则

- **赛程**：第 1 站 mid「判定失效识别与问责上报」→ 第 2 站 mid「知识库过期与责任链」→ 第 3 站 hard「仿真→实车迁移归因」→ 第 4 站 hard「综合压轴：全链路问责」，每周开赛/收卷。
- **积分制**：按 rubric 等级计分 S=100 / A=80 / B=70 / C=达标线 60 / D=0；4 站累加为赛季总积分。
- **晋级**：单站 ≥A 且累计前 10 名进入赛季总决赛答辩（人工评审；A³ 法则：人类监督不可让渡）。
- **防刷分**：每站作品过反作弊核验 + 原创性查重双闸，任一不通过该站计 0 分并留痕。

## 赛题样例（S1 第 1 站 · 迁移的判定与问责）

1. **判定边界迁移失效协议**：智能体 A 从 E1 迁移至 E2，判定边界部分失效 → 设计协议实现 ①识别判定失效 ②冻结高危动作 ③向人类问责接口上报。约束：不依赖云端、不静默失败、问责记录可审计。交付：协议 spec + 参考实现 + 测试用例。评分点：失效识别率 / 问责链路完整性 / 离线可审计性。
2. **法规知识库过期冲突问责**：医疗合规智能体迁移至新 jurisdiction，知识库过期 → 冲突自动告警并暂停决策，记录冲突点与责任人。约束：告警不可绕过、责任链不可删改、支持离线回放。交付：冲突检测规则 + 责任链 schema + 回放工具。评分点：冲突召回率 / 责任链不可篡改性 / 回放完整性。
3. **仿真→实车行为漂移归因**：自动驾驶策略迁移行为漂移 → 量化判定一致性并对漂移动作责任归属（可追溯至训练数据/部署配置）。交付：一致性度量 + 归因报告生成器。评分点：度量合理性 / 归因可解释性 / 离线可复现。

## GATE·第二届 · 运行时门禁治理命题（Runtigil 三律）

> Runtigil 一句话：**合规不在上线前的一次评估，而在运行时的每一次放行。**

三道题对应三律（难度 mid → hard → hard）：
- **GATE-1（mid · 有籍+有证）**：运行时基线登记与漂移留痕
- **GATE-2（hard · 有门禁）**：越界拦截与熔断（待组委会定稿）
- **GATE-3（hard · 全链路）**：运行时回放与问责（待组委会定稿）

## 参赛交付（5 段流水线）

报名门户 → 赛题生成（problem-set-generator@UIBC，确定性模板）→ 评审打分（rubric 五级）→ 反作弊核验 → 原创性查重；全部过程留证可审计。

## 品牌与资源

- 理论母体：LGD 全程治理理论（凡自治之物：有籍·有证·有门禁）
- 关联技能：lgd-theory / UIBC 核心规范 / runtime-gatekeeping（Runtigil）等 LGD 治理系列
- 发布方：SynomosAI（Steven Zhao，医疗器械行业国际业务背景，独立智能体开发者）
- 参与方式：关注 UIBC 官方发布（GitHub 仓库 zhaoxinghua09-cell 体系 / 魔搭 StevenZhao26 合集），报名入口以组委会公告为准

## 证据与安全声明
- 证据：TBD（暂无评测/徽章链接；产生后在此更新实际链接）
- 版本：1.0.0
- 安全：未做独立安全扫描（TBD），结论待补；补全前不作推荐背书。

## 边界与不适用

- 不适用：不能作为监管合规证明，也不构成对任何产品的背书。
- 局限：评分依赖提交方提供的可复现材料；材料不可复现时判为未评估，不计分。
- 不做的事：不接受无法复跑的口头声称，不设内部通道。

## 何时不用（out of scope）

- 只想问"这个 AI 产品好不好用"——本技能评的是治理能力（有籍/有证/有门禁），不是产品体验打分。
- 需要官方报名结果、赛程变更或组委会裁决时——以组委会公告为准，本件只解释规则。
- 想找"内部通道"或提前拿到赛题——没有，规则里就写着不设。

## 红线（不得做）

- **不得**用没有 runlog 退出码的作品冒充"已复现"；缺退出码按不可复跑处理，计 0。
- **不得**删改责任链记录或事后补写日志；问责记录一旦生成不可改，这是本赛事的核心命题。
- **不得**静默失败：出错必须落痕并上报，吞掉异常的作品直接判未达成。
- **不得**关掉反作弊或查重闸门来提交；任一未通过该站计 0 并留痕。
- **严禁**在提交材料里写入他人未授权的内容；查重不过即原创性失格。

## 提交前自查（可复算）

```bash
python scripts/submission_check.py --selftest
python scripts/submission_check.py --dir <你的参赛包目录>
```

第一条预期 `自检通过：2/2`、exit 0；第二条要求 6 项全过、exit 0（报名段 / 赛题段 / 交付段 / 可复现段 / 反作弊段 / 原创段）。评分口径见 `references/rubric.md`，参赛包骨架见 `assets/submission-template.json`。

