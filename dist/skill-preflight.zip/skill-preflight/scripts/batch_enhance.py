# -*- coding: utf-8 -*-
"""已发布技能 · 「规范骨架」批量补齐（fail-safe）。

⚠️ 改动前必读（F-003 血的教训）：
  1. 徽章/理论行**只许追加在文末** —— preflight 的 D1 只看 `desc + body[:2000]`，
     插在正文顶部会把触发词挤出窗口 → D1 掉分并连带 S2 失守（实测 0.70→0.40）。
  2. 判定「政策句适用范围」必须用**原始正文**，不能用改后文本（改后文本含刚注入的
     `x-theory: "LGD-…"` 的 `LGD` → 判定恒真，属自注入型自命中）。
  3. 备份**绝不覆盖**；改后必须做**全库口径对比**（只升不降才算过）。

原始说明：

覆盖 skill-preflight 的 S3/S4/S5/S6/S8/S10（+README 骨架），落点严格按规范原文：
  规范①《技能打磨规范 v1.0》(2026-09-06)
    §一.3 理论锚：frontmatter `x-theory: LGD…` 或 正文行含 DOI 10.5281/zenodo.22456647
    §一.4 徽章行：README 首屏挂 lgd-powered-en.svg（必须）｜域徽章**不上**（自仓已记：directions/* 16 个文件
         全 25186 字节，是同一份"证据"徽章复制品，非真方向标）
    §一.5 可验证性：README 含一行 Source / How it's tested
    §一.6 许可署名：LICENSE=CC BY-4.0；署名 赵兴华/MedXpert×SynomosAI
  规范②《技能包设计规范》(2026-09-08)
    §5 安装矩阵 ｜ §3 错误码 ｜ §10 政策契合声明（**唯一合规表述** + README 定位段末尾 + 不单独成节
         + 禁止范围：商业文件一律不引用）

【不做】description_en 中英文（需逐件精译，另批）；LICENSE.md/ATTESTATION.md/manifest.json（另批）

安全：默认 dry-run ｜ --go 才写 ｜ 逐件备份到 _enhance_backup/<日期>/ ｜ 幂等（有标记即跳过）
      ｜ 不覆盖 frontmatter 已有键值 ｜ --restore 可整体回滚
"""
import json, os, re, sys, shutil, time, difflib

SKROOT = os.path.expanduser(os.environ.get("SKILL_ROOT") or "~/.workbuddy/skills")
WS = os.path.dirname(os.path.abspath(__file__))
BK = os.path.join(WS, "_enhance_backup", time.strftime("%Y%m%d"))

# ── 规范化常量（全部有出处，零自创）──────────────────────────────
POWERED = ("https://raw.githubusercontent.com/zhaoxinghua09-cell/lgd-theory/"
           "main/assets/badges/powered/lgd-powered-en.svg")
DOI = "10.5281/zenodo.22456647"
DOI_URL = "https://doi.org/" + DOI
XTHEORY = "LGD-Lifecycle-Governance-Doctrine-v1.0"   # 自仓实有：LGD-Lifecycle-Governance-Doctrine-v1.0.md
SIGN = "赵兴华/MedXpert × SynomosAI"                  # 规范①§一.6 原文署名
LICENSE = "CC-BY-4.0"                                 # 规范①§一.6 原文
REPO = "https://github.com/zhaoxinghua09-cell/lgd-theory"

# 照抄 masters 既有行（05-工具/agent-skills/skills/*/SKILL.md 实测格式，逐字复用）
BADGE_LINE = f"![LGD-Powered]({POWERED})"
THEORY_LINE = (f"> 头像与徽记 © SynomosAI 2026；理论 CC BY 4.0（DOI {DOI}）。"
               f"参照声明须回链：[LGD-theory]({REPO}）。")
# 规范②§10 **唯一合规表述**（逐字，不得改写）
POLICY_SENT = "本技能包契合国家「人工智能+软件」专项行动方向（智能体技能包资源库与规范上架）。"

# 商业件特征词 → 政策句**禁用**（规范②§10 禁止范围）
COMMERCIAL = ("报价", "定价", "渠道价", "财务", "合同", "发票", "佣金", "投标", "回款", "毛利率", "内部流转")

# F-004 教训：不得再用「全文子串命中」判商业件（语境缺失 → 11/11 误伤，实测）
# 元标记词：出现在商业词 ±35 字内 ⇒ 该处是在**讲规则/举反例/列风险**，不是在**做商业件**
META_CTX = ("不构成", "免责", "禁止", "不得", "红线", "风险", "示例", "举例", "例如", "去敏", "脱敏",
            "清单", "门禁", "审查", "校验", "检查项", "建议", "敏感", "规则", "标注", "枚举")
# 「产出商业交付物」的动宾结构：只有这种才是**自我定位为商业件**
DELIVERABLE = re.compile(
    r"(生成|输出|出具|编制|起草|填写|制作|拟制|汇总)[^。\n]{0,10}"
    r"(报价单|报价书|定价方案|价格表|财务报告|财务报表|对账单|发票|合同文本|标书|投标文件|投资协议)")

M_BADGE = "lgd-powered"
M_THEORY = "zenodo.22456647"
M_INSTALL = "安装矩阵"
M_SRC = "How it's tested"


def read(p):
    return open(p, encoding="utf-8").read()


def parse_fm(txt):
    """返回 (fm_lines, body)。正确跳过第一个 --- 收尾符。"""
    if not txt.startswith("---"):
        return None, txt
    lines = txt.split("\n")
    if lines[0].strip() != "---":
        return None, txt
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            return lines[1:i], "\n".join(lines[i + 1:])
    return None, txt


def fm_keys(fm):
    return {re.match(r"([A-Za-z0-9_\-]+)\s*:", l).group(1).lower()
            for l in (fm or []) if re.match(r"([A-Za-z0-9_\-]+)\s*:", l)}


def fm_dict(fm):
    d = {}
    for l in (fm or []):
        m = re.match(r"([A-Za-z0-9_\-]+)\s*:\s*(.*)", l)
        if m:
            d[m.group(1).lower()] = m.group(2).strip().strip('"\'')
    return d


def first_sentence(desc):
    """取 description 的第一句作定位句（去掉触发词尾巴）。"""
    if not desc:
        return ""
    d = desc.strip().strip('"\'')
    for sep in ("。", "；", ". "):
        if sep in d:
            d = d.split(sep)[0]
            break
    return d.strip()[:180]


def is_commercial_doc(name, desc):
    """商业件判定（身份层版 · 修 F-004）。

    只用两类**身份层**信号，不看正文：
      A. 技能名/显示名里就带商业件词（如「报价单生成器」「财务报告器」）——自我定位即商业件；
      B. description 里出现「生成|出具|编制…+报价单|财务报告|合同文本|标书…」的**产出交付物**动宾结构。
    **正文里提一句商业词一律不判商业件** —— 免责句「不构成财务建议」、门禁枚举「合规/财务/身份」、
    技能主题「审查合同管理办法」、去敏示例「客户报价」、内容枚举「…/投标/培训材料」
    这五类实测各误伤过，全部不再触发（F-004）。
    """
    ident = " ".join(x for x in (name or "",) if x)
    a = [kw for kw in COMMERCIAL if kw in ident]
    b = []
    if DELIVERABLE.search(desc or ""):
        b.append("交付物动宾:" + DELIVERABLE.search(desc).group(0))
    return a + b


def build_readme(name, fm, body, allow_policy):
    """生成 README.md（规范骨架）。"""
    g = lambda k: (fm or {}).get(k, "")
    title = g("display_name") or g("displayname") or g("title") or name
    title_en = g("display_name_en") or g("title_en") or ""
    desc = first_sentence(g("description"))
    # 关键词：frontmatter tags/keywords 优先，其次抽 description 触发词
    tags = g("tags") or g("keywords")
    if tags:
        kw = re.sub(r'[\[\]"\']', "", tags).replace(",", " · ")
    else:
        kw = ""
    ver = g("version") or "1.0.0"

    L = []
    L.append(f"# {title}" + (f" · {title_en}" if title_en else ""))
    L.append("")
    L.append(BADGE_LINE)
    L.append("")
    if desc:
        L.append(desc + "。")
        L.append("")
    if kw:
        L.append(f"**{kw}**")
        L.append("")
    if allow_policy:
        # 规范②§10：定位段末尾 · 一句话 · 不单独成节 · 不做视觉强调
        L.append(POLICY_SENT)
        L.append("")
    L.append("## 安装矩阵")
    L.append("")
    L.append("| 运行时 | 安装位置 |")
    L.append("|---|---|")
    L.append(f"| WorkBuddy | `~/.workbuddy/skills/{name}/`（或技能市场导入本目录） |")
    L.append(f"| Claude Code | `~/.claude/skills/{name}/` |")
    L.append("")
    L.append("## 来源与验证")
    L.append("")
    L.append(f"- **Source**：{SIGN} 自研维护，许可 {LICENSE}。")
    L.append("- **How it's tested**：`python <skill-preflight>/scripts/preflight.py "
             f"\"{name}\" --require-spec 7`（结构/规范双体检，退出码非 0 即不达标）")
    L.append("")
    L.append(THEORY_LINE)
    L.append("")
    L.append(f"版本 v{ver} · © MedXpert × SynomosAI · 内部规范件")
    return "\n".join(L) + "\n"


def enhance_skill_md(txt, name):
    """SKILL.md：补 frontmatter 键 + 顶部徽章行/理论行。幂等。"""
    done = []
    fm, body = parse_fm(txt)
    if fm is None:
        return txt, ["⚠️ 无 frontmatter，跳过"]
    keys = fm_keys(fm)
    add = []
    if "x-theory" not in keys:
        add.append(f'x-theory: "{XTHEORY}"')
        done.append("S3 x-theory")
    if "author" not in keys:
        add.append(f'author: "{SIGN}"')
        done.append("S6 署名")
    if "license" not in keys:
        add.append(f"license: {LICENSE}")
        done.append("S6 许可")
    fm2 = fm + add
    head = "---\n" + "\n".join(fm2) + "\n---\n"
    body = body.lstrip("\n")

    # ⚠️ 只允许「文末追加」：preflight 的 D1 触发设计只看 `desc + body[:2000]`，
    #    在正文顶部插行会把「触发词」挤出窗口 → D1 掉分（实测 medical-device-reg-hub 0.70→0.40，
    #    并连带 S2 失守）。徽章「首屏」由 README 承担（规范①§一.4 的指定位置）。
    body = body.rstrip("\n")
    tail = []
    if M_BADGE not in body:
        tail.append(BADGE_LINE)
        done.append("S4 徽章行")
    if M_THEORY not in body:
        tail.append("")
        tail.append(THEORY_LINE)
        done.append("S3 理论署名行(DOI)")
    if tail:
        body = body + "\n\n---\n\n" + "\n".join(tail)
    return head + "\n" + body.lstrip("\n") + "\n", done


def main():
    args = sys.argv
    only = args[args.index("--only") + 1].split(",") if "--only" in args else None
    sample = int(args[args.index("--sample") + 1]) if "--sample" in args else None
    go = "--go" in args
    global SKROOT
    if "--root" in args:
        SKROOT = args[args.index("--root") + 1]
    scope_file = (args[args.index("--scope") + 1] if "--scope" in args
                  else os.path.join(WS, "_enhance_scope.json"))
    scope = only or json.load(open(scope_file, encoding="utf-8"))
    if sample:
        scope = scope[:sample]

    plan = []
    for name in scope:
        d = os.path.join(SKROOT, name)
        sp = os.path.join(d, "SKILL.md")
        if not os.path.isfile(sp):
            print("  ⚠ 缺 SKILL.md:", name)
            continue
        txt = read(sp)
        fm, body = parse_fm(txt)
        new_sp, done = enhance_skill_md(txt, name)

        rp = os.path.join(d, "README.md")
        # F-004：政策句适用范围只按**身份层**判（技能名 + desc 的产出动宾），不再用全文子串
        _d = fm_dict(fm)
        _name = _d.get("name", "") + " " + _d.get("display_name", "") + " " + _d.get("displayname", "")
        commercial = is_commercial_doc(_name.strip(), _d.get("description", ""))
        allow_policy = not commercial
        has_readme = os.path.isfile(rp)
        new_rd = None
        if not has_readme:
            new_rd = build_readme(name, fm_dict(fm), body, allow_policy)
            done.append("README 新建")
        elif M_BADGE not in read(rp):
            done.append("README 已存在（未动，另批）")

        plan.append({"name": name, "sp": sp, "old_sp": txt, "new_sp": new_sp,
                     "rp": rp, "new_rd": new_rd, "done": done,
                     "policy": allow_policy, "commercial": commercial})

    print("=" * 76)
    print(f"{'【真执行】' if go else '【DRY-RUN】'} 目标 {len(plan)} 件")
    print("=" * 76)
    for it in plan:
        print(f"\n■ {it['name']}  ({len(it['done'])} 项) {', '.join(it['done'])}"
              + ("" if it["policy"] else f"   ⛔政策句豁免(商业特征:{it['commercial'][:3]})"))
        if not go:
            d = list(difflib.unified_diff(it["old_sp"].split("\n"), it["new_sp"].split("\n"),
                                          lineterm="", n=0))
            for l in [x for x in d if x.startswith("+") and not x.startswith("+++")][:8]:
                print("    SKILL.md ", l)
            if it["new_rd"]:
                print("    --- README.md（新建，共 %d 行）---" % len(it["new_rd"].split("\n")))
                for l in it["new_rd"].split("\n")[:16]:
                    print("      " + l[:100])

    if not go:
        print("\n>>> DRY-RUN 结束，未改动任何文件。加 --go 执行。")
        return

    os.makedirs(BK, exist_ok=True)
    log = []
    for it in plan:
        dst_bk = os.path.join(BK, it["name"] + ".__SKILL.md")
        # 🔴 绝不覆盖已有备份：多次 --go 会把"原始件"覆盖成"已改件"，回滚即失效（F-003 实测）
        if os.path.exists(dst_bk):
            raise RuntimeError("备份已存在，拒绝覆盖（回滚可信性红线）: " + dst_bk)
        shutil.copy2(it["sp"], dst_bk)
        open(it["sp"], "w", encoding="utf-8").write(it["new_sp"])
        rec = {"name": it["name"], "sp": it["sp"], "rp": it["rp"],
               "readme_created": bool(it["new_rd"]), "done": it["done"]}
        if it["new_rd"]:
            open(it["rp"], "w", encoding="utf-8").write(it["new_rd"])
        log.append(rec)
    json.dump({"at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"), "backup": BK, "items": log},
              open(os.path.join(WS, "_enhance_manifest.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(f"\n完成 {len(plan)} 件；备份 -> {BK}")


def restore():
    man = json.load(open(os.path.join(WS, "_enhance_manifest.json"), encoding="utf-8"))
    for it in man["items"]:
        b = os.path.join(man["backup"], it["name"] + ".__SKILL.md")
        if os.path.isfile(b):
            shutil.copy2(b, it["sp"])
        if it.get("readme_created") and os.path.isfile(it["rp"]):
            os.remove(it["rp"])
        print("  ↩ " + it["name"])
    print(f"回滚完成（{len(man['items'])} 件）。")


if __name__ == "__main__":
    restore() if "--restore" in sys.argv else main()
