#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""拉取 SkillHub 平台的「AI 评分」，输出可分析的 JSON。

为什么需要它：`skill-preflight` 只能看**本地文件**；而平台侧另有一套 **AI 评测**（5 维度 × 15 评分项，
每项 0–5，页面显示为总分 1 位小数）。两把尺子测的不是同一件事，必须都看。

口径（2026-09-24 实测复核）：
  总分 = 15 个评分项的**算术平均**，保留 1 位小数。
  验证：某技能 15 项合计 62.5 ÷ 15 = 4.1667 → 页面显示「4.2」✅

数据源（均为只读 GET，官方 API 通道）：
  · 条目枚举  GET {base}/api/v1/users/{handle}/skills?page=N&pageSize=M
  · 评分详情  GET {base}/api/v1/skills/{slug}/evaluation?namespace={handle}

凭据：从 `~/.skillhub/credentials.json` 读（`user.token` / `user.host`）。
      **绝不接受对话传入的密钥**，也绝不回显 token。

用法：
  python pull_platform_scores.py --handle user_xxx --out scores.json
  python pull_platform_scores.py --handle user_xxx --limit 10      # 试跑
"""
import argparse
import io
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

UA = {"User-Agent": "skill-preflight/1.1 (+score fetcher)"}
CRED = os.path.expanduser("~/.skillhub/credentials.json")
DEFAULT_BASE = "https://api.skillhub.cn"


def load_cred():
    """读本机凭据。只读文件，不落日志、不打印值。"""
    try:
        c = json.load(io.open(CRED, encoding="utf-8"))
        u = c.get("user") or {}
        host = (u.get("host") or DEFAULT_BASE).rstrip("/")
        if not host.startswith("http"):
            host = "https://" + host
        return u.get("token"), host
    except Exception:
        return None, DEFAULT_BASE


def get(url, token=None, timeout=30):
    h = dict(UA)
    h["Accept"] = "application/json"
    if token:
        h["Authorization"] = "Bearer " + token
    with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def enum_skills(handle, token, base, page_size=100, max_pages=10):
    out, total = [], None
    for page in range(1, max_pages + 1):
        url = "%s/api/v1/users/%s/skills?%s" % (
            base, urllib.parse.quote(handle),
            urllib.parse.urlencode({"page": page, "pageSize": page_size}))
        d = get(url, token)
        items = d.get("skills") or []
        if total is None:
            total = d.get("total")
        out += items
        if len(items) < page_size or (total and len(out) >= total):
            break
        time.sleep(0.2)
    return out, total


def avg_of(ev):
    """按页面口径算总分：15 项算术平均（保留 4 位，便于核对）。"""
    scores = []
    for dv in (ev.get("dimensions") or {}).values():
        for iv in (dv.get("items") or {}).values():
            if isinstance(iv, dict) and isinstance(iv.get("score"), (int, float)):
                scores.append(iv["score"])
    return (round(sum(scores) / len(scores), 4) if scores else None), len(scores)


def main():
    ap = argparse.ArgumentParser(description="拉取 SkillHub AI 评分（只读）")
    ap.add_argument("--handle", required=True, help="账号 handle，如 user_xxxxxxxx")
    ap.add_argument("--out", default="platform_scores.json", help="输出 JSON 路径")
    ap.add_argument("--limit", type=int, default=0, help="只处理前 N 条（试跑用）")
    ap.add_argument("--detail", action="store_true", help="同时保存每项的 reason（体积大）")
    args = ap.parse_args()

    token, base = load_cred()
    if not token:
        print("[warn] 读不到 %s —— 枚举端点通常需要 token" % CRED, file=sys.stderr)

    items, total = enum_skills(args.handle, token, base)
    print("枚举到 %d 条（total=%s）" % (len(items), total), file=sys.stderr)

    out, fails = {}, []
    for i, x in enumerate(items):
        if args.limit and i >= args.limit:
            break
        slug = x.get("slug")
        rec = {"name": x.get("name"), "downloads": x.get("downloads"),
               "stars": x.get("stars"), "version": x.get("version"),
               "category": x.get("category")}
        url = "%s/api/v1/skills/%s/evaluation?namespace=%s" % (
            base, urllib.parse.quote(slug or ""), urllib.parse.quote(args.handle))
        try:
            ev = get(url, token)
            a, n = avg_of(ev)
            rec.update({"avg": a, "n_items": n,
                        "dims": {dk: {ik: iv.get("score")
                                      for ik, iv in (dv.get("items") or {}).items()}
                                 for dk, dv in (ev.get("dimensions") or {}).items()},
                        "summary": (ev.get("summary") or "")[:400]})
            if args.detail:
                rec["items_reason"] = {
                    "%s.%s" % (dk, ik): {"score": iv.get("score"), "reason": iv.get("reason")}
                    for dk, dv in (ev.get("dimensions") or {}).items()
                    for ik, iv in (dv.get("items") or {}).items() if isinstance(iv, dict)}
        except urllib.error.HTTPError as e:
            rec["error"] = "HTTP %s" % e.code
            fails.append(slug)
        except Exception as e:
            rec["error"] = str(e)[:80]
            fails.append(slug)
        out[slug] = rec
        time.sleep(0.2)
        if (i + 1) % 25 == 0:
            print("  ... %d" % (i + 1), file=sys.stderr)

    got = [v["avg"] for v in out.values() if v.get("avg") is not None]
    payload = {"fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
               "handle": args.handle, "formula": "avg(15 items)", "total": total,
               "n_scored": len(got), "n_failed": len(fails),
               "account_avg": round(sum(got) / len(got), 4) if got else None,
               "items": out}
    io.open(args.out, "w", encoding="utf-8").write(json.dumps(payload, ensure_ascii=False, indent=1))
    print("已写 %s | 有评分 %d / %d | 均分 %s" % (
        args.out, len(got), len(out), payload["account_avg"]), file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
