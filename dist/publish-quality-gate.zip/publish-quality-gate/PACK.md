# publish-quality-gate

发布前四层脱敏门禁（公司信息 / 本机信息 / 个人信息 / 机密信息），豁免要署名和日期。

- 版本线：lgd-hub rev H
- 许可：MIT（包内 LICENSE.txt 为全文；引用请保留署名 Xinghua Zhao）
- 包内文件：11 个，解压后约 0.06 MB
- `SKILL.md` 的 SHA-256：`cf857a14a8b79426198c6b5c85570480177aa08a4cf6ef23fde2c897b72771e4`

## 安装

```bash
unzip publish-quality-gate.zip -d ~/.claude/skills/     # 或你的 agent 技能目录
```

装完即可用；无依赖、不联网、不调模型。入口：`scripts/check_release.py`。

## 自己核一遍

```bash
sha256sum SKILL.md            # 应等于上面那一行
python scripts/check_release.py --json         # 机器可读；本件自身也可作为样本
```

哈希对不上就**先报这个**，别先报内容问题——对不上说明你拿到的不是这一版。

## 界线

本包自跑、非认证。评分出自公开加权的判据，判据自身的已知缺陷写在 https://zhaoxinghua09-cell.github.io/lgd-hub/EVAL.md
（我们选择公开而不修）。发现不一致、或不服某个数，走 https://zhaoxinghua09-cell.github.io/lgd-hub/FEEDBACK.md：
7 天内进表，30 天内给结论，结论只有采纳 / 驳回 / 存疑。
