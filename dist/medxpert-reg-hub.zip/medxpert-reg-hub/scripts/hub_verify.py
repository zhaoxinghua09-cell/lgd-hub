# -*- coding: utf-8 -*-
"""枢纽包完整性校验：按 manifest.json 逐文件复算哈希，并统计资料覆盖。

用途：
  发布前自查、外部复核者一键验另。判据公开、可复算，不看自评。

用法：
  python hub_verify.py --root <技能目录>
  python hub_verify.py --selftest

判据：
  1. manifest.json 里登记的每个文件都必须存在；
  2. 每个文件的 SHA-256 必须与登记值一致；
  3. 清单外的文件只提示不判失败（允许新增资料）；
  4. references/ 至少 1 份、assets/ 至少 1 份，否则报覆盖不足。

退出码：0 通过 / 1 不通过 / 2 参数错误。
"""
import argparse
import hashlib
import json
import os
import sys
import tempfile


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def verify(root, quiet=False):
    man_path = os.path.join(root, "manifest.json")
    if not os.path.isfile(man_path):
        return 1, ["缺少 manifest.json"]
    try:
        man = json.load(open(man_path, encoding="utf-8"))
    except Exception as e:
        return 1, ["manifest.json 解析失败：%s" % e]

    rows, bad = [], 0
    for item in man.get("files") or []:
        rel = item.get("path") or ""
        fp = os.path.join(root, rel)
        if not os.path.isfile(fp):
            rows.append(("缺失", rel, "")); bad += 1; continue
        now = sha256_of(fp)
        ok = now == (item.get("sha256") or "").lower()
        rows.append(("一致" if ok else "不一致", rel, now[:12]))
        if not ok:
            bad += 1

    n_ref = len([f for f in os.listdir(os.path.join(root, "references"))
                 if os.path.isfile(os.path.join(root, "references", f))]) \
        if os.path.isdir(os.path.join(root, "references")) else 0
    n_asset = len([f for f in os.listdir(os.path.join(root, "assets"))
                   if os.path.isfile(os.path.join(root, "assets", f))]) \
        if os.path.isdir(os.path.join(root, "assets")) else 0
    if n_ref < 1:
        rows.append(("覆盖不足", "references/", "0 份")); bad += 1
    if n_asset < 1:
        rows.append(("覆盖不足", "assets/", "0 份")); bad += 1

    if not quiet:
        print("状态    文件                    实算前12位")
        print("------  ----------------------  ------------")
        for st, rel, note in rows:
            print("%-6s  %-22s  %s" % (st, rel, note))
        print("\n登记 %d 个文件｜references %d 份｜assets %d 份｜问题 %d 条"
              % (len(man.get("files") or []), n_ref, n_asset, bad))
        print("\n%s" % ("HUB OK" if bad == 0 else "HUB FAIL"))
    return (0 if bad == 0 else 1), rows


def restate(root):
    """把 manifest 的哈希刷新到当前文件，保留原始时间戳字段并记录本次重述。

    只改 files[] 的 sha256 与 restated_* 三个字段：不动 author / year /
    timestamp_utc / timestamp_local / package_fingerprint_sha256 等原始声明。
    manifest.json 不登记自身（自引用哈希无法自洽）。
    """
    import time
    man_path = os.path.join(root, "manifest.json")
    man = json.load(open(man_path, encoding="utf-8"))
    keep = [f for f in (man.get("files") or []) if f.get("path") != "manifest.json"]
    paths = [f.get("path") for f in keep]
    for extra in sorted(os.listdir(root)):
        p = os.path.join(root, extra)
        if os.path.isfile(p) and extra != "manifest.json" and extra not in paths:
            paths.append(extra)
    out = [{"path": rel,
            "sha256": sha256_of(os.path.join(root, rel))}
           for rel in paths if os.path.isfile(os.path.join(root, rel))]
    man["files"] = out
    man["restated_utc"] = time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime())
    man["restated_reason"] = ("hashes recomputed after metadata edits (attribution, brand, "
                              "English fields); original timestamp fields are unchanged")
    json.dump(man, open(man_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    return len(out)


def make_fixture(tmp, bad_hash=False, drop_file=False):
    root = os.path.join(tmp, "hub")
    os.makedirs(os.path.join(root, "references"), exist_ok=True)
    os.makedirs(os.path.join(root, "assets"), exist_ok=True)
    open(os.path.join(root, "README.md"), "w", encoding="utf-8").write("hello\n")
    open(os.path.join(root, "references", "a.md"), "w", encoding="utf-8").write("ref\n")
    open(os.path.join(root, "assets", "b.svg"), "w", encoding="utf-8").write("<svg/>\n")
    digest = sha256_of(os.path.join(root, "README.md"))
    if bad_hash:
        digest = "0" * 64
    files = [{"path": "README.md", "sha256": digest},
             {"path": "references/a.md",
              "sha256": sha256_of(os.path.join(root, "references", "a.md"))},
             {"path": "assets/b.svg",
              "sha256": sha256_of(os.path.join(root, "assets", "b.svg"))}]
    if drop_file:
        files.append({"path": "MISSING.md", "sha256": "0" * 64})
    json.dump({"files": files}, open(os.path.join(root, "manifest.json"), "w", encoding="utf-8"))
    return root


def selftest():
    tmp = tempfile.mkdtemp(prefix="hub_")
    a = verify(make_fixture(os.path.join(tmp, "1")), quiet=True)[0]
    b = verify(make_fixture(os.path.join(tmp, "2"), bad_hash=True), quiet=True)[0]
    c = verify(make_fixture(os.path.join(tmp, "3"), drop_file=True), quiet=True)[0]
    checks = [("齐全应 exit 0", a == 0), ("哈希不一致应 exit 1", b == 1), ("缺文件应 exit 1", c == 1)]
    failed = [n for n, ok in checks if not ok]
    if failed:
        print("自检未通过：" + "；".join(failed))
        return 1
    print("自检通过：3/3（齐全 0 / 哈希不符 1 / 缺文件 1）")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--restate", action="store_true",
                    help="刷新 manifest 哈希到当前文件（保留原始时间戳并记录重述原因）")
    args = ap.parse_args()
    if args.selftest:
        return selftest()
    if args.restate:
        n = restate(args.root)
        print("已重述 manifest.json：登记 %d 个文件（manifest 自身不登记）" % n)
        return verify(args.root)[0]
    return verify(args.root)[0]


if __name__ == "__main__":
    sys.exit(main())
