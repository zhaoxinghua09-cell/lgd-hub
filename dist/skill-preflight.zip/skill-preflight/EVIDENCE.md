# EVIDENCE · skill-preflight

- 类型：可执行
- 记录日期：2026-11-11 17:13:40（当日实跑，未引用历史快照）
- 环境指纹：Windows / Python 3.13.14
- 记录口径：命令 + 退出码 + 输出尾部 + 产物；非“看起来正常”

## 结论

**PASS**——上列命令退出码全为 0。

## 实跑命令与退出码

| # | 命令 | 目标 | 退出码 | 耗时(ms) |
|---|---|---|---|---|
| 1 | `python -u scripts\preflight.py --selftest` | - | 0 | 79 |
| 2 | `python -u scripts\preflight.py --json <目标技能：skill-doctor>` | <目标技能：skill-doctor> | 0 | 101 |
| 3 | `python -u scripts\preflight.py <目标技能：evidence-chain-suite>` | <目标技能：evidence-chain-suite> | 0 | 86 |

## 实跑输出（尾部）

```text
# [1] exit=0
skill-preflight 自查门禁 · 豁免规则正/负样本断言
----------------------------------------------------------------
  ✅ 真徽章·普通行                        期望=True  实得=True 
  ✅ 真徽章·署名引用块内                     期望=True  实得=True 
  ✅ 说明用·反引号包裹                      期望=False 实得=False
  ✅ 说明用·规范对照表                      期望=False 实得=False
  ✅ 内容表格·徽章不豁免                     期望=True  实得=True 
  ✅ 真违规·政策背书                       期望=True  实得=True 
  ✅ 元语境·规则清单列禁用词                   期望=False 实得=False
  ✅ 技术写法·上游推荐版本                    期望=False 实得=False
  ✅ 词面·句中提退出码不算表                   期望=False 实得=False
  ✅ 实质·行首错误码表                      期望=True  实得=True 
  ✅ 政策声明·唯一合规表述                    期望=True  实得=True 
----------------------------------------------------------------
结果：11/11 通过  ✅ 门禁自检通过
```

```text
# [2] exit=0
022
  },
  "D7": {
   "skill": 1.0,
   "baseline_avg": 0.8296,
   "delta": 0.17
  },
  "D8": {
   "skill": 0.75,
   "baseline_avg": 0.2275,
   "delta": 0.522
  },
  "D9": {
   "skill": 0.0,
   "baseline_avg": 0.298,
   "delta": -0.298
  },
  "D10": {
   "skill": 0.7,
   "baseline_avg": 0.2584,
   "delta": 0.442
  }
 },
 "weakest": [
  {
   "dim": "D9",
   "name": "国际化",
   "value": 0.0,
   "weight": 0.04,
   "fix": "补 display_name_en 与 description_en，海外市场才检索得到。"
  },
  {
   "dim": "D1",
   "name": "触发设计",
   "value": 0.4,
   "weight": 0.14,
   "fix": "在 frontmatter 的 description 里写清『做什么 + 何时用 + 触发词』，并补 read_when 列表。"
  },
  {
   "dim": "D5",
   "name": "边界诚实",
   "value": 0.45,
   "weight": 0.1,
   "fix": "补边界段：不适用场景 / 局限 / 免责；再写红线（不得、禁止、严禁）。"
  }
 ],
 "verdict": "PASS · B 档，可用；补强最弱三维更稳"
}
```

```text
# [3] exit=0
    0.06   
  D9   国际化          0.000    0.298    0.04  ★
  D10  资源配套         0.300    0.258    0.08   

-- SkillHub 对齐度（七段式骨架 · 不计入 D1-D10 分，仅为评测对齐参考） --
  章节数 21  ·  覆盖 1/7  ·  骨架充实（≥9 段）
  已有: 反模式/FAQ
  缺:   错误处理、环境与稳定性、示例与最佳实践、能力边界、触发设计、安装矩阵

-- 发布规范符合度（《技能打磨规范 v1.0》+《技能包设计规范》· 不计入 D1-D10） --
  达标 3/10
  缺:   desc 含触发词+边界、徽章行 lgd-powered、可验证性 Source/How tested、中英文 _en 元数据、安装矩阵表、错误码/修复回执、政策契合声明

-- 该补什么（按拖后腿程度排序，只列 3 条） --
  1. D5 边界诚实 = 0.000（权重 0.10）
     → 补边界段：不适用场景 / 局限 / 免责；再写红线（不得、禁止、严禁）。
  2. D9 国际化 = 0.000（权重 0.04）
     → 补 display_name_en 与 description_en，海外市场才检索得到。
  3. D10 资源配套 = 0.300（权重 0.08）
     → 补 references/（知识/规范）、scripts/（可跑脚本）、assets|templates|examples/ 至少两类。

-- 判定 --
  HOLD · C 档，需加工后再上架
  blockers: 无
==============================================================
```

## 产物

- 无落盘产物（纯控制台输出，可复算）

## 复跑方式

```bash
# 在技能目录内执行；<…> 为需替换的目标参数
python -u scripts\preflight.py --selftest
python -u scripts\preflight.py --json <目标技能：skill-doctor>
python -u scripts\preflight.py <目标技能：evidence-chain-suite>
```

## 边界

- 只证明“当日、按上列命令可跑通并给出该输出”，不外推到其他环境或其他输入。
- 本文件刻意不写入本机绝对路径：可复现性靠命令与版本，不靠机器布局。
- 无脚本件用结构校验代替实跑，不冒充可执行验证。
- 退出码非 0 即记 FAIL，不以措辞放宽。

## 外锚（外部时间戳）

- 锚定对象：本件 `SKILL.md` 的 SHA-256
- 指纹：`d6593fadda3bc0d86a3061d79bc2a861180743d3baac35f94cd0b2589ae7cd16`
- 证明文件：同目录 `SKILL.md.ots`（OpenTimestamps，Binary 格式）
- 提交日历：a.pool / b.pool / alice.btc 三个公共日历，均有回执
- 生成时间：2026-11-11T17:36:30
- 复核方式：`ots verify SKILL.md`（需联网升级至比特币区块确认）；本机等价命令见《65 号件》§三
- 状态：**Pending**（已提交、待比特币区块确认；确认后 proof 永久有效，可离线校验）
- 内容不上链：链上只有 32 字节哈希与时间，原始文本不进入任何外部网络
