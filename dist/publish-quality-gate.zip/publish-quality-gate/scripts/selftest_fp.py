#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""check_release.py 的固定正负对照自检。

用途：证明"规则/示例文本豁免"没有把真泄漏一起放过。

负对照（应 exit 0）——文件本身就在列举禁用词，属规则文本：
  N1 占位符写法      `<内部代号>` / `<KEY_STORE_PATH>`
  N2 正则字面量      r'项目代号|内部代号'
  N3 类别词单独出现  "未公开"、"内部代号" 作为类别名
  N4 哈希里的数字    SHA-256 串中的 6 位数字
  N5 标准号里的数字  ISO 15189:2022 的 slug 片段

正对照（应 exit 1）——真实敏感值，必须仍然报警：
  P1 本机绝对路径    C:\\Users\\<user>\\...
  P2 API 密钥        以 sk- 起头的密钥串
  P3 密码赋值        password 赋值语句
  P4 手机号          1 开头的 11 位号码
  P5 凭据位置陈述    某文件"一行一号"风格的位置描述

用法：
  python selftest_fp.py                 # 自动建临时样本目录跑完并清理
退出码：0 全部符合预期；1 有任一不符合。
"""
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
CHECK = os.path.join(HERE, "check_release.py")

NEG = {
    "n1_placeholder.md": "见 `<内部代号>` 与本包的 `<KEY_STORE_PATH>`，此处仅示意。\n",
    "n2_rule_line.md": "BANNED = [r'项目代号', r'内部代号']  # 禁用词表\n",
    "n3_category.md": "未公开的内部代号一律不得出现在对外件中。\n",
    "n4_hash.md": "sha256: 7fbeb22530567beae4966778529ed8058d7c8e2c77420991180d55ed977abb9e\n",
    "n5_isostd.md": "参见 [ISO 15189:2022](https://ilac.org/latest_ilac_news/iso-151892022-for-medical-labs-published/)\n",
}
POS = {
    # 正对照样例一律**运行时拼接**，避免这个自检脚本本身含敏感字面量而被自己判成泄漏
    "p1_localpath.md": "落点：" + "C:" + "\\" + "Users" + "\\" + "some" + "user" + "\\Desktop\\keys\\a.txt\n",
    "p2_apikey.md": 'API_KEY = "' + "sk-" + "abcdefghijklmnop" + "1234" + '"\n',
    "p3_password.md": 'pass' + 'word = "' + "hunter2" + "xyz" + '"\n',
    "p4_phone.md": "联系电话 " + "138" + "0013" + "8000" + "\n",
    "p5_plainkey.md": "明文" + "密钥：GitHub key.txt（一行一号）\n",
}


def run(path):
    p = subprocess.run([sys.executable, "-u", CHECK, path],
                       capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    out = (p.stdout or "") + (p.stderr or "")
    return p.returncode, out


def main():
    root = tempfile.mkdtemp(prefix="gate_selftest_")
    fails = []
    try:
        neg_dir = os.path.join(root, "neg")
        pos_dir = os.path.join(root, "pos")
        for d in (neg_dir, pos_dir):
            os.makedirs(d, exist_ok=True)
        for fn, txt in NEG.items():
            open(os.path.join(neg_dir, fn), "w", encoding="utf-8", newline="\n").write(txt)
        for fn, txt in POS.items():
            open(os.path.join(pos_dir, fn), "w", encoding="utf-8", newline="\n").write(txt)

        for fn in sorted(NEG):
            single = os.path.join(root, "one_" + fn)
            os.makedirs(single, exist_ok=True)
            shutil.copy2(os.path.join(neg_dir, fn), os.path.join(single, fn))
            rc, out = run(single)
            ok = rc == 0
            print("  %-6s %-18s exit=%d %s" % ("NEG", fn, rc, "OK" if ok else "FAIL"))
            if not ok:
                fails.append(("neg", fn, out[-600:]))

        for fn in sorted(POS):
            single = os.path.join(root, "one_" + fn)
            os.makedirs(single, exist_ok=True)
            shutil.copy2(os.path.join(pos_dir, fn), os.path.join(single, fn))
            rc, out = run(single)
            ok = rc == 1
            print("  %-6s %-18s exit=%d %s" % ("POS", fn, rc, "OK" if ok else "FAIL"))
            if not ok:
                fails.append(("pos", fn, out[-600:]))

        print("")
        if fails:
            print("不符合预期 %d 项：" % len(fails))
            for kind, fn, tail in fails:
                print("--- %s %s" % (kind, fn))
                print(tail)
            return 1
        print("全部符合预期：负对照 %d 项 exit0，正对照 %d 项 exit1。" % (len(NEG), len(POS)))
        return 0
    finally:
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
