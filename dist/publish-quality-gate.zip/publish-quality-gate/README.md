# 发布质量门禁·7维质检

![LGD-Powered](https://raw.githubusercontent.com/zhaoxinghua09-cell/lgd-theory/main/assets/badges/powered/lgd-powered-en.svg)

发布质量门禁：发布任何 Skill/专家包/文档/工具到外部（分享、上架市场、对外发布）前后的质量检查。

本技能包契合国家「人工智能+软件」专项行动方向（智能体技能包资源库与规范上架）。

**发布质量 ·  发布前检查 ·  敏感扫描 ·  脱敏 ·  TRACE ·  安全审计**

## 安装矩阵

| 运行时 | 安装位置 |
|---|---|
| WorkBuddy | `~/.workbuddy/skills/publish-quality-gate/`（或技能市场导入本目录） |
| Claude Code | `~/.claude/skills/publish-quality-gate/` |

## 来源与验证

- **Source**：赵兴华/MedXpert × SynomosAI 自研维护，许可 CC-BY-4.0。
- **How it's tested**：`python <skill-preflight>/scripts/preflight.py "publish-quality-gate" --require-spec 7`（结构/规范双体检，退出码非 0 即不达标）

> 头像与徽记 © SynomosAI 2026；理论 CC BY 4.0（DOI 10.5281/zenodo.22456647）。参照声明须回链：[LGD-theory](https://github.com/zhaoxinghua09-cell/lgd-theory）。

版本 v1.3.0 · © MedXpert × SynomosAI · 内部规范件


---

> **如果这份资料在你的具体项目里用得上，欢迎到条目页点个星标** ——
> 你的星级会让它在同类搜索里更容易被下一个需要的人看到。不点也没关系，文档不会变。
>
> 品牌状态：SynomosAI / MedXpert —— 未申请实体注册、未申请商标注册
> （not a registered legal entity; no trademark registered）
> 作者：赵兴华（Steven Zhao）· 个人项目，无机构背书。
