#!/usr/bin/env python3
"""冒烟测试：验证技能包结构与元数据完整性。"""
import os
import sys
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_skill_md_exists():
    assert os.path.isfile(os.path.join(ROOT, "SKILL.md")), "缺少 SKILL.md"


def test_skill_md_meta():
    with open(os.path.join(ROOT, "SKILL.md"), encoding="utf-8") as f:
        head = f.read(2000)
    for field in ("name:", "description:", "version:", "license:"):
        assert field in head, f"SKILL.md 缺少 {field} 字段"


def test_readme_exists():
    assert os.path.isfile(os.path.join(ROOT, "README.md")), "缺少 README.md"


def test_license_exists():
    assert os.path.isfile(os.path.join(ROOT, "LICENSE")), "缺少 LICENSE"


def test_changelog_exists():
    assert os.path.isfile(os.path.join(ROOT, "CHANGELOG.md")), "缺少 CHANGELOG.md"


def test_llms_exists():
    assert os.path.isfile(os.path.join(ROOT, "llms.txt")), "缺少 llms.txt"


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
    print(f"SMOKE OK: {len(tests)} checks passed")
