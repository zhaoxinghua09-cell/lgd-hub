---
x-theory: "LGD-Lifecycle-Governance-Doctrine-v1.0"
copyright: "赵兴华（Steven Zhao）"
x-brand: "SynomosAI"
x-agent-seat: "StevenZhao26"
x-attribution: "Xinghua Zhao"
agent_created: true
  x-author-legacy: "StevenZhao26"
  x-attribution: "Xinghua Zhao"
  x-brand: "SynomosAI"
  x-agent-seat: "StevenZhao26"
  copyright: "赵兴华（Steven Zhao）"
name: lgd-gate-methodology
doc_only: "文档型·无脚本"
description: 从 0 到 1 做开源信任/安全工具的完整方法论（LGD 三律：有籍、有证、有门禁）。当你要新建一个开源扫描器、评测器或门禁工具，要规划版本迭代节奏、七层测试、质量门禁与误报率目标，或要把自己的理论/框架工程化成可复用工具时使用。
version: 1.0.0
license: MIT
author: "赵兴华（Steven Zhao）"
tags:
- methodology
- open-source
- security
- trust
- lgd
x-shelf: flagship
x-signature-line: B
category: 教程与方法论
description_en: LGD gate methodology: a from-zero playbook for building open-source trust and safety tooling with registration, evidence, and gating built in. Use it to plan version cadence, seven-layer testing, quality gates, and false-positive targets.

read_when:
- "要从零做一个开源信任或安全工具时"
- "要规划版本节奏与七层测试时"
- "要设定误报率目标与发布门禁时"
- "要把一套理论工程化成可复用的工具时"
---

# LGD-Gate 开源方法论

## When to Use

- 你要从 0 到 1 做一个新的开源工具
- 你要做安全相关的开源项目（扫描器/评测器/门禁工具）
- 你要把自己的理论/框架工程化成可复用的工具
- 你要确保开源项目的质量和安全性

## 何时不用（out of scope）

- 需要出具法律意见、认证结论或监管申报材料时——本件只给工程方法，不替代专业机构结论。
- 纯前端 / 纯 UI 项目——七层测试的重心（误报率、红队、压测）在这里用不上。
- 只想给一个"分数"而不打算留下可复算证据时——这套方法的核心就是证据，去掉它只剩口号。


## 核心三律（LGD）

### 1. 有籍（Registered）
每个任务有档案可追溯。
- 每个版本有 CHANGELOG
- 每个决策有记录
- 每个步骤有迹可循

### 2. 有证（Evidenced）
每个结论有出处有证据。
- 每个功能有测试覆盖
- 每个指标有实跑数据
- 每个说法有来源引用

### 3. 有门禁（Gated）
关键节点有检查有验证。
- CI 全绿才能过
- 误报率/召回率达标才能发
- 红队测试通过才能上线

## 完整流程（五步法）

### 第一步：Trending-to-Gap 调研法
1. 看 GitHub Trending，收集相关竞品
2. 拆解每个竞品：做什么、不做什么、优缺点
3. 找到空位：没人做的、做得不够好的
4. 定位机会：现有玩家各做一段，没人串成端到端

### 第二步：Inch-by-Inch 迭代法
1. v1.0 最小可用版——先做一个能跑的
2. v2-v3 加功能——加规则、加语言、加格式
3. v4-v5 加评测——加 benchmark、加红队测试
4. v6-v7 优化质量——降误报率、加覆盖率、做 E2E

### 第三步：Layered-Testing 七层测试法
1. 单元测试——规则数量、版本号、格式输出
2. 集成测试——端到端扫描
3. 错误处理——空文件/二进制/超长行
4. 红队测试——路径遍历/恶意输入/正则 DoS
5. 严格基准——精确率/召回率/F1
6. E2E 模拟——完整用户流程（扫描→修复→再扫描）
7. 压力测试——10000 文件并发

### 第四步：Green-Gate 质量门禁法
1. CI 全绿——所有步骤通过才能算完成
2. OpenSSF Scorecard 高分——10/10 满分
3. 自扫描（dogfooding）——扫自己，看看有没有问题
4. 误报率达标——目标 < 5%

### 第五步：LGD 三律验收
1. 有籍——CHANGELOG 完整，从 v1 到最新版都有记录
2. 有证——每个结论有测试证据，不是吹的
3. 有门禁——关键节点都过了，不是"差不多就行"

## 输出纪律

- 每个版本必须有 CHANGELOG
- 每个指标必须有实跑数据
- 每个结论必须有测试证据
- 不追求一步到位，追求持续改进

## 互相促进闭环（5 个核心功能）

### 1. 自动反馈回路（Feedback Loop）
工具用的过程中发现问题 → 自动记录到"方法论改进建议" → 方法论版本升级。

### 2. 互相打分（Mutual Scoring）
- 方法论给工具打分：功能完整性、稳定性、精度
- 工具给方法论打分：安全性、可执行性、完整性

### 3. 版本同步（Version Sync）
每个工具版本对应哪个方法论版本？方法论升级了，工具要不要跟着升级？

### 4. 自动改进建议（Auto Improvement Suggestions）
每次互相使用完，自动输出：
- 方法论建议工具改进什么
- 工具建议方法论改进什么

### 5. 演进记录（Evolution Log）
完整的迭代历史——每轮做了什么，发现了什么，改了什么。

## Known Limits

- 这套方法学是从做 SkillGate 的过程中沉淀出来的
- 适用于安全/信任相关的开源工具
- 不适用于纯前端/纯 UI 项目

## 参考

- 本方法学沉淀自 SkillGate 项目 v1→v7.3 的完整开发过程
- 核心理论：LGD 三律（有籍/有证/有门禁）

## 边界与不适用

- 不适用：需要法律意见、认证结论或监管申报的场合 —— 本件只给工程方法，不构成合规结论。
- 局限：示例基于本机 Windows 环境实测；跨平台行为需自行复跑确认。
- 不做的事：不替代评分机构，不自称权威；判据公开，可被任何人复算与质疑。

## 红线（不得做）

- **不得**只报一个"准确率"而不给 `tp / fp / fn` 拆分——隐藏漏报等于伪造结论。
- **不得**用其他层的高分抵消某一层未过；一层未过就只能是 RED。
- **不得**把小样本冒充压测结论；`files` 要写真实数量。
- **不得**在没有实跑证据时对外说"已达标"；本轮没跑就写"未测"。
- **严禁**为了过门禁而改判据；判据只能因为判错而改，并留下改前改后的对照。

## 跑一次看看（可复算）

```bash
python scripts/gate_scorecard.py --selftest
python scripts/gate_scorecard.py --in assets/scorecard-example.json
```

第一条预期 `自检通过：3/3 符合预期`、exit 0；第二条读自带示例，预期 `判定：GREEN`、exit 0。把示例里 `3_error_paths` 的 `passed` 从 6 改成 5，第二条应转 `RED`、exit 1——这条对照证明门禁真的会阻断。

判据全表见 `references/seven-layer-matrix.md`。

