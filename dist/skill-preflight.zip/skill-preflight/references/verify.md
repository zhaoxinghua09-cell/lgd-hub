# 验证方法与验证脚本

> 本文件记录「凭什么说这个工具是对的」。三条判据都可原样复跑。

## 判据

| # | 判据 | 门槛 | 实测 |
|---|---|---|---|
| ① | **复现率** —— 重算分数与 `技能评估.json` 台账记录逐位相同 | ≥95% | **100%**（60/60） |
| ② | **幂等性** —— 同一技能连跑 2 次结果完全一致 | 0 例不一致 | 通过（0/10） |
| ③ | **门禁有效** —— 故意用不达标技能触发，必须被拦 | exit 1 | 通过（见下） |

## ① 复现率 · 公平判据

**关键前提**：台账 `技能评估.json` 的 `as_of` 是 `2026-09-22 03:16:35`。
**as_of 之后被改动过的 SKILL.md，其台账分数自然过期**，与工具对错无关。
比对时必须先按文件 mtime 过滤，否则会把「台账陈旧」误判成「工具不准」。

实测（2026-09-24）：688 条中 **666 条**台账后未改动、**22 条**已改动。

## 验证脚本

```python
# verify_preflight.py —— 复现率 + 幂等性
import io, os, sys, json, random, subprocess, datetime

PY  = "<python 可执行文件绝对路径>"
PRE = "<skill-preflight>/scripts/preflight.py"
LEDGER = "<家底总账>/技能评估.json"
N, SEED = 60, 20260924

led  = json.load(io.open(LEDGER, encoding="utf-8"))
cand = [s for s in led["skills"] if os.path.exists(s["path"])]
as_of = datetime.datetime.strptime(led["as_of"], "%Y-%m-%d %H:%M:%S").timestamp()
frozen = [s for s in cand if os.stat(s["path"]).st_mtime <= as_of]   # 公平判据

random.seed(SEED)
sample = random.sample(frozen, min(N, len(frozen)))

ok, bad = 0, []
for s in sample:
    p = subprocess.run([PY, PRE, s["path"], "--json"],
                       capture_output=True, text=True, encoding="utf-8")
    got = json.loads(p.stdout)
    if (round(float(got["skill"]["score"]), 4) == round(float(s["score"]), 4)
            and got["skill"]["tier"] == s["tier"]):
        ok += 1
    else:
        bad.append((s["name"], s["score"], got["skill"]["score"]))
print("复现率 %.1f%% (%d/%d)" % (100.0 * ok / len(sample), ok, len(sample)))
for b in bad:
    print("  ✗", b)
```

## ③ 门禁故意违规验证（必做）

装了守卫就必须证明它**真会拦**，不能停在「应该会拦」。

```bash
PY="<python>"; PRE="<skill-preflight>/scripts/preflight.py"

# 期望 exit 1（D 档技能 + 要求 B 档）
"$PY" "$PRE" "<某个 D 档技能>" --min-tier B; echo "exit=$?"

# 期望 exit 0（A 档技能 + 要求 B 档）
"$PY" "$PRE" "<某个 A 档技能>" --min-tier B; echo "exit=$?"

# 期望 exit 1（内部件含本地绝对路径 + 要求可对外）
"$PY" "$PRE" "<内部技能>" --require-publishable; echo "exit=$?"
```

实测结果（2026-09-24）：

| 用例 | 期望 | 实测 |
|---|---|---|
| `external-submission-identity-guard`（D 档）+ `--min-tier B` | exit 1 | **exit 1** ✅ 报「档位 D < B」 |
| `ai-brain-learning-memory-pro`（A 档）+ `--min-tier B` | exit 0 | **exit 0** ✅ |
| `blocked-then-github-first`（内部件）+ `--require-publishable` | exit 1 | **exit 1** ✅ 报「含本地绝对路径×14」 |

## 已知局限（不藏）

- **口径漂移风险**：`WEIGHTS` / `DIM_NAME` / 正则常量与 `eval_skills.py` 是两份拷贝，
  改了单边就会静默失真。**尚未做自动一致性校验**——建议后续加一条
  「两边权重字典 diff == 空」的断言进 CI。
- **mtime 依赖**：复现率比对依赖文件 mtime 判断台账新鲜度。若文件被 `touch` 但内容未变，
  会被误排除；反之若内容被改但 mtime 未变（极少见），会误报不符。
- **baseline.json 是快照**：分位基于 2026-09-22 的 688 技能分布。技能库扩容后应重新生成。
